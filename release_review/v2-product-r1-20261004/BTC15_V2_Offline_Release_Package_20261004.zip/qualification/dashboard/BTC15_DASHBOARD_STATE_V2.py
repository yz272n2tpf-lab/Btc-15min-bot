#!/usr/bin/env python3
"""
BTC15 DASHBOARD STATE BUILDER V2

Read-only live adapter for the locked BTC15 dashboard.

Goals
- Mirror the already-frozen FINAL, Tier-1, and Strong Scalp gates.
- Read bounded tails from Railway's persistent /data files when run on Railway.
- Never place orders and never modify the trading bot or thresholds.
- Emit a compact JSON object for the dashboard UI.

Run on Railway/service container:
    python BTC15_DASHBOARD_STATE_V2.py

Run in Codespaces after downloading the CSVs locally:
    python BTC15_DASHBOARD_STATE_V2.py

Optional local pull (uses Railway CLI; downloads source files first):
    python BTC15_DASHBOARD_STATE_V2.py --pull
"""

from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import csv
import io
import json
import math
import subprocess
from typing import Dict, Iterable, List, Optional, Tuple

from btc15_data_paths_v1 import _btc15_data_root, _btc15_isolated_canary

DATA_ROOT = _btc15_data_root(legacy_cwd_fallback=True)
OUT = DATA_ROOT / 'dashboard_state.json'

FILES = {
    'unified': 'kalshi_subminute_unified_v1_1.csv',
    'live': 'kalshi_two_output_live_log_v4_13.csv',
    'rescue': 'kalshi_rescue_v2_shadow_v1.csv',
    'parity': 'kalshi_app_parity_shadow_v1.csv',
    'protect': 'kalshi_final_position_protection_shadow_v3.csv',
}

# Bounded reads. The unified file is large and growing; the dashboard never needs
# the full history to render the current contract.
TAIL_BYTES = {
    'unified': 512 * 1024,
    'live': 128 * 1024,
    'rescue': 64 * 1024,
    'parity': 128 * 1024,
    'protect': 128 * 1024,
}

# EXACT ACCEPTED/FROZEN GATES. These are mirrored from the accepted scorecard.
# They are not new thresholds and this file does not alter the bot.
TIER1_ASK_MAX = 0.45
TIER1_FAIR_MIN = 0.75
TIER1_EDGE_MIN = 0.08
TIER1_MIN_LEFT = 2.0
TIER1_MAX_LEFT = 10.0
TIER1_MIN_GAP = 25.0

FINAL_FAIR_MIN = 0.90
FINAL_MAX_LEFT = 8.0
FINAL_GAP_EARLY = 75.0  # when >6m left
FINAL_GAP_LATE = 50.0
FINAL_DIST_MIN = 1.0

SCALP_ASK_MAX = 0.70
SCALP_FAIR_MIN = 0.52
SCALP_EDGE_MIN = 0.0
SCALP_MIN_LEFT = 3.0
SCALP_MAX_LEFT = 10.0
SCALP_MIN_GAP = 50.0
SCALP_TARGET = 0.08
SCALP_STOP = 0.10
SCALP_HORIZON_MIN = 5

DIRECT_BRTI_MAX_AGE_SECONDS = 5.0
DIRECT_BRTI_WAIT_DOLLARS = 11.0


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(x) -> Optional[datetime]:
    try:
        d = datetime.fromisoformat(str(x).strip().replace('Z', '+00:00'))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc)
    except Exception:
        return None


def num(x) -> float:
    try:
        return float(str(x).strip())
    except Exception:
        return math.nan


def prob(x) -> float:
    v = num(x)
    if math.isfinite(v) and abs(v) > 1.5:
        v /= 100.0
    return v


def clean(v):
    if isinstance(v, float) and not math.isfinite(v):
        return None
    return v


def truthy(x) -> bool:
    return str(x or '').strip().lower() in {'1', 'true', 'yes', 'y'}


def side(x) -> Optional[str]:
    s = str(x or '').strip().upper()
    if s in {'UP', 'YES', 'Y', 'HIGHER', 'ABOVE', 'TRUE', '1'}:
        return 'UP'
    if s in {'DOWN', 'NO', 'N', 'LOWER', 'BELOW', 'FALSE', '0'}:
        return 'DOWN'
    return None


def first(r: Dict[str, str], names: Iterable[str]):
    for k in names:
        if k in r and str(r.get(k, '')).strip() != '':
            return r.get(k)
    return None


def _read_header(path: Path) -> List[str]:
    try:
        with path.open('r', newline='', encoding='utf-8-sig', errors='ignore') as f:
            row = next(csv.reader(f), [])
        return row
    except Exception:
        return []


def read_csv_tail(path: Path, max_bytes: int) -> List[Dict[str, str]]:
    """Read only the tail of a growing CSV while preserving its real header."""
    if not path.exists() or path.stat().st_size <= 0:
        return []
    header = _read_header(path)
    if not header:
        return []
    try:
        size = path.stat().st_size
        start = max(0, size - max_bytes)
        with path.open('rb') as f:
            f.seek(start)
            data = f.read(max_bytes)
        text = data.decode('utf-8-sig', errors='ignore')
        if start > 0:
            # The first tail line can be a partial CSV row. Drop it.
            p = text.find('\n')
            text = text[p + 1:] if p >= 0 else ''
        if text and not text.endswith('\n'):
            text = text.rsplit('\n', 1)[0] if '\n' in text else ''
        if not text.strip():
            return []
        rdr = csv.DictReader(io.StringIO(text), fieldnames=header)
        out = []
        for r in rdr:
            if r and None not in r and all(v is not None for v in r.values()) and any(str(v or '').strip() for v in r.values()):
                out.append(dict(r))
        return out
    except Exception:
        return []


def pull_local_files() -> Dict[str, bool]:
    # Optional off-canary diagnostic only; never mix production evidence in.
    if _btc15_isolated_canary():
        raise RuntimeError("Railway production-data pull is disabled in isolated canary mode")
    status = {}
    for key, filename in FILES.items():
        remote = f'/data/{filename}'
        p = subprocess.run(
            ['railway', 'service', 'files', 'download', '--overwrite', remote, f'./{filename}'],
            text=True,
            capture_output=True,
        )
        status[key] = p.returncode == 0
    return status


def latest_unified_snapshot(rows: List[Dict[str, str]]) -> Dict[str, object]:
    """Choose a complete, same-contract/same-timestamp UP+DOWN display frame.

    An incomplete append must never combine a new UP quote with an older DOWN
    quote or silently fall back to the previous contract at rollover.
    """
    groups = {}
    latest_key = None
    for row in rows:
        timestamp = parse_dt(row.get('timestamp_utc'))
        contract = str(row.get('contract', '')).strip()
        sd = side(row.get('side'))
        if timestamp is None or not contract or sd is None:
            continue
        key = (timestamp, contract)
        groups.setdefault(key, {})[sd] = row
        if latest_key is None or timestamp > latest_key[0]:
            latest_key = key
    if latest_key is None:
        return {}
    newest_contract = latest_key[1]
    for (timestamp, contract), pair in sorted(groups.items(), reverse=True):
        if contract != newest_contract or set(pair) != {'UP', 'DOWN'}:
            continue
        up, down = pair['UP'], pair['DOWN']
        shared = ('target', 'seconds_left', 'minutes_left', 'btc_price', 'btc_gap',
                  'preferred_fair', 'preferred_fair_side', 'preferred_edge',
                  'current_target_side', 'dist_over_range5', 'brti_value',
                  'brti_age_seconds', 'brti_ready', 'brti_side', 'brti_gap_to_target')
        if any(str(up.get(k, '')) != str(down.get(k, '')) for k in shared):
            continue
        prices = [prob(pair[sd].get(k)) for sd in ('UP', 'DOWN')
                  for k in ('side_bid', 'side_ask')]
        if not all(math.isfinite(v) and 0 <= v <= 1 for v in prices):
            continue
        if prices[0] > prices[1] or prices[2] > prices[3]:
            continue
        preferred = side(up.get('preferred_fair_side'))
        snap = dict(pair.get(preferred, up))
        snap.update(_timestamp=timestamp, _contract=contract,
                    _paired_quotes=True, up_bid=up['side_bid'],
                    up_ask=up['side_ask'], down_bid=down['side_bid'],
                    down_ask=down['side_ask'])
        return snap
    return {'_contract': newest_contract, '_paired_quotes': False}


def current_contract_chart(rows: List[Dict[str, str]], contract: Optional[str], max_points: int = 180):
    """Return one synchronized BTC/BRTI point per source timestamp for current contract."""
    if not contract:
        return []
    by_ts = {}
    for r in rows:
        if str(r.get('contract', '')).strip() != contract:
            continue
        t = parse_dt(r.get('timestamp_utc'))
        if t is None:
            continue
        btc = num(r.get('btc_price'))
        target = num(r.get('target'))
        brti_gap = num(first(r, ['brti_gap_to_target', 'brti_gap']))
        # Same timestamp is normally written twice (UP/DOWN). Keep one point.
        key = t.isoformat()
        if key not in by_ts or side(r.get('side')) == 'UP':
            by_ts[key] = {
                't': key,
                'btc': clean(btc),
                'brti': clean(num(r.get('brti_value'))),
                'brti_age_sec': clean(num(r.get('brti_age_seconds'))),
                'target': clean(target),
                'brti_gap': clean(brti_gap),
            }
    pts = [by_ts[k] for k in sorted(by_ts)]
    return pts[-max_points:]

def latest_row(rows: List[Dict[str, str]], time_fields: Iterable[str], contract: Optional[str] = None):
    best = None
    best_t = None
    for r in rows:
        if contract:
            rc = str(first(r, ['contract', 'unified_contract', 'api_contract']) or '').strip()
            if rc != contract:
                continue
        for k in time_fields:
            t = parse_dt(r.get(k))
            if t and (best_t is None or t > best_t):
                best = r
                best_t = t
                break
    return best or {}, best_t


def clamp01(v: float) -> float:
    return min(1.0, max(0.0, v)) if math.isfinite(v) else math.nan


def build_state() -> Dict[str, object]:
    data = {
        k: read_csv_tail(DATA_ROOT / filename, TAIL_BYTES[k])
        for k, filename in FILES.items()
    }

    s = latest_unified_snapshot(data['unified'])
    ts = s.get('_timestamp') if s else None
    contract = str(s.get('_contract') or '') or None
    age = (now_utc() - ts).total_seconds() if isinstance(ts, datetime) else None

    pref_side = side(first(s, ['preferred_fair_side', 'preferred_side']))
    target_side = side(first(s, ['current_target_side', 'btc_gap_side']))
    pref_fair = prob(first(s, ['preferred_fair', 'side_fair']))
    pref_edge = prob(first(s, ['preferred_edge', 'side_edge']))
    pref_ask = prob(first(s, ['side_ask']))
    pref_bid = prob(first(s, ['side_bid']))
    minutes_left = num(first(s, ['minutes_left']))
    seconds_left = num(first(s, ['seconds_left']))
    btc_gap = num(first(s, ['btc_gap']))
    abs_gap = abs(btc_gap) if math.isfinite(btc_gap) else math.nan
    ratio = num(first(s, ['dist_over_range5']))
    brti_ready_raw = truthy(first(s, ['brti_ready']))
    brti_age = num(first(s, ['brti_age_seconds']))
    brti_gap = num(first(s, ['brti_gap_to_target', 'brti_gap']))
    brti_side = side(first(s, ['brti_side']))
    direct_brti_authority_ready = (
        brti_ready_raw
        and math.isfinite(brti_age) and brti_age <= DIRECT_BRTI_MAX_AGE_SECONDS
        and math.isfinite(brti_gap) and abs(brti_gap) > DIRECT_BRTI_WAIT_DOLLARS
        and brti_side in {'UP', 'DOWN'}
    )
    direct_brti_agrees = bool(
        direct_brti_authority_ready and pref_side and brti_side == pref_side
    )

    # Exact frozen gates mirrored for display only.
    tier1_ready = (
        pref_side is not None
        and math.isfinite(pref_ask) and pref_ask <= TIER1_ASK_MAX
        and math.isfinite(pref_fair) and pref_fair >= TIER1_FAIR_MIN
        and math.isfinite(pref_edge) and pref_edge >= TIER1_EDGE_MIN
        and math.isfinite(minutes_left) and TIER1_MIN_LEFT <= minutes_left <= TIER1_MAX_LEFT
        and math.isfinite(abs_gap) and abs_gap >= TIER1_MIN_GAP
    )

    required_gap = FINAL_GAP_EARLY if math.isfinite(minutes_left) and minutes_left > 6.0 else FINAL_GAP_LATE
    final_ready = (
        pref_side is not None and target_side is not None and pref_side == target_side
        and math.isfinite(minutes_left) and minutes_left <= FINAL_MAX_LEFT
        and math.isfinite(pref_fair) and pref_fair >= FINAL_FAIR_MIN
        and math.isfinite(abs_gap) and abs_gap >= required_gap
        and math.isfinite(ratio) and ratio >= FINAL_DIST_MIN
        and direct_brti_authority_ready
        and direct_brti_agrees
    )

    scalp_ready = (
        pref_side is not None
        and math.isfinite(pref_ask) and pref_ask <= SCALP_ASK_MAX
        and math.isfinite(pref_fair) and pref_fair >= SCALP_FAIR_MIN
        and math.isfinite(pref_edge) and pref_edge >= SCALP_EDGE_MIN
        and math.isfinite(minutes_left) and SCALP_MIN_LEFT <= minutes_left <= SCALP_MAX_LEFT
        and math.isfinite(abs_gap) and abs_gap >= SCALP_MIN_GAP
    )

    live_row, live_t = latest_row(data['live'], ['timestamp_utc'], contract=contract)
    rescue_row, rescue_t = latest_row(data['rescue'], ['resolved_timestamp_utc', 'source_timestamp_utc'])
    parity_row, parity_t = latest_row(data['parity'], ['audit_timestamp_utc', 'source_timestamp_utc'], contract=contract)
    protect_row, protect_t = latest_row(data['protect'], ['collector_timestamp_utc', 'source_timestamp_utc'], contract=contract)

    recorded_final_call = (
        str(live_row.get('final_status', '')).strip().upper() == 'FINAL CALL'
        and side(live_row.get('final_side')) is not None
    )

    scalp_target_bid = clamp01(pref_ask + SCALP_TARGET) if math.isfinite(pref_ask) else math.nan
    scalp_stop_bid = clamp01(pref_ask - SCALP_STOP) if math.isfinite(pref_ask) else math.nan

    chart_points = current_contract_chart(data['unified'], contract)

    generated = now_utc()
    age = (generated - ts).total_seconds() if isinstance(ts, datetime) else None
    close_time = None
    if isinstance(ts, datetime) and math.isfinite(seconds_left) and 0 <= seconds_left <= 900:
        close_time = ts + timedelta(seconds=seconds_left)
    current_remaining = max(0.0, (close_time - generated).total_seconds()) if close_time else None
    paired = bool(s.get('_paired_quotes'))
    fresh = bool(age is not None and 0 <= age <= 15 and paired and current_remaining is not None and current_remaining > 0)
    brti_effective_age = max(0.0, age) + brti_age if age is not None and math.isfinite(brti_age) and brti_age >= 0 else None
    state: Dict[str, object] = {
        'display_build': '13.2-sync-candidate',
        'generated_utc': generated.isoformat(),
        'source_timestamp_utc': ts.isoformat() if isinstance(ts, datetime) else None,
        'health': {'source_fresh': fresh, 'paired_quotes': paired,
                   'brti_fresh': bool(fresh and brti_ready_raw and brti_effective_age is not None and 0 <= brti_effective_age <= DIRECT_BRTI_MAX_AGE_SECONDS),
                   'market_open': bool(current_remaining is not None and current_remaining > 0),
                   'read_only_diagnostic': True},
        'source_age_sec': round(age, 2) if age is not None else None,
        'contract': contract,
        'timer': {
            'close_utc': close_time.isoformat() if close_time else None,
            'close_basis': 'source_timestamp_plus_logged_remaining',
            'remaining_at_generation_sec': current_remaining,
            'minutes_left': clean(minutes_left),
            'seconds_left': clean(seconds_left),
        },
        'chart': {
            'points': chart_points,
            'live': bool(chart_points),
        },
        'market': {
            'target': clean(num(first(s, ['target']))),
            'btc_price': clean(num(first(s, ['btc_price']))),
            'btc_gap': clean(btc_gap),
            'preferred_side': pref_side,
            'up_bid': clean(prob(first(s, ['up_bid', 'yes_bid']))),
            'up_ask': clean(prob(first(s, ['up_ask', 'yes_ask']))),
            'down_bid': clean(prob(first(s, ['down_bid', 'no_bid']))),
            'down_ask': clean(prob(first(s, ['down_ask', 'no_ask']))),
            'dist_over_range5': clean(ratio),
            'range5': clean(num(first(s, ['range5']))),
            'vol5': clean(num(first(s, ['vol5']))),
            'btc_move_15s': clean(num(first(s, ['btc_move_15s_side']))),
            'btc_move_30s': clean(num(first(s, ['btc_move_30s_side']))),
            'btc_move_60s': clean(num(first(s, ['btc_move_60s_side']))),
            'brti_value': clean(num(first(s, ['brti_value']))),
            'brti_age_seconds': clean(brti_age),
            'brti_effective_age_seconds': brti_effective_age,
            'brti_ready': brti_ready_raw,
            'brti_gap': clean(brti_gap),
            'brti_side': brti_side,
            'direct_brti_authority_ready': direct_brti_authority_ready,
            'direct_brti_agrees': direct_brti_agrees,
            'reversal_state': str(first(s, ['reversal_state']) or '').strip().upper() or None,
        },
        'final': {
            'side': pref_side,
            'confidence': clean(pref_fair),
            'ready': final_ready,
            'recorded_final_call': recorded_final_call,
            'recorded_status': live_row.get('final_status') or None,
            'recorded_side': side(live_row.get('final_side')),
            'recorded_confidence': clean(prob(live_row.get('final_confidence'))),
            'required_gap': required_gap,
            'source': 'FROZEN_V4_6_FINAL',
            'conditions': {
                'minutes_left_lte_8': bool(math.isfinite(minutes_left) and minutes_left <= FINAL_MAX_LEFT),
                'fair_gte_90': bool(math.isfinite(pref_fair) and pref_fair >= FINAL_FAIR_MIN),
                'gap_ok': bool(math.isfinite(abs_gap) and abs_gap >= required_gap),
                'dist_over_range5_gte_1': bool(math.isfinite(ratio) and ratio >= FINAL_DIST_MIN),
                'preferred_matches_target': bool(pref_side and target_side and pref_side == target_side),
                'direct_brti_authority_ready': direct_brti_authority_ready,
                'preferred_matches_brti': direct_brti_agrees,
            },
        },
        'early': {
            'side': pref_side,
            'fair': clean(pref_fair),
            'ask': clean(pref_ask),
            'bid': clean(pref_bid),
            'edge': clean(pref_edge),
            'ready': tier1_ready,
            'status': 'GOOD' if tier1_ready else 'WATCHING',
            'entry_ceiling': TIER1_ASK_MAX,
            'source': 'FROZEN_TIER1',
        },
        'scalp': {
            'side': pref_side,
            'fair': clean(pref_fair),
            'ask': clean(pref_ask),
            'bid': clean(pref_bid),
            'edge': clean(pref_edge),
            'ready': scalp_ready,
            'status': 'ACTIVE' if scalp_ready else 'WATCHING',
            'entry_ceiling': SCALP_ASK_MAX,
            'target_bid': None,
            'stop_bid': None,
            'position_status': 'NOT_LINKED',
            'hypothetical_target_bid': clean(scalp_target_bid) if scalp_ready else None,
            'hypothetical_stop_bid': clean(scalp_stop_bid) if scalp_ready else None,
            'target_gain': SCALP_TARGET,
            'stop_loss': SCALP_STOP,
            'horizon_minutes': SCALP_HORIZON_MIN,
            'source': 'FROZEN_STRONG_SCALP',
        },
        'rescue_v2': {
            'shadow_only': True,
            'record_type': rescue_row.get('record_type') or None,
            'contract': rescue_row.get('contract') or None,
            'side': side(rescue_row.get('side')),
            'result': rescue_row.get('result') or None,
            'entry_ask': clean(prob(rescue_row.get('entry_ask'))),
            'fair': clean(prob(rescue_row.get('fair'))),
            'edge': clean(prob(rescue_row.get('edge'))),
            'timestamp_utc': rescue_t.isoformat() if rescue_t else None,
        },
        'parity': {
            'shadow_only': True,
            'status': parity_row.get('overall_status') or None,
            'contract_match': parity_row.get('contract_match') or None,
            'clock_match': parity_row.get('clock_match') or None,
            'target_match': parity_row.get('target_match') or None,
            'quote_match': parity_row.get('quote_match') or None,
            'brti_match': parity_row.get('brti_match') or None,
            'notes': parity_row.get('notes') or None,
            'timestamp_utc': parity_t.isoformat() if parity_t else None,
            'contract': parity_row.get('unified_contract') or parity_row.get('contract') or None,
            'api_contract': parity_row.get('api_contract') or None,
        },
        'position_protection': {
            'shadow_only': True,
            'record_type': protect_row.get('record_type') or None,
            'final_side': side(protect_row.get('final_side')),
            'current_preferred_side': side(protect_row.get('current_preferred_side')),
            'current_fair': clean(prob(protect_row.get('current_fair'))),
            'fair_change_from_trigger': clean(num(protect_row.get('fair_change_from_trigger'))),
            'signed_gap_change_from_trigger': clean(num(protect_row.get('signed_gap_change_from_trigger'))),
            'bid_change_from_trigger': clean(prob(protect_row.get('bid_change_from_trigger'))),
            'reversal_state': protect_row.get('reversal_state') or None,
            'timestamp_utc': protect_t.isoformat() if protect_t else None,
        },
        'safety': {
            'read_only': True,
            'orders_enabled': False,
            'trading_logic_changed': False,
            'shadow_protection_used_as_action': False,
        },
    }
    return state


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pull', action='store_true', help='Download current Railway files first (local/Codespaces only).')
    ap.add_argument('--stdout', action='store_true', help='Print JSON instead of only the normal PASS summary.')
    args = ap.parse_args()

    print('=' * 82)
    print('BTC15 DASHBOARD STATE BUILDER V2')
    print('=' * 82)
    if args.pull and DATA_ROOT != Path('/data'):
        print('Railway sync:')
        status = pull_local_files()
        for key, ok in status.items():
            print(f"  {'OK  ' if ok else 'WAIT'} {FILES[key]}")
        print()

    state = build_state()
    OUT.write_text(json.dumps(state, indent=2, sort_keys=True), encoding='utf-8')

    if args.stdout:
        print(json.dumps(state, indent=2, sort_keys=True))
        print()

    print('RESULT: PASS')
    print('Wrote:', OUT)
    print('Frozen FINAL / Tier-1 / Strong Scalp gates mirrored only; not changed.')
    print('Position-protection and Rescue V2 remain shadow-only.')
    print('Orders enabled: NO')
    print('=' * 82)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
