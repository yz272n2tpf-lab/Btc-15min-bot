BTC15 LIVE DASHBOARD V13
========================

Purpose
- Turn the already-locked V12 dashboard layout into a live read-only app.
- Keep the existing BTC15 signal bot, Rescue V2 shadow, parity shadow, and
  position-protection shadow unchanged.
- No orders and no automatic trade execution.

Files
- BTC15_DASHBOARD_STATE_V2.py
  Reads bounded tails from /data and builds a compact dashboard state.
  Mirrors the frozen Tier-1 and FINAL gates. FINAL includes the direct BRTI
  authority gate. Rescue V2 and position protection stay shadow-only.

- BTC15_DASHBOARD_LIVE_SERVER_V1.py
  Serves the locked dashboard and /dashboard_state.json from the same Railway
  service. The endpoint is no-cache and read-only.

- BTC_Kalshi_App_Live_v13.html
  Locked V12 layout with live field wiring added. No panel rearrangement.
  Updates state every 5 seconds and keeps the on-screen contract timer ticking
  every second.

- BTC15_RUN_FULL_VALIDATION_WITH_DASHBOARD_V1.py
  Starts the existing btc15_run_full_validation_v1.py unchanged plus the
  dashboard server. Dashboard failure does not stop the core runner.

Promotion sequence
1. Put all four files in the repo root.
2. Run: python BTC15_RUN_FULL_VALIDATION_WITH_DASHBOARD_V1.py --self-test
3. Change Railway start command to:
   python -u BTC15_RUN_FULL_VALIDATION_WITH_DASHBOARD_V1.py
4. Expose the service domain and verify /health and the dashboard.
5. Verify memory, parity, position protection, and no new rc=-9 exits.

Safety
- Signal-only.
- No order placement.
- No core threshold retuning.
- Position-protection remains shadow-only; the UI does not invent HOLD/PROTECT/
  EXIT thresholds from unvalidated telemetry.
