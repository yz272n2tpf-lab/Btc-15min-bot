#!/usr/bin/env python3
"""
BTC15 FULL VALIDATION + LIVE DASHBOARD RUNNER V1

Dashboard deployment wrapper.
- Existing btc15_run_full_validation_v1.py remains unchanged in the repo cwd.
- Dashboard code/HTML are extracted beside this wrapper by the installer.
- Dashboard failure never stops the core/full-validation process tree.
- NO ORDERS. NO TRADING-LOGIC CHANGES.
"""
from pathlib import Path
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
CORE = Path('qualification/v2_product_20261004/dashboard/btc15_run_full_validation_v1.py')
DASH = BASE / "BTC15_DASHBOARD_LIVE_SERVER_V1.py"
STATE = BASE / "BTC15_DASHBOARD_STATE_V2.py"
HTML = BASE / "BTC_Kalshi_App_Live_v13.html"


def main() -> int:
    required = (CORE, DASH, STATE, HTML)

    if "--self-test" in sys.argv:
        missing = [str(p) for p in required if not p.exists()]
        if missing:
            raise SystemExit("SELF-TEST FAIL: missing " + ", ".join(missing))
        p = subprocess.run(
            [sys.executable, str(DASH), "--self-test"],
            text=True,
            capture_output=True,
        )
        if p.returncode != 0 or "SELF-TEST: PASS" not in (p.stdout or ""):
            print((p.stdout or "") + (p.stderr or ""))
            raise SystemExit("SELF-TEST FAIL: dashboard server")
        print("BTC15 FULL VALIDATION + DASHBOARD SELF-TEST: PASS")
        print("Existing full-validation runner present: YES")
        print("Dashboard asset directory:", BASE)
        print("Read-only dashboard: YES")
        print("Orders enabled by dashboard: NO")
        return 0

    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise SystemExit("STOP: missing " + ", ".join(missing))

    print("=" * 88, flush=True)
    print("BTC15 FULL VALIDATION + LIVE DASHBOARD: STARTING", flush=True)
    print("Existing full-validation runner: UNCHANGED CHILD", flush=True)
    print("Dashboard: READ-ONLY / SIGNAL DISPLAY ONLY", flush=True)
    print("NO ORDERS. NO TRADING-LOGIC CHANGES.", flush=True)
    print("=" * 88, flush=True)

    core = subprocess.Popen([sys.executable, "-u", str(CORE)])
    dash = subprocess.Popen([sys.executable, "-u", str(DASH)])

    stopping = False

    def stop(signum, frame):
        nonlocal stopping
        stopping = True
        for p in (dash, core):
            if p.poll() is None:
                p.terminate()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    dash_exit_reported = False
    try:
        while True:
            rc = core.poll()
            if rc is not None:
                break
            drc = dash.poll()
            if drc is not None and not dash_exit_reported:
                print(
                    f"DASHBOARD PROCESS EXITED rc={drc}; core + validation continue untouched.",
                    flush=True,
                )
                dash_exit_reported = True
            time.sleep(2)
    finally:
        if dash.poll() is None:
            dash.terminate()
        if core.poll() is None and not stopping:
            core.terminate()

    return core.returncode or 0


if __name__ == "__main__":
    raise SystemExit(main())
