from pathlib import Path
import json,hashlib,os,contextlib,io,sys
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()))
from btc15_v2_product.release import verify_environment,read_receipt
lane=sys.argv[1];base=Path('/workspace/scratch/7500f1a32278/v2_release/package');idx=json.loads((base/'RELEASE_INDEX.json').read_text());r=json.loads((base/'release_receipt.template.json').read_text())
v=r['lanes'][lane];deployment=('33333333' if lane=='main' else '44444444')+'-1234-1234-1234-123456789abc'
env={'BTC15_V2_APPROVED_MANIFEST_SHA256':idx['manifest_sha256'],'BTC15_V2_APPROVED_BUILD':v['build'],'RAILWAY_PROJECT_ID':r['project'],'RAILWAY_ENVIRONMENT_ID':r['environment'],'RAILWAY_SERVICE_ID':v['service'],'RAILWAY_DEPLOYMENT_ID':deployment,'RAILWAY_GIT_COMMIT_SHA':v['build'],'RAILWAY_VOLUME_ID':v['volume'],'RAILWAY_VOLUME_MOUNT_PATH':'/data'}
with patch.dict(os.environ,env,clear=True),contextlib.redirect_stdout(io.StringIO()):
 got=verify_environment(lane);assert got['evidence_class']=='RUNTIME_ONLY_NOT_CONTROL_PLANE_VERIFIED'
 assert deployment in os.environ['BTC15_LADDER_DATA_ROOT']
checks=[{'check':'Exact reviewed candidate pin accepts synthetic matching runtime identity; no runtime launched','result':'PASS'}]
try:
 read_receipt(base/'release_receipt.template.json',hashlib.sha256((base/'release_receipt.template.json').read_bytes()).hexdigest())
 raise AssertionError('Template accepted')
except ValueError as e:
 assert str(e)=='RECEIPT_CLASS'
 checks.append({'check':'Invalid unfilled production receipt template fails closed','result':'PASS','reason':str(e)})
(base/'qualification'/f'{lane}_final_release_gate_checks.json').write_text(json.dumps({'lane':lane,'checks':checks,'synthetic_environment':True,'production_started':False,'orders':False},indent=2)+'\n')
print(lane,'reviewed-pin and invalid-template checks passed; no runtime started.')
