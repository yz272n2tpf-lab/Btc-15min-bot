# BTC15 offline recovery — V2 evidence contract

Status: PASS_OFFLINE_CONTRACT_ONLY. No runtime hooks or production deployment.
Commit: `9b5b02744d8e31307516efb5a33c5190d8c74e90`
Tree: `446b1daa9893332397ff2142fe78cd9d555e13c4`
Branch: `audit/pr36-origin-adapter-20260925` (local only; no push attempted)
Prior checkpoint: `9ca8f33a14df3606556bdf027eaa4af6cfd2ebd5`
Production PR36: `3e552065e34a0a402bc3ca4598b57dff1f1c6e77`
Two-clock candidate, unchanged and undeployed: `06261dbfbe6d8336a6886a4f2b349f33b06b6202`
SIGNAL ONLY / NO ORDERS.

## Restore offline work without GitHub or authentication

1. Extract this ZIP to a fresh directory; retain the original archive.
2. Run `python3 verify_recovery.py` in that directory to verify manifest hashes.
3. Run `python3 run_focused.py` to execute exactly 40 focused stdlib tests from
   the self-contained `offline/` source package, with no credentials or network.
   All inputs are synthetic January 2020 fixtures. There is NO authentic live pair.
4. Read `offline/completion_audit/EVIDENCE_CONTRACT_V2_20260925.md` and companion
   JSON. Prior V1/counterexample documents remain present and unchanged. Their
   old BLOCKED statements describe prior checkpoints; V2 solves only the offline
   representation gap, not prospective capture/runtime qualification.

The included full native file is for AST/blob verification ONLY. Do not run it.
No model artifacts, credentials, private captures, production configuration or
live data directories are included. Source/tests are self-contained; this is
NOT a complete deployable repository mirror.

## Restore exact Git commits when the full repository is available

The incremental `local-ladder-history.bundle` preserves every local ladder commit
since base `852e9a4638eb487ffe5a307b79d039d2a9b747c1`. The receiving full repo must already contain that base.
Run `git bundle verify /absolute/path/local-ladder-history.bundle`, then fetch
its `audit/pr36-origin-adapter-20260925` ref into a new local recovery branch without overwriting existing
work. Verify recovered HEAD/tree against the identities above before continuing.
This operation needs no GitHub login or push. The bundle does not contain the
entire pre-base repository history.

## Exact next task — no need to repeat earlier investigation

Prepare and qualify the minimal passive V2 source-owner/native/observer capture
patch OFFLINE ONLY. Capture genuine pre-cutoff owner receipt/validation witnesses
bound to exact quote/BRTI/BTC publications. Retain raw native floats/consumption,
original cutoff and publication/completion timestamps in distinct fields. Never
reconstruct missing provenance or backdate. Bind actual instrumentation build
identity and prove enabled/disabled native outputs/state equivalent. A later
changed capture build must not be mislabeled as PR36 or automatically whitelisted.
No deployment/restart/configuration mutation is authorized by this recovery file.

Existing offline explicit immutable EARLY origin/linkage, unknown advice/exit
policies, contract boundaries, model identities, duplicate/conflict handling and
source freshness rules stay frozen. Historical V1 data stays V1. V2 complete
fixtures passing does not mean authentic live capture exists. Incomplete old
observations remain unusable. Separate two-clock live acceptance remains required.

Do not resume cost/SSH/GitHub authentication, predictive scoring, tuning, lifecycle
policy creation, threshold/model changes or orders. Return to the user after the
single authorized next task. Preserve Work usage.
