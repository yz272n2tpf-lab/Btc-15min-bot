"""Only 43 focused offline tests; no production or network operation."""
import os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent/'offline'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='completion_audit:.')
raise SystemExit(subprocess.call([sys.executable,'-m','unittest',*['completion_audit.test_early_origin_replay', 'completion_audit.test_pr36_evidence_adapter', 'completion_audit.test_microsecond_origin_replay', 'completion_audit.test_passive_capture_feasibility', 'completion_audit.test_evidence_contract_v2', 'completion_audit.test_capture_release_identity_gate'],'-v'],cwd=root,env=env))
