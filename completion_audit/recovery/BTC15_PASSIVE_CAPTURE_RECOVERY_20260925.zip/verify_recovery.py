"""Verify bytes before recovery. No network or repository writes."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/"RECOVERY_MANIFEST.json").read_text())
for name,expected in manifest["files_sha256"].items():
    path=root/name
    assert path.is_file(), "MISSING: "+name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected, "HASH MISMATCH: "+name
print("PASS: all recovery files match manifest; checkpoint "+manifest["commit"])
