"""Synthetic January 2020 format tests, never authentic live lifecycle evidence."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from early_origin_replay import canonical, replay as replay_v1
from early_origin_replay_v2 import replay
from pr36_evidence_adapter import evidence_json, ms, sha
from pr36_evidence_adapter_v2 import Archive, adapt, bound_payloads, OWNER_ROLES
from test_microsecond_origin_replay import micro_fixture, add_micro
from test_passive_capture_feasibility import delivery_counterexample, quote_counterexample
from test_pr36_evidence_adapter import OPEN


def iso_exact(value):
    # Test-only exact clock fabrication. This is not a capture/export function.
    micros = value * 1000
    assert micros.denominator == 1
    return (datetime(1970, 1, 1, tzinfo=timezone.utc) +
            timedelta(microseconds=micros.numerator)).isoformat(timespec='microseconds')


def fixture_v2(us=191, delta=120000, **kwargs):
    docs, mapping = micro_fixture(us, delta, **kwargs)
    c, b, q, f = (docs[k] for k in ('context', 'brti_delivery', 'quote', 'fair'))
    cut = ms(c['decision_utc'])
    received = c.pop('quote_received_utc')
    c.update(schema='BTC15_NATIVE_CONTEXT_V2', clock_basis='NATIVE_UTC_MICROSECOND_WITNESS',
             completed_publication_utc=iso_exact(ms(c['published_utc']) + 1),
             consumption_completed_utc=dict(quote=iso_exact(cut + 4), brti=c['decision_utc'], btc=c['decision_utc']))
    q['consumed_ms'] = int(cut + 4)
    # Match what native float producers emit. These are NOT provenance clocks.
    source = float(b['source_ts'])
    age = float(cut / 1000) - source
    b.update(source_ts=source, age_at_decision=age)
    b['delivery'].update(decision_ts=float(cut / 1000), checked_ts=float(cut / 1000),
                         observed_ts=float(b['delivery']['observed_ts']), current_age=age)
    docs['observation']['market']['brti_age_seconds'] = age
    # Independently specified synthetic owner witnesses (not derived from raw floats).
    # Keep the same source-owner receipt for repeated publications at sub-ms cuts.
    brti_receipt = iso_exact(Fraction(OPEN + delta - 500) + Fraction(111, 1000) +
                            (ms(docs['contract']['open_time']) - OPEN))
    witnesses = dict(schema='BTC15_SOURCE_WITNESSES_V2')
    for name, epoch, source_time, receipt in (
        ('quote', q['epoch'], iso_exact(Fraction(q['identity'][3])), received),
        ('brti', docs['brti_source']['owner_epoch'], iso_exact(Fraction(docs['brti_source']['source_ts_ms'])), brti_receipt),
        ('btc', c['btc_owner_epoch'], f['btc_source_utc'], f['btc_observed_utc'])):
        witnesses[name] = dict(authority=OWNER_ROLES[name], clock_basis='OWNER_UTC_MICROSECOND_WITNESS',
            owner_epoch=epoch, source_utc=source_time, received_utc=receipt,
            validated_utc=receipt, witnessed_utc=receipt,
            payload_sha256=sha(evidence_json(bound_payloads(docs)[name]).encode()))
    docs['witnesses'] = witnesses
    return docs, mapping


def convert(*cases):
    archive = Archive()
    mappings = [add_micro(archive, *case, str(i)) for i, case in enumerate(cases)]
    return archive, mappings, adapt(archive, mappings)


class EvidenceContractV2Tests(unittest.TestCase):
    def test_v1_files_and_counterexample_semantics_unchanged(self):
        expected = json.loads((Path(__file__).with_name('EVIDENCE_CONTRACT_V2_20260925.json')).read_text())['v1_file_sha256']
        for path, checksum in expected.items():
            self.assertEqual(sha((Path(__file__).parents[1] / path).read_bytes()), checksum)
        self.assertEqual(quote_counterexample()['result']['adapter_rejections'][0]['reason'], 'QUOTE_PROVENANCE_TIME')
        self.assertEqual(delivery_counterexample()['result']['adapter_rejections'][0]['reason'], 'SUBMICROSECOND_CLOCK_NOT_REPRESENTABLE')
        row = convert(fixture_v2())[2]['converted_records'][0]
        self.assertTrue(replay_v1([row]).rejections)

    def test_complete_v2_pair_lossless_raw_tokens_and_cli_deterministic(self):
        docs, m = fixture_v2()
        archive, mappings, result = convert((docs, m), fixture_v2(192, kind='FINAL_EVIDENCE'))
        self.assertFalse(result['adapter_rejections']); self.assertFalse(result['replay']['rejections'])
        with patch('socket.socket', side_effect=AssertionError('OFFLINE ONLY')):
            self.assertEqual(result, adapt(archive, mappings))
        row = result['converted_records'][0]
        raw = archive.raw_record(mappings[0]['brti_delivery'])
        self.assertIn('1.0001909732818604', raw)
        self.assertEqual(row['evidence']['documents']['brti_delivery'], raw)
        life = result['replay']['lifecycles'][0]
        self.assertEqual(life['origin']['entry_ts_ms'], f'{OPEN+120000}.191')
        self.assertEqual(life['final_evidence'][0]['native']['decision_ts_ms'], f'{OPEN+120000}.192')
        self.assertIsNone(life['advice_state']); self.assertFalse(life['execution_or_fill_proven'])
        frozen = replay(result['converted_records'])
        row['entry_price'] = .99
        self.assertEqual(frozen.lifecycles[0].origin.to_dict()['entry_price'], .35)
        self.assertEqual(replay([row]).rejections[0].reason, 'NORMALIZED_EVIDENCE_MISMATCH')
        with tempfile.TemporaryDirectory() as tmp:
            source, out = Path(tmp)/'rows.jsonl', Path(tmp)/'out.json'
            # Full explicit stream, not a guessed origin for the FINAL-only file.
            source.write_text('\n'.join(canonical(r) for r in [life['origin']] + life['final_evidence']))
            subprocess.run([sys.executable, str(Path(__file__).with_name('early_origin_replay_v2.py')),
                            str(source), '--output', str(out)], check=True, capture_output=True)
            self.assertEqual(json.loads(out.read_text()), result['replay'])
        altered = raw.replace('1.0001909732818604', '1.0001909732818604000')
        a = Archive(); a.add('raw', altered.encode(), sha(altered.encode()))
        self.assertEqual(a.raw_record({'artifact':'raw','row':0}), altered)

    def test_post_cutoff_consumption_is_not_availability_or_validation(self):
        docs, m = fixture_v2()
        q = quote_counterexample()['docs']['quote']
        docs['quote'] = q  # Actual frozen producer output on synthetic input.
        # Exact consumption witness exists separately from the rounded native field.
        docs['context']['consumption_completed_utc']['quote'] = '2020-01-01T00:02:00.004001+00:00'
        docs['witnesses']['quote']['payload_sha256'] = sha(evidence_json(bound_payloads(docs)['quote']).encode())
        result = convert((docs, m))[2]
        self.assertFalse(result['adapter_rejections']); self.assertFalse(result['replay']['rejections'])
        row = result['converted_records'][0]
        self.assertLess(ms(docs['witnesses']['quote']['validated_utc']), ms(docs['context']['decision_utc']))
        self.assertEqual(json.loads(row['evidence']['documents']['quote'])['consumed_ms'], OPEN+120004)
        for key in ('received_utc', 'validated_utc', 'witnessed_utc'):
            bad = deepcopy(docs); bad['witnesses']['quote'][key] = bad['context']['consumption_completed_utc']['quote']
            self.assertFalse(convert((bad, m))[2]['converted_records'])
        bad = deepcopy(docs); bad['context']['consumption_completed_utc']['quote'] = bad['witnesses']['quote']['received_utc']
        self.assertEqual(convert((bad, m))[2]['adapter_rejections'][0]['reason'], 'RAW_QUOTE_CONSUMPTION_ORDER')

    def test_future_event_and_one_microsecond_witness_cutoff_fail_closed(self):
        for difference in (-1, 0, 1):
            docs, m = fixture_v2()
            clock = iso_exact(ms(docs['context']['decision_utc']) + Fraction(difference, 1000))
            w = docs['witnesses']['quote']
            w.update(received_utc=clock, validated_utc=clock, witnessed_utc=clock)
            r = convert((docs, m))[2]
            self.assertEqual(bool(r['converted_records']), difference <= 0)
        docs, m = fixture_v2()
        docs['quote'] = quote_counterexample(late_source=True)['docs']['quote']
        w = docs['witnesses']['quote']
        w['payload_sha256'] = sha(evidence_json(bound_payloads(docs)['quote']).encode())
        w['source_utc'] = '2020-01-01T00:02:00.001000+00:00'
        w.update(received_utc='2020-01-01T00:02:00.001001+00:00',
                 validated_utc='2020-01-01T00:02:00.001001+00:00', witnessed_utc='2020-01-01T00:02:00.001001+00:00')
        self.assertEqual(convert((docs, m))[2]['adapter_rejections'][0]['reason'], 'SOURCE_NOT_INDEPENDENTLY_AVAILABLE_AT_CUTOFF')

    def test_float_age_never_supplies_exact_clock_or_missing_witness(self):
        docs, m = fixture_v2()
        case = delivery_counterexample()
        docs['brti_delivery'] = case['docs']['brti_delivery']
        docs['observation']['market']['brti_age_seconds'] = case['native']['age']
        for k in ('received_utc', 'validated_utc', 'witnessed_utc'):
            docs['witnesses']['brti'][k] = '2020-01-01T00:01:59.500000+00:00'
        self.assertFalse(convert((docs, m))[2]['adapter_rejections'])
        # The actual checked float may have submicrosecond precision. A later
        # independently witnessed completion records it without rounding it.
        fractional = deepcopy(docs)
        d = fractional['brti_delivery']['delivery']
        d['checked_ts'] = float(Decimal('1577836920.0001912'))
        d['current_age'] = d['checked_ts'] - float(fractional['brti_delivery']['source_ts'])
        fractional['context']['consumption_completed_utc']['brti'] = '2020-01-01T00:02:00.000192+00:00'
        got = convert((fractional, m))[2]
        self.assertFalse(got['adapter_rejections'])
        self.assertIn(str(d['checked_ts']), got['converted_records'][0]['evidence']['documents']['brti_delivery'])
        for field in ('source_utc', 'received_utc', 'validated_utc', 'witnessed_utc'):
            bad = deepcopy(docs); bad['witnesses']['brti'][field] = case['native']['age']
            self.assertFalse(convert((bad, m))[2]['converted_records'])
        for change in (lambda d: d.pop('witnesses'),
                       lambda d: d['witnesses']['brti'].pop('received_utc'),
                       lambda d: d['witnesses']['brti'].update(clock_basis='DERIVED_NATIVE_FLOAT'),
                       lambda d: d['witnesses']['brti'].update(authority='PR36_NATIVE_CONSUMER'),
                       lambda d: d['brti_delivery'].update(age_at_decision=Decimal('1.000191'))):
            bad = deepcopy(docs); change(bad)
            self.assertFalse(convert((bad, m))[2]['converted_records'])

    def test_missing_ambiguous_wrong_owner_payload_and_native_context_rejected(self):
        a, mappings, result = convert(fixture_v2(), fixture_v2(192, kind='FINAL_EVIDENCE'))
        self.assertEqual(len(adapt(a, [])['unmapped_observations']), 2)
        self.assertEqual(adapt(a, [mappings[1]])['replay']['rejections'][0]['reason'], 'UNKNOWN_EARLY_ORIGIN')
        alias = deepcopy(mappings[0]); alias['entry_id'] = 'invented'
        self.assertFalse(adapt(a, [mappings[0], alias])['converted_records'])
        for change in (lambda d: d['context'].pop('native_owner_epoch'),
                       lambda d: d['contract'].pop('open_time'),
                       lambda d: d['witnesses']['quote'].update(owner_epoch='other'),
                       lambda d: d['witnesses']['quote'].update(payload_sha256='0'*64),
                       lambda d: d['quote']['events'][1].update(seq=4),
                       lambda d: d['brti_source'].update(value=80021),
                       lambda d: d['context'].update(ticker='other')):
            docs, m = fixture_v2(); change(docs)
            self.assertFalse(convert((docs, m))[2]['converted_records'])
        swapped = deepcopy(mappings[0]); swapped['witnesses'] = mappings[1]['witnesses']
        self.assertFalse(adapt(a, [swapped])['converted_records'])

    def test_submillisecond_order_duplicates_conflicts_restart_and_rollover(self):
        a, maps, r = convert(fixture_v2(1), fixture_v2(2, kind='FINAL_EVIDENCE'), fixture_v2(3, kind='FINAL_EVIDENCE'))
        self.assertFalse(r['adapter_rejections']); self.assertFalse(r['replay']['rejections'])
        self.assertEqual(adapt(a, maps+maps)['replay']['duplicate_count'], 3)
        self.assertEqual(adapt(a, [maps[0], maps[2], maps[1]])['replay']['rejections'][0]['reason'], 'OUT_OF_ORDER_RECORD')
        conflict = deepcopy(maps[0]); conflict['observation'] = maps[1]['observation']
        self.assertFalse(adapt(a, [maps[0], conflict])['converted_records'])
        for case, reason in ((fixture_v2(1, 1000, opened=OPEN+900000, ticker='KXBTC15M-SYNTHETIC-B', kind='FINAL_EVIDENCE'), 'ORIGIN_CONTRACT_MISMATCH'),
                             (fixture_v2(4, kind='FINAL_EVIDENCE'), 'OWNER_RESTART_LINK_UNDEFINED')):
            if reason.startswith('OWNER'):
                case[0]['context']['native_owner_epoch'] = 'restart'
            m = add_micro(a, *case, reason)
            self.assertEqual(adapt(a, maps+[m])['replay']['rejections'][0]['reason'], reason)
        changed, cm = fixture_v2(4, kind='FINAL_EVIDENCE')
        for field in ('received_utc', 'validated_utc', 'witnessed_utc'):
            changed['witnesses']['brti'][field] = '2020-01-01T00:01:59.500112+00:00'
        conflict_map = add_micro(a, changed, cm, 'changed-receipt')
        self.assertEqual(adapt(a, maps + [conflict_map])['replay']['rejections'][0]['reason'],
                         'SOURCE_PROOF_IDENTITY_CONFLICT')
        # The same explicit FINAL evidence can refer to two explicit independent
        # origins without creating a new signal or changing its evidence payload.
        a2, m2, _ = convert(fixture_v2(1), fixture_v2(2, entry='e2'), fixture_v2(3, kind='FINAL_EVIDENCE'))
        second_link = deepcopy(m2[2]); second_link['entry_id'] = 'e2'
        linked = adapt(a2, m2 + [second_link])
        self.assertFalse(linked['replay']['rejections'])
        self.assertEqual([len(l['final_evidence']) for l in linked['replay']['lifecycles']], [1, 1])
        docs, m = fixture_v2(999, 899899)
        self.assertFalse(convert((docs, m))[2]['adapter_rejections'])
        docs['observation']['observed_utc'] = '2020-01-01T00:15:00.000000+00:00'
        self.assertFalse(convert((docs, m))[2]['converted_records'])

    def test_source_expiry_completed_publication_and_exact_precision(self):
        for suffix, accepts in (('000000', True), ('000001', False)):
            docs, m = fixture_v2(); docs['observation']['observed_utc'] = f'2020-01-01T00:02:04.{suffix}+00:00'
            self.assertEqual(bool(convert((docs, m))[2]['converted_records']), accepts)
        for change in (lambda d: d['context'].update(completed_publication_utc='2020-01-01T00:02:00.101000+00:00'),
                       lambda d: d['context'].update(completed_publication_utc=None),
                       lambda d: d['context']['consumption_completed_utc'].update(quote='2020-01-01T00:02:00.0041911+00:00'),
                       lambda d: d['context']['consumption_completed_utc'].update(brti='2020-01-01T00:02:00.000190+00:00')):
            docs, m = fixture_v2(); change(docs)
            self.assertFalse(convert((docs, m))[2]['converted_records'])


if __name__ == '__main__':
    unittest.main()
