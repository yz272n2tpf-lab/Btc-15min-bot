"""Exact-clock regressions only; synthetic 2020 evidence, no policy selection."""
from copy import deepcopy
from datetime import datetime, timedelta
from decimal import Decimal
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from early_origin_replay import canonical, replay, timestamp
from pr36_evidence_adapter import Archive, adapt, evidence_json, ms, parse, sha, wire_ms
from test_pr36_evidence_adapter import OPEN, fixture


def micro_fixture(us=191, delta=120000, **kwargs):
    docs, mapping = fixture(delta=delta, **kwargs)
    def iso(value):
        return (datetime.fromisoformat(value) + timedelta(microseconds=us)).isoformat(timespec='microseconds')
    for name, keys in {
        'observation': ['observed_utc', 'source_timestamp_utc'],
        'fair': ['decision_utc', 'btc_source_utc', 'btc_observed_utc'],
        'quote': ['source_time'], 'brti_delivery': ['decision_utc'],
        'context': ['decision_utc', 'published_utc', 'quote_received_utc'],
    }.items():
        for key in keys:
            docs[name][key] = iso(docs[name][key])
    docs['observation']['parity']['timestamp_utc'] = iso(docs['observation']['parity']['timestamp_utc'])
    # Exchange/BRTI publications stay at their original millisecond clocks.
    # Decision, native receipts and BTC clocks carry genuine microseconds.
    delivery = docs['brti_delivery']['delivery']
    for key in ('observed_ts', 'decision_ts', 'checked_ts'):
        # The same preserved publication must retain the same original receipt.
        offset = 111 if key == 'observed_ts' else us
        delivery[key] = Decimal(str(delivery[key])) + Decimal(offset) / 1000000
    docs['brti_delivery']['source_ts'] = Decimal(str(docs['brti_delivery']['source_ts']))
    age = Decimal(1) + Decimal(us) / 1000000
    docs['brti_delivery']['age_at_decision'] = delivery['current_age'] = age
    docs['observation']['market']['brti_age_seconds'] = age
    docs['context']['decision_id'] += f'-us{us}'
    if mapping['evidence_id'] is not None:
        mapping['evidence_id'] += f'-us{us}'
    return docs, mapping


def add_micro(archive, docs, mapping, label):
    mapping = deepcopy(mapping)
    for name, row in docs.items():
        raw = evidence_json(row).encode()
        key = label + '-' + name
        archive.add(key, raw, sha(raw), role='observations' if name == 'observation' else 'evidence')
        mapping[name] = dict(artifact=key, row=0)
    return mapping


class MicrosecondReplayTests(unittest.TestCase):
    def converted(self, *fixtures):
        archive = Archive()
        mappings = [add_micro(archive, *f, str(i)) for i, f in enumerate(fixtures)]
        return archive, mappings, adapt(archive, mappings)

    def test_exact_all_clock_fields_archive_and_cli_round_trip(self):
        docs, mapping = micro_fixture()
        original = evidence_json(docs)
        archive, mappings, result = self.converted((docs, mapping), micro_fixture(192, kind='FINAL_EVIDENCE'))
        self.assertFalse(result['adapter_rejections']); self.assertFalse(result['replay']['rejections'])
        row = result['converted_records'][0]
        for name, value in [('entry_ts_ms', OPEN + 120000), ('observed_ts_ms', OPEN + 120100)]:
            self.assertEqual(row[name], f'{value}.191')
            self.assertEqual(timestamp(row[name]), value * 1000 + 191)
        self.assertEqual(row['native']['decision_ts_ms'], f'{OPEN + 120000}.191')
        self.assertEqual(row['native']['published_ts_ms'], f'{OPEN + 120050}.191')
        for name in ('quote', 'btc'):
            self.assertEqual(row['sources'][name]['receipt_ts_ms'], f'{OPEN + 119500}.191')
        self.assertEqual(row['sources']['brti']['receipt_ts_ms'], f'{OPEN + 119500}.111')
        self.assertEqual(row['sources']['btc']['source_ts_ms'], f'{OPEN + 119000}.191')
        self.assertEqual(row['sources']['quote']['source_ts_ms'], OPEN + 119000)
        self.assertEqual(row['sources']['brti']['source_ts_ms'], OPEN + 119000)
        self.assertEqual(archive.get(mappings[0]['observation'])['source_timestamp_utc'],
                         docs['observation']['source_timestamp_utc'])
        self.assertEqual(archive.get(mappings[0]['brti_delivery'])['delivery']['decision_ts'],
                         Decimal('1577836920.000191'))
        # Exact UTC conversion, including offsets, does not use POSIX float time.
        self.assertEqual(ms('2020-01-01T05:32:00.000191+05:30'), ms('2020-01-01T00:02:00.000191Z'))
        self.assertEqual(evidence_json(docs), original)
        with tempfile.TemporaryDirectory() as tmp:
            source, output = Path(tmp)/'input.jsonl', Path(tmp)/'output.json'
            source.write_text('\n'.join(canonical(r) for r in result['converted_records']))
            subprocess.run([sys.executable, str(Path(__file__).with_name('early_origin_replay.py')),
                            str(source), '--output', str(output)], check=True, capture_output=True)
            self.assertEqual(json.loads(output.read_text()), result['replay'])
        frozen = replay(result['converted_records'])
        row['entry_ts_ms'] = '0.001'
        self.assertEqual(frozen.lifecycles[0].origin.to_dict()['entry_ts_ms'], f'{OPEN + 120000}.191')

    def test_one_microsecond_order_duplicates_and_conflicts_are_not_collapsed(self):
        archive, mappings, result = self.converted(micro_fixture(1), micro_fixture(2, kind='FINAL_EVIDENCE'),
                                                 micro_fixture(3, kind='FINAL_EVIDENCE'))
        self.assertFalse(result['adapter_rejections']); self.assertFalse(result['replay']['rejections'])
        life = result['replay']['lifecycles'][0]
        self.assertEqual([r['native']['decision_ts_ms'] for r in life['final_evidence']],
                         [f'{OPEN + 120000}.002', f'{OPEN + 120000}.003'])
        self.assertEqual(canonical(adapt(archive, mappings)), canonical(result))
        reversed_result = adapt(archive, [mappings[0], mappings[2], mappings[1]])
        self.assertEqual(reversed_result['replay']['rejections'][0]['reason'], 'OUT_OF_ORDER_RECORD')
        self.assertEqual(adapt(archive, mappings + mappings)['replay']['duplicate_count'], 3)
        rows = deepcopy(result['converted_records'])
        conflict = deepcopy(rows[0]); conflict['observed_ts_ms'] = f'{OPEN + 120100}.002'
        self.assertEqual(replay(rows + [conflict]).rejections[0].reason, 'CONFLICTING_RECORD_IDENTITY')
        simultaneous = deepcopy(rows[1]); simultaneous['native']['decision_ts_ms'] = rows[0]['entry_ts_ms']
        simultaneous['sources'] = deepcopy(rows[0]['sources'])
        self.assertEqual(replay([rows[0], simultaneous]).rejections[0].reason, 'FINAL_NOT_SUBSEQUENT_TO_ORIGIN')
        changed_receipt = deepcopy(rows[1])
        changed_receipt['sources']['brti']['receipt_ts_ms'] = f'{OPEN + 119500}.112'
        self.assertEqual(replay([rows[0], changed_receipt]).rejections[0].reason,
                         'SOURCE_PROOF_IDENTITY_CONFLICT')

    def test_microsecond_causality_join_and_expiry_boundaries(self):
        mutations = [
            (lambda d: d['fair'].update(decision_utc='2020-01-01T00:02:00.000192+00:00'), 'EXACT_DECISION_JOIN_REQUIRED'),
            (lambda d: d['fair'].update(btc_observed_utc='2020-01-01T00:02:00.000192+00:00'), 'Noncausal clocks'),
            (lambda d: d['brti_delivery']['delivery'].update(observed_ts=Decimal('1577836920.000192')), 'SOURCE_NOT_CAUSALLY_AVAILABLE'),
            (lambda d: d['context'].update(quote_received_utc='2020-01-01T00:02:00.000192+00:00'), 'SOURCE_NOT_CAUSALLY_AVAILABLE'),
            (lambda d: d['observation'].update(observed_utc='2020-01-01T00:02:04.000001+00:00'), 'SOURCE_EXPIRED_AT_OBSERVATION'),
        ]
        for change, reason in mutations:
            with self.subTest(reason=reason):
                docs, mapping = micro_fixture(); change(docs)
                _, _, result = self.converted((docs, mapping))
                self.assertFalse(result['converted_records'])
                self.assertEqual(result['adapter_rejections'][0]['reason'], reason)
        docs, mapping = micro_fixture()
        docs['observation']['observed_utc'] = '2020-01-01T00:02:04.000000+00:00'
        self.assertFalse(self.converted((docs, mapping))[2]['adapter_rejections'])

    def test_last_microsecond_rollover_and_official_window_isolation(self):
        docs, mapping = micro_fixture(999, delta=899899)
        archive, mappings, result = self.converted((docs, mapping))
        self.assertFalse(result['adapter_rejections'])
        self.assertEqual(result['converted_records'][0]['observed_ts_ms'], f'{OPEN + 899999}.999')
        docs['observation']['observed_utc'] = '2020-01-01T00:15:00.000000+00:00'
        self.assertFalse(self.converted((docs, mapping))[2]['converted_records'])
        rollover = micro_fixture(1, delta=1000, opened=OPEN + 900000, ticker='KXBTC15M-SYNTHETIC-B', kind='FINAL_EVIDENCE')
        next_mapping = add_micro(archive, *rollover, 'rollover')
        result = adapt(archive, mappings + [next_mapping])
        self.assertFalse(result['adapter_rejections'])
        self.assertEqual(result['replay']['rejections'][0]['reason'], 'ORIGIN_CONTRACT_MISMATCH')
        self.assertEqual(result['replay']['lifecycles'][0]['final_evidence'], [])
        docs, mapping = micro_fixture(); docs['contract']['close_time'] = '2020-01-01T00:15:00.000001+00:00'
        self.assertEqual(self.converted((docs, mapping))[2]['adapter_rejections'][0]['reason'], 'CONTRACT_WINDOW')

    def test_precision_does_not_supply_missing_or_ambiguous_provenance(self):
        archive, mappings, _ = self.converted(micro_fixture(), micro_fixture(192, kind='FINAL_EVIDENCE'))
        result = adapt(archive, [])
        self.assertEqual(len(result['unmapped_observations']), 2)
        self.assertEqual(result['converted_records'], [])
        self.assertEqual(adapt(archive, [mappings[1]])['replay']['rejections'][0]['reason'], 'UNKNOWN_EARLY_ORIGIN')
        missing = deepcopy(mappings[0]); missing['quote']['artifact'] = 'absent'
        self.assertEqual(adapt(archive, [missing])['adapter_rejections'][0]['reason'], 'MISSING_REFERENCED_EVIDENCE')
        alias = deepcopy(mappings[0]); alias['entry_id'] = 'guessed-origin'
        result = adapt(archive, [mappings[0], alias])
        self.assertEqual(result['converted_records'], [])
        self.assertTrue(all(r['reason'] == 'AMBIGUOUS_ORIGIN_MAPPING' for r in result['adapter_rejections']))
        docs, mapping = micro_fixture(); del docs['context']['native_owner_epoch']
        self.assertEqual(self.converted((docs, mapping))[2]['converted_records'], [])
        docs, mapping = micro_fixture(); docs['context']['quote_received_utc'] = None
        self.assertEqual(self.converted((docs, mapping))[2]['converted_records'], [])

    def test_unsupported_precision_never_truncates_or_uses_float_rounding(self):
        for raw in ('2020-01-01T00:02:00.0001911Z', '2020-01-01T00:02:00.000191+00:00:00.000001'):
            with self.assertRaisesRegex(ValueError, 'EXACT_MICROSECOND_ISO_REQUIRED'):
                ms(raw)
        for raw in (float(OPEN), f'{OPEN}.0001', True):
            with self.assertRaisesRegex(ValueError, 'TIMESTAMP_REQUIRED_EXACT_MS'):
                timestamp(raw)
        with self.assertRaisesRegex(ValueError, 'EXACT_MICROSECOND_CLOCK_REQUIRED'):
            wire_ms(Fraction(1, 10000))
        docs, mapping = micro_fixture()
        # These would compare equal if first parsed as IEEE-754 epoch floats.
        value = Decimal('1577836920.00019101')
        self.assertEqual(float(value), float(Decimal('1577836920.000191')))
        docs['brti_delivery']['delivery']['decision_ts'] = value
        archive, mappings, result = self.converted((docs, mapping))
        self.assertEqual(archive.get(mappings[0]['brti_delivery'])['delivery']['decision_ts'], value)
        self.assertEqual(result['adapter_rejections'][0]['reason'], 'SUBMICROSECOND_CLOCK_NOT_REPRESENTABLE')
        self.assertEqual(parse(evidence_json(docs))['brti_delivery']['delivery']['decision_ts'], value)


if __name__ == '__main__':
    unittest.main()
