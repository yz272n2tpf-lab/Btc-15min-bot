# Authentic EARLY→FINAL capture gate — 2026-09-25

Parent: `e451081b77f2c4b8ecaae19bd1d6da1e9bbe9ea3`.
Result: **BLOCKED at evidence completeness; no authentic bundle obtained.**
No production mutation, new collector, synthetic bundle, adapter modification,
test rerun, scoring or policy selection. SIGNAL ONLY / NO ORDERS.

## Inspected producers

This pass inspected PR36 source and the already-preserved deployed source copies
for the retained collectors. Their recorded deployment pins were reused, not
re-investigated. Two bounded, unauthenticated GETs to the existing main dashboard
and fair-input manifest each timed out after approximately five seconds. There
were no retries or authentication attempts. Consequently this is a producer/schema
determination, not a claim that current remote archives were downloaded or that
every live deployment identity was freshly verified.

| Producer | Evidence actually emitted | Missing requirement |
|---|---|---|
| PR36 `record_model_input` / fair-input journal | Exact decision/BTC source/receipt ISO times, ticker, target, features and model hashes | Native owner generation, decision ID, committed publication time, official window, origin and FINAL link |
| PR36 `Provider.consume` quote proof | Exact consumed event tape, connection epoch, market/SID/sequence/source timestamp, consumption clock, decision label | Per-event local receipt clocks; history is overwritten by the next consumed proof, not a durable per-decision journal |
| PR36 `BRTI DELIVERY` stdout | Selected source and native receipt/decision/check fields, readiness and owner epoch | Original matching shared-owner response is not preserved by the native delivery record; numeric clocks/ages use binary float |
| Main qualified-forward observer | Raw EARLY/FINAL flags, market, parity, source/observation times and qualification flags | Full native context, official window, immutable origin and explicit FINAL linkage; no source event tape |
| Main FINAL protection telemetry | `FINAL_TRIGGER` and `POST_FINAL` against its own FINAL origin | No EARLY origin or EARLY management linkage; remains shadow-only |
| Retained clean SCALP common observer (`e98576f…`) | Durable independent HTTP responses from main, shared BRTI, V8.1 and generalized SCALP | Its observer epoch is not native ownership; independent BRTI sampling is not proof of native consumption; dashboard lacks native context and quote tape |
| Retained generalized SCALP (`0d69832…`) | Its own SCALP tape/serial lifecycle plus protected main presentation | Not the main EARLY owner; independent SCALP source proofs cannot stand in for native PR36 proofs |
| Retained EARLY→FINAL handoff (`cb05a53…`) | First protected EARLY and first protected FINAL per eligible contract, in separate RAM maps | `_early_record` / `_final_record` retain observer times, side, ask/fair and time-left, but drop native source time and context. Same-contract membership does not prove subsequent FINAL or a native entry. `/state` returns summaries, not complete RAM evidence |
| Retained EARLY excursion (`54cf41e…`) | First observed EARLY, observed FINAL and excursions | `entry_at_utc` is observer time, not native decision time; lacks source proof/context |
| Retained combined / FINAL / coverage scorecards | Coverage and first-observed predictions, quotes, path/settlement research | Cannot supply fields absent from their main dashboard input; their cohort/collector identities are not native decision/origin identities |
| Retained V8.1 | Its own entry and source provenance | Explicitly separate ownership; cannot relabel a V8.1 origin as EARLY |

The accompanying JSON records source-file SHA-256 identities and inspected anchors.
No score or outcome was used to select an example. No remote result was called
complete merely because a collector retains a same-contract EARLY and FINAL.

## Why an external collector/config-only change is insufficient

The current native stream has eligibility observations, not a durable primary
EARLY entry with an explicit FINAL pointer. The replay contract permits an
explicitly identified **offline observation origin**, not an inferred fill or new
action entry. A future capture must say which existing observed EARLY record it
identifies and persist that linkage when observed. It cannot retroactively label
a collector's timestamp as the native entry time.

Two further capture constraints are visible in the frozen source:

1. In `bot_two_output_build_v4_13_profit_protection_shadow.py`, `decision_time(...)`
   runs before `consume_ws_quotes(...)`. The proof's `consumed_ms` is sampled in
   `Provider.consume`. A consumption after the cutoff does not establish validation
   or receipt before the cutoff. The existing adapter requires quote receipt and
   validation at/before the native decision. Merely copying the existing latest
   proof will not guarantee admission. This is a static capture/causality constraint,
   not a demonstrated live future-source acceptance in this pass. Do not move the
   native cutoff, backdate consumption or weaken replay to make a bundle pass.
2. `Delivery.select` stores float seconds and subtraction ages. The exact adapter
   rejects non-microsecond numeric values and disagreement with the original ISO
   cutoff. Passive capture must retain these original log values verbatim. It must
   not round them or recalculate replacements and present those replacements as
   the original native delivery record. A new exact capture-time channel would
   need explicit provenance, not silent conversion of old telemetry.

Therefore there is **no supported existing switch** that turns these producers
into the seven-record adapter bundle. A journal-only/export-only patch is not a
complete solution. No runnable capture patch is claimed implemented or qualified
by this checkpoint, and enabling an imagined environment variable is not proposed.

## Minimum prospective patch required before a production authorization

The following is the concrete required patch scope, not an installed patch. It
is intentionally confined to existing owners and the existing main observer;
no additional service or authenticated upstream request is needed.

| File / capture point | Required passive change |
|---|---|
| `btc15_kalshi_quote_provenance_v1.py`, `Provider.session` immediately after successful event acceptance | Retain bounded immutable evidence of actual local receipt/validation time, epoch and complete book identity. Keep native book selection untouched. At native consumption, bind the exact consumed identity to that already-existing witness. If its witness is after the cutoff or missing, capture rejection; do not select an older book for strategy use. |
| `btc15_brti_shared_consumer_v1.py`, existing `/state` response; native `_collect_brti_once` and `_brti_contract_snapshot` | Retain the exact existing response and actual receipt witness, and bind the selected delivery by owner epoch/source timestamp/value. Preserve original float telemetry beside any separately witnessed exact clocks. No extra fetch or inferred receipt. The writer/adapter format boundary must be made explicit before deployment; current incompatible values must remain rejected. |
| Native `decision_time`, `record_model_input`, and completed native publication | Copy official market `ticker/open_time/close_time/floor_strike`, exact decision and BTC clocks, model frame and selected source identities into one immutable evidence envelope. Record genuine capture/native process generations and a decision identity at production, not later. Record actual publication after completion, never renderer generation or decision time as its substitute. Include both frozen strategy identity and the actual instrumentation release identity without mislabeling the deployed commit as PR36. |
| `btc15_qualified_forward_observer_v1.py`, existing observation append | Persist a separate observation-origin record and explicit later-FINAL reference only with the matching complete native envelope and existing native flags. Keep it labeled offline evidence, not an entry/advice/lifecycle event. No latest-frame substitution, new eligibility rule, protection call, persistence hit or implicit relationship. The original CSV and native/collector state remain untouched. |
| New private evidence journal/export on main's existing `/data` | Nonblocking bounded handoff; storage or queue failure records capture-unavailable and drops evidence, never delays native processing. Preserve all rejected attempts in order. Stop after one complete explicitly linked bundle or a fixed bounded capture window/storage budget, whichever occurs first. Restart/rollover cannot link across generations/contracts. No public secret export, new owner or service. |

The capture identity/linkage is an observational record only. It must not create
the missing product lifecycle, adopt a shadow policy, or claim an actual user fill.
If a complete pair cannot be witnessed under frozen clocks, stop with that
rejection. Passive instrumentation is not permission to repair native source
selection or alter the adapter's causal contract.

**Deployment action required:** after an actual capture-only patch and its focused
noninterference/format gates are prepared and reviewed, deploy that specifically
pinned PR36-derived instrumentation release to the existing main service and
restart its existing supervisor/observer chain once, preserving `/data`, current
variables and the original PR36 rollback. This changes the deployed artifact
identity even if strategy code remains frozen, so it requires separate explicit
authorization. No deployment/configuration action is authorized or performed here.
Do not deploy the two-clock candidate as a means of obtaining evidence.

## Result and next action

- Bundle identity/hash, EARLY/FINAL timestamps and contract linkage: **not obtained**.
- Admission: **REJECTED at evidence-completeness preflight**; no fabricated mapping
  was submitted to replay. No claim that the adapter ran a nonexistent bundle.
- Existing 29/29 acceptance remains preserved; replay/adapter/tests are byte-identical
  to the parent. Only source/schema checks and the two bounded GET attempts ran.
- **One next action:** prepare and qualify the capture-only native/observer patch
  above for separate deployment authorization. No collector-only export can fill
  the absent native evidence, and no deployment-ready patch is claimed here.

PR36 strategy behavior/models/thresholds and the undeployed two-clock candidate
remain unchanged. Core NOT_LINKED, FINAL shadow-only, false shadow-protection
action authority and V8.1 ownership are not promoted. SIGNAL ONLY / NO ORDERS.
