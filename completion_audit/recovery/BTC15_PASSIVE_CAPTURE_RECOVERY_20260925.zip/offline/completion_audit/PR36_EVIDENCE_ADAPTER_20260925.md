# PR36 preserved-evidence adapter — local checkpoint, 2026-09-25

Parent: `db3c122ffa785abb179d18615a4355402e0c7844`.
Scope: read-only conversion and exact linkage, no cohort scoring or policy selection.
SIGNAL ONLY / NO ORDERS. Production PR36 and the undeployed two-clock candidate
are unchanged. The existing origin harness and its 14 tests are unchanged.

## Implemented input path

`pr36_evidence_adapter.py` reads immutable local JSON, JSONL and the exact
`btc15_qualified_forward_v1.csv` envelope. Every input artifact requires its
expected SHA-256. Duplicate JSON fields, ambiguous artifact IDs, invalid hashes,
CSV/payload identity conflicts and unsupported formats fail before output.
Files are never rewritten. No API, network, database or production process is used.

A manifest has exactly `artifacts` and `mappings`. Each artifact specification has
`id`, `path` (relative to the manifest or absolute local path), `sha256`, `format`
(`json`, `jsonl`, `qualified_csv`), and `role` (`observations` or `evidence`).
References have exactly `artifact` and zero-based `row`. JSON has row 0; JSONL
uses nonblank record order; CSV uses data-row order. Whole-file hashes pin these
indices against changed exports or append tails.

Each explicit mapping has `record_type` (`EARLY_ORIGIN` or `FINAL_EVIDENCE`),
`entry_id`, `evidence_id` (null for origins), and these seven references:

| Reference | Preserved evidence required |
|---|---|
| `observation` | Version-1 qualified-forward OBSERVATION with original source/observation clocks, raw EARLY/FINAL lane, eligibility flags, market and parity. A raw dashboard response alone is not this record. |
| `fair` | Exact `BTC15_FAIR_INPUT_V1` frame, including true BTC source/receipt clocks, target and frozen weight/artifact hashes. Existing PR36 validation is reused; the model is never loaded or evaluated. |
| `quote` | Exact consumed quote proof, including exchange snapshot/deltas, connection epoch, sequence/timestamp identity and consumption clock. Existing PR36 quote replay reconstructs the four quotes and requires an exact market match. Parity prose is not a proof substitute. |
| `brti_delivery` | Exact `BTC15_BRTI_DELIVERY_V1` native log record with source/receipt/decision/check clocks, readiness and owner epoch. |
| `brti_source` | Matching archived shared-owner schema-2 BRTI publication: source timestamp, value, epoch and qualified status. No nearest/latest publication substitution. |
| `contract` | Official `ticker`, `open_time`, `close_time`, `floor_strike`. The dashboard's rounded source-time-plus-remaining timer is never used as official contract metadata. |
| `context` | Explicitly preserved native metadata: `runtime_commit`, `run_id`, `native_owner_epoch`, `btc_owner_epoch`, `decision_id`, `decision_utc`, `published_utc`, `ticker`, `early_policy_id`, `final_policy_id`, `quote_received_utc`, `signal_only`, `orders`. Missing fields are rejected. |

The context is a required **evidence record**, not permission to supply guessed
metadata or backfill a new production origin. No existing PR36 writer of that
complete context was identified. This adapter neither creates it nor treats a
deployment ID, renderer generation time or file timestamp as a substitute.
An explicit `entry_id` remains an offline replay-case identifier, not a claim of
an actual user fill, native entry birth or approved re-entry policy.

All seven records must match the exact native decision, contract, fixed target,
source values and pinned model. Gates are read, never recalculated or optimized.
EARLY ask/time come from that mapped original observation. FINAL probability is
the recorded confidence expressed as UP probability (1-confidence for DOWN);
FINAL evidence links only to the explicitly named origin. A false FINAL ready
flag can remain a source-qualified deterioration observation without advice.

Identical duplicate mappings/observations are retained and deduplicated by the
existing harness. Conflicting mappings for an origin/evidence identity are all
rejected; one native EARLY observation cannot acquire multiple origin identities.
Unmapped observations remain explicitly listed. Output retains mapping/artifact
lineage, conversion rejections and the unchanged harness's rejection ledger.
`converted_records` means passed adapter checks; the `replay` result determines
which records passed lifecycle linkage. No rejected record becomes an event.

## Real-evidence admission boundary

Supported real formats now have a deterministic route into the harness **only
when the complete matching evidence and explicit mappings exist**. No real
EARLY/FINAL pair was admitted or scored in this run.

A narrow compatibility read of the already-preserved
`cost-cleanup/main_state.json` (outside the repository) showed:

- It is a raw PR36 dashboard capture, not a qualified-forward observer record.
  Both its EARLY and FINAL ready flags are false; it cannot establish an entry.
- It has no durable EARLY origin, native decision ID/owner generation,
  native publication context, or inline complete exchange-event quote proof.
  Parity notes contain an identity but do not contain the replayable event tape.
- Its timer explicitly uses `source_timestamp_plus_logged_remaining`, not an
  official exact open/close record.
- Its source timestamp `2026-09-25T04:09:21.246191+00:00` has microsecond precision.
  The existing origin harness accepts integer milliseconds. The adapter rejects
  `SUBMILLISECOND_CLOCK_NOT_REPRESENTABLE`; it never truncates, rounds, moves a
  receipt backward or extends a freshness boundary to manufacture compatibility.

The preserved fair-input writer records BTC/model provenance, but those rows
alone omit EARLY origin/owner, FINAL relationship and complete quote/BRTI proof.
No complete qualified-forward CSV, fair-input JSONL or quote-proof JSON artifact
was found by the narrow local filename check. This is not a claim that production
does not retain them elsewhere; no remote retrieval or archival investigation was
performed. Old scorecards, bare ready flags, derived clocks, latest source states,
missing context and cross-contract/ambiguous matches remain unusable as entries.

Artifact hashes prove local byte integrity, not external authenticity. The adapter
replays actual quote proof contents and checks source linkage; it does not certify
an archive's origin beyond its supplied capture provenance or prove a manual fill.
The supplemental complete contexts in tests are explicitly synthetic fixtures,
not purported recovered PR36 evidence.

## Verification and use

9 focused adapter tests pass, plus the unchanged 14 origin tests (23/23).
Fixtures use January 2020 only. Tests cover actual writer schemas, byte hashes,
CSV envelopes, proof replay/gaps, explicit/ambiguous/unmapped links, duplicates,
rollover, future receipts, expiry, precision rejection, deterministic conversion,
read-only loading and preservation of undefined advice. The imported quote/fair
validators are byte-identical to PR36. No unrelated suites were run.

```sh
python3 completion_audit/pr36_evidence_adapter.py MANIFEST.json --output NEW_REPORT.json
```

Output is created exclusively and cannot overwrite an existing report. Input
records are not reordered or repaired. See the acceptance JSON for counts and
file identities. The code and acceptance checkpoint remain local; no GitHub push
or authentication was attempted.

**Single minimum next ladder action:** make the offline replay timestamp
representation lossless for PR36's microsecond clocks, preserving all existing
identity, causal and freshness checks. This is a representation correction, not
entry/advice policy or a change to PR36. Missing proof/context requirements still
remain blockers afterward; they must never be filled by inference.

The separate two-clock live-acceptance requirement is unchanged. This adapter
adds no information authority, entry, advice, exit, re-entry, model change,
threshold, scoring result, production integration or deployment.
