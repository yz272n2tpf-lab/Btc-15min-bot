"""Offline EARLY origin / FINAL evidence linkage; no entry or advice policy.

Inputs are explicit, normalized records of frozen native observations. This
module does not turn a dashboard ready flag into an entry, choose an origin,
recompute qualification, infer fills, or connect to any production process.
See EARLY_ORIGIN_REPLAY_20260925.md for the input and trust boundary.
"""
from dataclasses import dataclass
import hashlib
import json
import math
import re

SCHEMA = 'BTC15_EARLY_ORIGIN_REPLAY_V1'
PR36 = '3e552065e34a0a402bc3ca4598b57dff1f1c6e77'
UNDEFINED = 'UNDEFINED_POLICY_REQUIRES_VALIDATION'
# Existing source ceilings, not predictive parameters: shared BRTI 5s,
# btc15_kalshi_quote_provenance_v1.MAX_AGE 6s, native BTC freshness 10s.
MAX_AGE_MS = {'brti': 5000, 'quote': 6000, 'btc': 10000}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def exact(value, fields):
    require(type(value) is dict and set(value) == set(fields.split()), 'SCHEMA_FIELDS')


def string(value):
    require(type(value) is str and bool(value.strip()), 'MISSING_IDENTITY')


def timestamp(value):
    """Exact microseconds for comparisons; never rewrite the recorded value.

    Wire clocks retain millisecond units: legacy nonnegative integers, or
    decimal strings with exactly three fractional digits (one microsecond).
    JSON floats are deliberately unsupported for epoch timestamps.
    """
    if type(value) is int and value >= 0:
        return value * 1000
    require(type(value) is str and re.fullmatch(r'(0|[1-9][0-9]*)\.[0-9]{3}', value),
            'TIMESTAMP_REQUIRED_EXACT_MS')
    whole, fraction = value.split('.')
    return int(whole) * 1000 + int(fraction)


def number(value, low, high=math.inf):
    require(type(value) in (int, float) and math.isfinite(value)
            and low <= value <= high, 'INVALID_NUMERIC_VALUE')


def validate(row):
    common = ('schema record_type entry_id run_id side native contract model_id '
              'policy_id native_gate_passed observed_ts_ms sources signal_only orders ')
    kind = row.get('record_type') if type(row) is dict else None
    require(kind in ('EARLY_ORIGIN', 'FINAL_EVIDENCE'), 'UNSUPPORTED_RECORD_TYPE')
    exact(row, common + ('entry_ts_ms entry_price' if kind == 'EARLY_ORIGIN'
                        else 'evidence_id probability_up'))
    require(row['schema'] == SCHEMA, 'SCHEMA_VERSION')
    require(row['signal_only'] is True and row['orders'] is False, 'SIGNAL_ONLY_REQUIRED')
    require(row['side'] in ('UP', 'DOWN'), 'SIDE_REQUIRED')
    require(type(row['native_gate_passed']) is bool, 'NATIVE_GATE_REQUIRED')
    for key in ('entry_id', 'run_id', 'model_id', 'policy_id'):
        string(row[key])
    n, c = row['native'], row['contract']
    exact(n, 'authority runtime_commit owner_epoch decision_id decision_ts_ms published_ts_ms')
    require(n['authority'] == 'AUTHORITATIVE_ACTION_STATE' and n['runtime_commit'] == PR36,
            'FROZEN_NATIVE_AUTHORITY_REQUIRED')
    string(n['owner_epoch']); string(n['decision_id'])
    exact(c, 'ticker open_ts_ms close_ts_ms target')
    string(c['ticker']); number(c['target'], 0)
    require(c['target'] > 0, 'TARGET_REQUIRED')
    decision, published, observed, opened, closed = map(timestamp, (
        n['decision_ts_ms'], n['published_ts_ms'], row['observed_ts_ms'],
        c['open_ts_ms'], c['close_ts_ms']))
    require(opened % 900000000 == 0 and closed - opened == 900000000,
            'CONTRACT_WINDOW')
    require(opened <= decision <= published <= observed < closed, 'NONCAUSAL_OR_CLOSED_CONTRACT')
    exact(row['sources'], 'quote brti btc')
    for name, ceiling in MAX_AGE_MS.items():
        source = row['sources'][name]
        exact(source, 'proof_id owner_epoch source_ts_ms receipt_ts_ms qualified ' +
              ('ticker validated_ts_ms up_ask down_ask' if name == 'quote' else 'value'))
        string(source['proof_id']); string(source['owner_epoch'])
        require(source['qualified'] is True, 'SOURCE_UNQUALIFIED')
        sourced, received = map(timestamp, (source['source_ts_ms'], source['receipt_ts_ms']))
        require(sourced <= received <= decision,
                'SOURCE_NOT_CAUSALLY_AVAILABLE')
        require(0 <= observed - sourced <= ceiling * 1000,
                'SOURCE_EXPIRED_AT_OBSERVATION')
        if name == 'quote':
            validated = timestamp(source['validated_ts_ms'])
            require(source['ticker'] == c['ticker'], 'QUOTE_TICKER_MISMATCH')
            require(opened <= sourced <= received <= validated <= decision, 'QUOTE_PROVENANCE_TIME')
            number(source['up_ask'], 0, 1); number(source['down_ask'], 0, 1)
        else:
            number(source['value'], 0)
            require(source['value'] > 0, 'SOURCE_VALUE_REQUIRED')
    if kind == 'EARLY_ORIGIN':
        entered = timestamp(row['entry_ts_ms']); number(row['entry_price'], 0, 1)
        require(row['native_gate_passed'] is True, 'EARLY_NATIVE_ELIGIBILITY_REQUIRED')
        require(entered == decision, 'ENTRY_TIMESTAMP_DRIFT')
        require(row['entry_price'] == row['sources']['quote'][row['side'].lower() + '_ask'],
                'ENTRY_PRICE_PROVENANCE_MISMATCH')
    else:
        string(row['evidence_id']); number(row['probability_up'], 0, 1)


@dataclass(frozen=True)
class Record:
    """Deep immutability via canonical JSON, including all source provenance."""
    json: str

    def to_dict(self):
        return json.loads(self.json)


@dataclass(frozen=True)
class Lifecycle:
    origin: Record
    final_evidence: tuple[Record, ...] = ()

    def to_dict(self):
        return dict(origin=self.origin.to_dict(), origin_sha256=digest(self.origin.json),
                    final_evidence=[r.to_dict() for r in self.final_evidence],
                    advice_state=None, advice_policy_status=UNDEFINED,
                    reentry_policy_status=UNDEFINED, settlement_status='UNRESOLVED',
                    execution_or_fill_proven=False)


@dataclass(frozen=True)
class Rejection:
    input_index: int
    record_sha256: str
    reason: str


@dataclass(frozen=True)
class Replay:
    lifecycles: tuple[Lifecycle, ...]
    rejections: tuple[Rejection, ...]
    duplicate_count: int
    input_sha256: str

    def to_dict(self):
        return dict(schema=SCHEMA, lifecycles=[x.to_dict() for x in self.lifecycles],
                    rejections=[dict(input_index=x.input_index, record_sha256=x.record_sha256,
                                     reason=x.reason) for x in self.rejections],
                    duplicate_count=self.duplicate_count, input_sha256=self.input_sha256,
                    scope='OFFLINE_EXPLICIT_ORIGIN_LINKAGE_ONLY', production_connected=False,
                    advice_published=False, signal_only=True, orders=False)


def replay(records):
    """Consume recorded observation order. Never sort away future/late evidence.

    Explicit multiple origins are retained as independent replay cases, not
    approved re-entries. A FINAL record must name its exact EARLY entry_id.
    Unqualified/rejected evidence stays in the rejection ledger; it cannot
    provide HOLD or carry any previous assessment forward as current advice.
    """
    rows = json.loads(canonical(list(records)))  # detach caller-owned dictionaries
    lives, seen, native_seen, contracts, proof_seen = {}, {}, {}, {}, {}
    evidence_seen, policies, native_frames = {}, {}, {}
    rejected, duplicate_count, last_observed, last_decision = [], 0, -1, -1
    run_id = model_id = None
    for index, row in enumerate(rows):
        encoded = canonical(row)
        try:
            validate(row)
            kind, n, c = row['record_type'], row['native'], row['contract']
            key = (kind, row['entry_id'], row.get('evidence_id'))
            require(run_id is None or row['run_id'] == run_id, 'MIXED_RUN_IDENTITIES')
            require(model_id is None or row['model_id'] == model_id, 'MODEL_IDENTITY_CHANGED')
            require(kind not in policies or policies[kind] == row['policy_id'],
                    'FROZEN_POLICY_IDENTITY_CHANGED')
            if key in seen:
                require(seen[key] == encoded, 'CONFLICTING_RECORD_IDENTITY')
                duplicate_count += 1
                continue
            observed, decision = timestamp(row['observed_ts_ms']), timestamp(n['decision_ts_ms'])
            require(observed >= last_observed and decision >= last_decision,
                    'OUT_OF_ORDER_RECORD')
            contract_id = c['ticker']
            require(contract_id not in contracts or contracts[contract_id] == c,
                    'CONTRACT_IDENTITY_CONFLICT')
            frame_key = (n['owner_epoch'], n['decision_id'])
            frame_value = canonical(dict(native=n, contract=c, model_id=row['model_id'],
                                         sources=row['sources']))
            require(frame_key not in native_frames or native_frames[frame_key] == frame_value,
                    'NATIVE_FRAME_IDENTITY_CONFLICT')
            # Same decision cannot acquire a new origin ID or changed evidence
            # through repeated sampling. One FINAL observation may explicitly
            # reference several independent origins, retaining the same payload.
            native_key = (kind, n['owner_epoch'], n['decision_id'])
            payload = {k: v for k, v in row.items() if k not in ('entry_id', 'evidence_id')}
            native_value = (row['entry_id'] if kind == 'EARLY_ORIGIN' else row['evidence_id'],
                            canonical(payload))
            require(native_key not in native_seen or native_seen[native_key] == native_value,
                    'NATIVE_DECISION_IDENTITY_CONFLICT')
            for name, source in row['sources'].items():
                proof_key = (name, source['owner_epoch'], source['proof_id'])
                require(proof_key not in proof_seen or proof_seen[proof_key] == canonical(source),
                        'SOURCE_PROOF_IDENTITY_CONFLICT')
            if kind == 'EARLY_ORIGIN':
                life = Lifecycle(Record(encoded))
            else:
                require(row['evidence_id'] not in evidence_seen
                        or evidence_seen[row['evidence_id']] == canonical(payload),
                        'FINAL_EVIDENCE_IDENTITY_CONFLICT')
                require(row['entry_id'] in lives, 'UNKNOWN_EARLY_ORIGIN')
                prior = lives[row['entry_id']]
                origin = prior.origin.to_dict()
                require(c == origin['contract'], 'ORIGIN_CONTRACT_MISMATCH')
                require(n['owner_epoch'] == origin['native']['owner_epoch'],
                        'OWNER_RESTART_LINK_UNDEFINED')
                require(row['model_id'] == origin['model_id'], 'MODEL_IDENTITY_CHANGED')
                require(decision > timestamp(origin['entry_ts_ms'])
                        and n['decision_id'] != origin['native']['decision_id'],
                        'FINAL_NOT_SUBSEQUENT_TO_ORIGIN')
                life = Lifecycle(prior.origin, prior.final_evidence + (Record(encoded),))
            # Only fully accepted records commit replay bookkeeping.
            lives[row['entry_id']] = life
            seen[key] = encoded
            native_seen[native_key] = native_value
            native_frames[frame_key] = frame_value
            if kind == 'FINAL_EVIDENCE':
                evidence_seen[row['evidence_id']] = canonical(payload)
            policies[kind] = row['policy_id']
            contracts[contract_id] = c
            for name, source in row['sources'].items():
                proof_seen[(name, source['owner_epoch'], source['proof_id'])] = canonical(source)
            run_id = row['run_id']
            model_id = row['model_id']
            last_observed, last_decision = observed, decision
        except ValueError as exc:
            rejected.append(Rejection(index, digest(encoded), str(exc)))
    return Replay(tuple(lives.values()), tuple(rejected), duplicate_count, digest(canonical(rows)))


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'DUPLICATE_JSON_FIELD')
        result[key] = value
    return result


if __name__ == '__main__':
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path, help='Explicit normalized JSONL records; no live fetch')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    with args.input.open() as stream:
        records = [json.loads(line, object_pairs_hook=unique_object) for line in stream if line.strip()]
    result = replay(records).to_dict()
    with args.output.open('x') as stream:
        stream.write(canonical(result) + '\n')
