"""Synthetic provenance/linkage tests only; no cohort scoring or live reads."""
from copy import deepcopy
from dataclasses import FrozenInstanceError
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from early_origin_replay import PR36, SCHEMA, UNDEFINED, canonical, replay

OPEN = 1577836800000  # Synthetic 2020-01-01; no validation data.


def origin(entry_id='early-1', delta=120000, ticker='KXBTC15M-SYNTHETIC-A', opened=OPEN):
    t = opened + delta
    row = dict(schema=SCHEMA, record_type='EARLY_ORIGIN', entry_id=entry_id,
               run_id='synthetic-offline', side='UP', model_id='frozen-model-fixture',
               policy_id='frozen-early-fixture', native_gate_passed=True,
               observed_ts_ms=t + 100, entry_ts_ms=t, entry_price=.35,
               signal_only=True, orders=False,
               native=dict(authority='AUTHORITATIVE_ACTION_STATE', runtime_commit=PR36,
                           owner_epoch='native-1', decision_id=f'decision-{t}',
                           decision_ts_ms=t, published_ts_ms=t + 50),
               contract=dict(ticker=ticker, open_ts_ms=opened, close_ts_ms=opened + 900000,
                             target=80000), sources={})
    for name in ('quote', 'brti', 'btc'):
        row['sources'][name] = dict(proof_id=f'{name}-{t}', owner_epoch=name + '-owner-1',
                                   source_ts_ms=t - 1000, receipt_ts_ms=t - 500, qualified=True)
    row['sources']['quote'].update(ticker=ticker, validated_ts_ms=t - 100, up_ask=.35, down_ask=.65)
    row['sources']['brti']['value'] = 80020
    row['sources']['btc']['value'] = 80021
    return row


def final(entry_id='early-1', delta=125000, **kwargs):
    row = origin(entry_id, delta, **kwargs)
    del row['entry_ts_ms'], row['entry_price']
    row.update(record_type='FINAL_EVIDENCE', evidence_id=f'final-{row["native"]["decision_ts_ms"]}',
               policy_id='frozen-final-fixture', probability_up=.91)
    row['sources']['quote'].update(up_ask=.9, down_ask=.1)
    return row


class EarlyOriginReplayTests(unittest.TestCase):
    def assert_rejected(self, rows, reason):
        result = replay(rows)
        self.assertIn(reason, [x.reason for x in result.rejections])
        return result

    def test_origin_is_deeply_immutable_and_detached_from_input_and_output(self):
        row = origin()
        result = replay([row, final()])
        life = result.lifecycles[0]
        saved = life.origin.json
        with self.assertRaises(FrozenInstanceError):
            life.origin.json = '{}'
        with self.assertRaises(FrozenInstanceError):
            life.final_evidence = ()
        row['entry_price'] = .99
        row['native']['decision_ts_ms'] += 1000
        out = result.to_dict()
        out['lifecycles'][0]['origin']['sources']['quote']['up_ask'] = .99
        self.assertEqual(life.origin.json, saved)
        self.assertEqual(life.origin.to_dict()['entry_price'], .35)
        self.assertEqual(life.origin.to_dict()['entry_ts_ms'], OPEN + 120000)

    def test_subsequent_agreeing_and_opposite_final_keep_exact_origin(self):
        a, b = final(), final(delta=130000)
        b.update(side='DOWN', probability_up=.09)
        result = replay([origin(), a, b])
        self.assertFalse(result.rejections)
        life = result.lifecycles[0]
        self.assertEqual(life.origin.to_dict(), origin())
        self.assertEqual([r.to_dict() for r in life.final_evidence], [a, b])
        self.assertEqual(life.to_dict()['advice_state'], None)

    def test_explicit_same_contract_origins_never_use_latest_origin_as_default(self):
        rows = [origin(), origin('early-2', 125000), final('early-1', 130000),
                final('early-2', 135000)]
        result = replay(rows)
        self.assertFalse(result.rejections)
        for i, life in enumerate(result.lifecycles):
            self.assertEqual(life.origin.to_dict()['entry_id'], f'early-{i + 1}')
            self.assertEqual(life.final_evidence[0].to_dict()['entry_id'], f'early-{i + 1}')
        self.assert_rejected(rows + [final('missing', 140000)], 'UNKNOWN_EARLY_ORIGIN')

    def test_rollover_and_new_origin_cannot_relabel_old_lifecycle(self):
        next_contract = dict(opened=OPEN + 900000, ticker='KXBTC15M-SYNTHETIC-B')
        rows = [origin(), final(), origin('early-2', **next_contract),
                final('early-2', **next_contract), final('early-1', 130000, **next_contract)]
        result = self.assert_rejected(rows, 'ORIGIN_CONTRACT_MISMATCH')
        self.assertEqual(len(result.lifecycles[0].final_evidence), 1)
        self.assertEqual(result.lifecycles[0].origin.to_dict(), origin())
        at_close = final(delta=900000)
        self.assert_rejected([origin(), at_close], 'NONCAUSAL_OR_CLOSED_CONTRACT')
        self.assertEqual(result.lifecycles[0].to_dict()['settlement_status'], 'UNRESOLVED')

    def test_undefined_advice_is_never_inferred_from_probability_or_missing_evidence(self):
        weak = final()
        weak.update(probability_up=.01, side='DOWN', native_gate_passed=False)
        stale = final(delta=130000)
        stale['sources']['brti']['qualified'] = False
        for rows in ([origin()], [origin(), weak], [origin(), weak, stale]):
            with self.subTest(rows=len(rows)):
                result = replay(rows).to_dict()
                life = result['lifecycles'][0]
                self.assertIsNone(life['advice_state'])
                self.assertEqual(life['advice_policy_status'], UNDEFINED)
                self.assertEqual(life['reentry_policy_status'], UNDEFINED)
                self.assertFalse(life['execution_or_fill_proven'])
                self.assertFalse(result['advice_published'])
                self.assertFalse(result['orders'])
        invented = final(); invented['advice_state'] = 'EXIT'
        self.assert_rejected([origin(), invented], 'SCHEMA_FIELDS')

    def test_duplicate_delivery_is_idempotent_and_alias_or_conflict_is_rejected(self):
        e, f = origin(), final()
        result = replay([e, f, e, f])
        self.assertEqual(result.duplicate_count, 2)
        self.assertEqual(len(result.lifecycles), 1)
        self.assertEqual(len(result.lifecycles[0].final_evidence), 1)
        changed = deepcopy(e)
        changed['entry_price'] = changed['sources']['quote']['up_ask'] = .36
        self.assert_rejected([e, changed], 'CONFLICTING_RECORD_IDENTITY')
        alias = deepcopy(e); alias['entry_id'] = 'alias'
        self.assert_rejected([e, alias], 'NATIVE_DECISION_IDENTITY_CONFLICT')
        alias = deepcopy(f); alias['evidence_id'] = 'alias'
        self.assert_rejected([e, f, alias], 'NATIVE_DECISION_IDENTITY_CONFLICT')

    def test_same_final_may_explicitly_link_two_origins_without_altering_evidence(self):
        first = final('early-1', 130000)
        second = deepcopy(first); second['entry_id'] = 'early-2'
        rows = [origin(), origin('early-2', 125000), first, second]
        result = replay(rows)
        self.assertFalse(result.rejections)
        self.assertEqual([len(x.final_evidence) for x in result.lifecycles], [1, 1])
        conflict = deepcopy(second); conflict['probability_up'] = .92
        self.assert_rejected(rows[:-1] + [conflict], 'NATIVE_DECISION_IDENTITY_CONFLICT')

    def test_future_missing_and_stale_provenance_fail_closed(self):
        cases = []
        row = origin(); row['sources']['brti']['receipt_ts_ms'] += 1000
        cases.append((row, 'SOURCE_NOT_CAUSALLY_AVAILABLE'))
        row = origin(); row['sources']['brti']['source_ts_ms'] += 2000
        cases.append((row, 'SOURCE_NOT_CAUSALLY_AVAILABLE'))
        row = origin(); del row['sources']['quote']['proof_id']
        cases.append((row, 'SCHEMA_FIELDS'))
        row = origin(); row['sources']['quote']['ticker'] = 'OTHER'
        cases.append((row, 'QUOTE_TICKER_MISMATCH'))
        for name, age in [('brti', 5001), ('quote', 6001), ('btc', 10001)]:
            row = origin(); row['sources'][name]['source_ts_ms'] = row['observed_ts_ms'] - age
            cases.append((row, 'SOURCE_EXPIRED_AT_OBSERVATION'))
        for row, reason in cases:
            with self.subTest(reason=reason, sources=row['sources']):
                self.assertFalse(self.assert_rejected([row], reason).lifecycles)

    def test_exact_five_second_boundary_and_expiry_during_publication(self):
        row = origin(); row['sources']['brti']['source_ts_ms'] = row['observed_ts_ms'] - 5000
        self.assertEqual(len(replay([row]).lifecycles), 1)
        row['observed_ts_ms'] += 1
        self.assert_rejected([row], 'SOURCE_EXPIRED_AT_OBSERVATION')
        row = origin(); row['native']['published_ts_ms'] += 5000; row['observed_ts_ms'] += 5000
        self.assert_rejected([row], 'SOURCE_EXPIRED_AT_OBSERVATION')

    def test_entry_quote_time_gate_and_authority_cannot_be_reconstructed_later(self):
        cases = []
        row = origin(); row['entry_price'] = .25
        cases.append((row, 'ENTRY_PRICE_PROVENANCE_MISMATCH'))
        row = origin(); row['entry_ts_ms'] -= 1
        cases.append((row, 'ENTRY_TIMESTAMP_DRIFT'))
        row = origin(); row['native_gate_passed'] = False
        cases.append((row, 'EARLY_NATIVE_ELIGIBILITY_REQUIRED'))
        row = origin(); row['native']['authority'] = 'INFORMATIONAL_READ_ONLY'
        cases.append((row, 'FROZEN_NATIVE_AUTHORITY_REQUIRED'))
        for row, reason in cases:
            with self.subTest(reason=reason):
                result = self.assert_rejected([row, final()], reason)
                self.assertFalse(result.lifecycles)

    def test_run_model_contract_restart_and_policy_boundaries_are_explicit(self):
        cases = []
        row = final(); row['run_id'] = 'other'
        cases.append(([origin(), row], 'MIXED_RUN_IDENTITIES'))
        row = final(); row['model_id'] = 'other'
        cases.append(([origin(), row], 'MODEL_IDENTITY_CHANGED'))
        row = final(); row['contract']['target'] += 1
        cases.append(([origin(), row], 'CONTRACT_IDENTITY_CONFLICT'))
        row = final(); row['native']['owner_epoch'] = 'restarted'
        cases.append(([origin(), row], 'OWNER_RESTART_LINK_UNDEFINED'))
        row = final(delta=130000); row['policy_id'] = 'retuned'
        cases.append(([origin(), final(), row], 'FROZEN_POLICY_IDENTITY_CHANGED'))
        for rows, reason in cases:
            with self.subTest(reason=reason):
                result = self.assert_rejected(rows, reason)
                self.assertEqual(result.lifecycles[0].origin.to_dict(), origin())

    def test_out_of_order_or_pre_origin_evidence_is_not_backfilled(self):
        self.assert_rejected([final(), origin()], 'UNKNOWN_EARLY_ORIGIN')
        self.assert_rejected([origin(), final(delta=130000), final()], 'OUT_OF_ORDER_RECORD')
        simultaneous = final(delta=120000)
        simultaneous['sources'] = deepcopy(origin()['sources'])
        self.assert_rejected([origin(), simultaneous], 'FINAL_NOT_SUBSEQUENT_TO_ORIGIN')

    def test_source_identity_conflicts_are_rejected_without_poisoning_later_input(self):
        bad = final()
        bad['sources']['quote']['proof_id'] = origin()['sources']['quote']['proof_id']
        result = self.assert_rejected([origin(), bad, final()], 'SOURCE_PROOF_IDENTITY_CONFLICT')
        self.assertEqual(len(result.lifecycles[0].final_evidence), 1)
        later_origin = origin('early-2', 125000)
        reused_frame = final(delta=130000)
        reused_frame['native']['decision_id'] = later_origin['native']['decision_id']
        self.assert_rejected([origin(), later_origin, reused_frame], 'NATIVE_FRAME_IDENTITY_CONFLICT')

    def test_replay_and_cli_are_deterministic_with_no_input_mutation_or_output_overwrite(self):
        rows = [origin(), final(), final()]
        before = deepcopy(rows)
        expected = canonical(replay(rows).to_dict()) + '\n'
        self.assertEqual(expected, canonical(replay(rows).to_dict()) + '\n')
        self.assertEqual(rows, before)
        script = Path(__file__).with_name('early_origin_replay.py')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.jsonl'
            path.write_text(''.join(canonical(row) + '\n' for row in rows))
            for name in ('first.json', 'second.json'):
                output = Path(directory) / name
                command = [sys.executable, str(script), str(path), '--output', str(output)]
                subprocess.run(command, capture_output=True, check=True)
                self.assertEqual(output.read_text(), expected)
            failed = subprocess.run(command, capture_output=True)
            self.assertNotEqual(failed.returncode, 0)
            self.assertEqual(output.read_text(), expected)
            path.write_text('{"record_type":"EARLY_ORIGIN","record_type":"FINAL_EVIDENCE"}\n')
            failed = subprocess.run(command[:-1] + [str(Path(directory) / 'bad.json')], capture_output=True)
            self.assertNotEqual(failed.returncode, 0)
            self.assertFalse((Path(directory) / 'bad.json').exists())


if __name__ == '__main__':
    unittest.main()
