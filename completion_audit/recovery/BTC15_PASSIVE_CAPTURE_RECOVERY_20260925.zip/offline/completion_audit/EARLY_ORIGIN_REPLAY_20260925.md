# Offline EARLY-origin replay checkpoint — 2026-09-25

Scope: immutable EARLY origin and explicit subsequent FINAL evidence linkage,
implemented from `TWO_CLOCK_LIFECYCLE_SPEC_20260925.md`. SIGNAL ONLY / NO ORDERS.
No live integration, entry generation, advice policy, predictive selection,
scoring, calibration, real-cohort replay or deployment is performed.

Production remains PR36 `3e552065e34a0a402bc3ca4598b57dff1f1c6e77`.
Qualified two-clock candidate `06261dbfbe6d8336a6886a4f2b349f33b06b6202`
remains undeployed. This isolated audit branch adds only the replay module,
focused tests, this contract and its acceptance evidence. No existing runtime,
model, two-clock code or lifecycle specification is changed.

## Capability completed

- Explicit EARLY origins preserve entry ID, original native decision timestamp,
  quoted ask, contract/target/window, policy/model identity, native generation,
  and quote/BRTI/BTC proof identities and clocks in deeply immutable records.
  Export returns detached copies. Prices are probabilities in [0, 1], not cents.
- FINAL observations name the exact EARLY `entry_id`. Agreement, disagreement
  and native FINAL eligibility are preserved as observations, without replacing
  the origin or claiming a new entry, persistence hit, fill, exit or flip.
- Multiple explicitly supplied origins are independent replay cases. They do
  not establish a re-entry policy. There is no inferred latest/active position.
  The same FINAL observation may link explicitly to more than one case; its
  native frame, evidence ID and payload must remain identical.
- Duplicate delivery is idempotent. Reused origin/evidence/native/proof IDs with
  changed contents or alias IDs for the same native observation fail closed.
  Rejected rows remain in a rejection ledger with input index, reason and hash;
  they cannot alter an accepted origin or poison subsequent valid records.
- Same-contract target/window conflicts, cross-contract links, post-close
  records, mixed runs, model/policy changes, unknown origins, and non-subsequent
  FINAL records are rejected. Native owner restarts cannot silently reconnect an
  old origin: `OWNER_RESTART_LINK_UNDEFINED` requires an explicit later policy.
- Source clocks must be causal by the original native decision; qualification
  must survive recorded observation. Existing BRTI <=5s, quote <=6s and BTC <=10s
  ceilings are retained. Missing proof references, future receipts and expiry
  during publication fail closed. There is no latest-frame substitution.
- Every output has `advice_state=null`, an explicit undefined advice/re-entry
  policy marker, unresolved settlement and no execution/fill claim. Prior FINAL
  records are historical evidence, never a last-good current recommendation.
  Rollover keeps the old contract history; it never invents an exit or settlement.

## Input contract and trust boundary

The interface accepts explicit normalized records, **not raw dashboard ready
flags**. Because PR36 has no durable EARLY entry owner, `entry_id` here is a
caller-supplied stable replay-case identity for a specified native observation.
It is not a claim that PR36 created a durable entry or that the user executed it.
No origin is selected automatically from a sequence of eligibility samples.

Each JSONL row has these exact common fields (unknown fields are rejected):

| Fields | Meaning |
|---|---|
| `schema`, `record_type` | `BTC15_EARLY_ORIGIN_REPLAY_V1`; `EARLY_ORIGIN` or `FINAL_EVIDENCE` |
| `entry_id`, `run_id`, `side` | Explicit origin link, immutable cohort/run identity, UP/DOWN |
| `model_id`, `policy_id`, `native_gate_passed` | Identities and recorded native gate result; gates are not recomputed |
| `observed_ts_ms` | Original recorded observation time, not archive-load or replay wall time |
| `native` | Exact keys: `authority`, `runtime_commit`, `owner_epoch`, `decision_id`, `decision_ts_ms`, `published_ts_ms` |
| `contract` | Exact keys: `ticker`, `open_ts_ms`, `close_ts_ms`, `target` |
| `sources` | Exactly `quote`, `brti`, `btc`; each has `proof_id`, `owner_epoch`, `source_ts_ms`, `receipt_ts_ms`, `qualified` |
| `signal_only`, `orders` | Required true / false |

Native authority must be `AUTHORITATIVE_ACTION_STATE` at the PR36 commit.
All clocks are integer Unix milliseconds. The contract is an aligned 15-minute
window. Source proof references identify archived native evidence in their
owner generation. Quote also requires `ticker`, `validated_ts_ms`, `up_ask`,
`down_ask`; BRTI and BTC each require `value`.

An EARLY row additionally requires `entry_ts_ms`, `entry_price`: timestamp equals
the native decision timestamp; price equals that exact source quote's side ask;
the recorded EARLY gate must be true. A FINAL row additionally requires
`evidence_id`, `probability_up`; its gate may be false, preserving deterioration
observations without inventing confirmation or advice. FINAL must come from a
strictly later native decision in the same contract and native generation.

This harness verifies **internal record/link/clock consistency**, not external
authenticity of supplied `qualified` flags or proof references. It does not fetch
proof blobs or reproduce native gates/models. A real-data adapter must preserve
and verify the original evidence mapping; missing metadata must remain rejected,
never reconstructed or asserted fresh. Native qualification at observation does
not prove browser delivery, an available manual fill or continuous price paths.

Replay consumes input order. It does not sort late evidence backward or attach
previously rejected evidence after an origin arrives. Exact duplicate deliveries
may repeat an older record without advancing the replay clock. Malformed JSON,
duplicate JSON keys or non-finite JSON values fail the whole invocation before
creating output. Structurally valid but unqualified records are individually
rejected. Output uses exclusive creation, preserving any pre-existing artifact.

## Run and verification

From the repository root, for an explicitly prepared normalized input:

```sh
python3 completion_audit/early_origin_replay.py INPUT.jsonl --output OUTPUT.json
```

Focused test command:

```sh
python3 -m unittest discover -s completion_audit -p test_early_origin_replay.py -v
```

Tests use synthetic January 2020 observations only. No historic holdout or
September 24 20:15–21:15 UTC validation-only data was read or scored. The existing
V8.1 accounting/replay work supplied the retained provenance and fail-closed
principles; no unrelated test suite was rerun. Machine-readable acceptance
records the final count, result, source hashes and boundary checks.

## Remaining work and next minimum action

The offline linkage foundation is complete; the complete advisory lifecycle is
not. EARLY birth/re-entry selection, durability/restart policy, HOLD/CAUTION/
PROTECT/EXIT/FLIP rules, Core linked exits and FINAL-to-EARLY management policy
remain undefined/unvalidated. Core remains NOT_LINKED; FINAL remains shadow_only
and shadow_protection_used_as_action=False; V8.1 retains its separate owner.

**Next minimum action:** add a read-only adapter from preserved PR36 observations
and their source evidence to this explicit replay schema, reporting missing
provenance and requiring supplied origin mappings. This enables real-evidence
linkage verification without selecting an entry, scoring a cohort or defining
advice policy. It is not part of this checkpoint.

Nothing here changes the separate two-clock live-acceptance requirement. Offline
ladder linkage can proceed independently; two-clock information remains strictly
INFORMATIONAL_READ_ONLY and never creates lifecycle transitions.
