"""Synthetic records in preserved PR36 formats; no performance data or live I/O."""
from copy import deepcopy
import csv
from datetime import datetime, timezone
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from btc15_fair_input_export_v1 import FEATURES
from early_origin_replay import PR36, canonical, replay
from pr36_evidence_adapter import ARTIFACT, WEIGHTS, Archive, adapt, load_manifest, sha

OPEN = 1577836800000


def iso(t):
    return datetime.fromtimestamp(t / 1000, timezone.utc).isoformat(timespec='milliseconds')


def fixture(delta=120000, ticker='KXBTC15M-SYNTHETIC-A', opened=OPEN, kind='EARLY_ORIGIN', entry='e1'):
    t = opened + delta
    source = t - 1000
    early = dict(ready=True, source='FROZEN_TIER1', side='UP', ask=.35)
    final = dict(ready=True, source='FROZEN_V4_6_FINAL', side='UP', confidence=.91)
    observation = dict(version=1, record_type='OBSERVATION', signal_only=True, orders=False,
        observed_utc=iso(t + 100), source_timestamp_utc=iso(t), contract=ticker,
        usable_frame=True, brti_fresh=True, timer={'close_utc': 'DO_NOT_USE_ROUNDED_TIMER'},
        market=dict(target=80000, btc_price=80021, brti_value=80020, brti_ready=True,
                    brti_age_seconds=1, up_bid=.34, up_ask=.35, down_bid=.65, down_ask=.66),
        parity=dict(status='PASS', contract=ticker, api_contract=ticker, timestamp_utc=iso(t)),
        lanes={name: dict(raw_ready=True, publication_eligible=True, source_qualified=True, raw=raw)
               for name, raw in [('early', early), ('final', final)]})
    fair = dict(schema='BTC15_FAIR_INPUT_V1', ticker=ticker, target=80000, decision_utc=iso(t),
        btc_source_utc=iso(source), btc_observed_utc=iso(t - 500), btc_price=80021,
        features={k: 0 for k in FEATURES}, feature_order=FEATURES,
        artifact_sha256=ARTIFACT, weights_sha256=WEIGHTS, signal_only=True, orders=False)
    quote = dict(source_time=iso(t), ticker=ticker, epoch='quote-owner', consumed_ms=t - 100,
        identity=['market', 1, 2, source], events=[
            dict(type='orderbook_snapshot', sid=1, seq=1, msg=dict(market_ticker=ticker,
                market_id='market', yes_dollars_fp=[['0.34','10']], no_dollars_fp=[['0.65','10']])),
            dict(type='orderbook_delta', sid=1, seq=2, msg=dict(market_ticker=ticker,
                market_id='market', side='yes', price_dollars='0.34', delta_fp='1', ts_ms=source))])
    brti = dict(schema='BTC15_BRTI_DELIVERY_V1', ticker=ticker, decision_utc=iso(t),
        source_ts=source / 1000, age_at_decision=1, ready=True, signal_only=True, orders=False,
        delivery=dict(owner_epoch='brti-owner', observed_ts=(t - 500) / 1000,
                      decision_ts=t / 1000, checked_ts=t / 1000, current_age=1, reason='QUALIFIED'))
    bs = dict(schema_version=2, index_id='BRTI', source_ts_ms=source, value=80020,
        owner_epoch='brti-owner', status='PRIMARY_OK', clean_for_qualification=True, signal_only=True, orders=False)
    contract = dict(ticker=ticker, open_time=iso(opened), close_time=iso(opened + 900000), floor_strike=80000)
    context = dict(runtime_commit=PR36, run_id='synthetic', native_owner_epoch='native-owner',
        btc_owner_epoch='btc-owner', decision_id=f'd{t}', decision_utc=iso(t), published_utc=iso(t + 50),
        ticker=ticker, early_policy_id='frozen-early', final_policy_id='frozen-final',
        quote_received_utc=iso(t - 500), signal_only=True, orders=False)
    docs = dict(observation=observation, fair=fair, quote=quote, brti_delivery=brti,
                brti_source=bs, contract=contract, context=context)
    mapping = dict(record_type=kind, entry_id=entry, evidence_id=None if kind == 'EARLY_ORIGIN' else f'f{t}')
    return docs, mapping


def add(archive, docs, mapping, label):
    mapping = deepcopy(mapping)
    for name, row in docs.items():
        raw = canonical(row).encode()
        key = label + '-' + name
        archive.add(key, raw, sha(raw), role='observations' if name == 'observation' else 'evidence')
        mapping[name] = dict(artifact=key, row=0)
    return mapping


class PR36AdapterTests(unittest.TestCase):
    def base(self):
        archive = Archive()
        first = add(archive, *fixture(), 'entry')
        second = add(archive, *fixture(125000, kind='FINAL_EVIDENCE'), 'final')
        return archive, [first, second]

    def test_real_schemas_exact_sources_and_explicit_links_reach_existing_harness(self):
        archive, mappings = self.base()
        before = deepcopy(mappings)
        with patch('socket.socket', side_effect=AssertionError('No network')):
            result = adapt(archive, mappings)
        self.assertFalse(result['adapter_rejections']); self.assertFalse(result['replay']['rejections'])
        self.assertEqual(mappings, before)
        life = result['replay']['lifecycles'][0]
        self.assertEqual(life['origin']['entry_price'], .35)
        self.assertEqual(life['origin']['entry_ts_ms'], OPEN + 120000)
        self.assertEqual(life['final_evidence'][0]['entry_id'], 'e1')
        self.assertIsNone(life['advice_state'])
        self.assertEqual(replay(result['converted_records']).to_dict(), result['replay'])
        self.assertEqual(canonical(result), canonical(adapt(archive, mappings)))

    def test_unmapped_unknown_and_ambiguous_origin_mappings_do_not_create_entries(self):
        archive, mappings = self.base()
        empty = adapt(archive, [])
        self.assertEqual(len(empty['unmapped_observations']), 2)
        self.assertEqual(empty['converted_records'], [])
        self.assertEqual(adapt(archive, [mappings[1]])['replay']['rejections'][0]['reason'], 'UNKNOWN_EARLY_ORIGIN')
        alias = deepcopy(mappings[0]); alias['entry_id'] = 'e2'
        result = adapt(archive, [mappings[0], alias])
        self.assertEqual(result['converted_records'], [])
        self.assertTrue(all(r['reason'] == 'AMBIGUOUS_ORIGIN_MAPPING' for r in result['adapter_rejections']))
        conflict = deepcopy(mappings[0]); conflict['observation'] = mappings[1]['observation']
        self.assertEqual(adapt(archive, [mappings[0], conflict])['converted_records'], [])

    def test_duplicate_mappings_are_preserved_and_harness_deduplicates(self):
        archive, mappings = self.base()
        result = adapt(archive, mappings + mappings)
        self.assertEqual(len(result['converted_records']), 4)
        self.assertEqual(result['replay']['duplicate_count'], 2)
        self.assertEqual(len(result['replay']['lifecycles'][0]['final_evidence']), 1)
        row = archive.get(mappings[0]['observation']); raw = canonical(row).encode()
        archive.add('duplicate-observation', raw, sha(raw), role='observations')
        repeated = deepcopy(mappings[0]); repeated['observation'] = dict(artifact='duplicate-observation', row=0)
        result = adapt(archive, [mappings[0], repeated])
        self.assertFalse(result['adapter_rejections'])
        self.assertEqual(result['replay']['duplicate_count'], 1)

    def test_down_final_deterioration_stays_observation_without_advice(self):
        archive = Archive()
        first = add(archive, *fixture(), 'entry')
        docs, mapping = fixture(125000, kind='FINAL_EVIDENCE')
        lane = docs['observation']['lanes']['final']
        lane.update(raw_ready=False, publication_eligible=False, source_qualified=False)
        lane['raw'].update(side='DOWN', confidence=.91, ready=False)
        second = add(archive, docs, mapping, 'final')
        result = adapt(archive, [first, second])
        self.assertFalse(result['adapter_rejections'])
        life = result['replay']['lifecycles'][0]
        self.assertAlmostEqual(life['final_evidence'][0]['probability_up'], .09)
        self.assertFalse(life['final_evidence'][0]['native_gate_passed'])
        self.assertIsNone(life['advice_state'])

    def test_missing_or_changed_source_proof_is_not_replaced_by_latest(self):
        archive, mappings = self.base()
        missing = deepcopy(mappings[0]); missing['quote']['artifact'] = 'absent'
        self.assertEqual(adapt(archive, [missing])['adapter_rejections'][0]['reason'], 'MISSING_REFERENCED_EVIDENCE')
        swapped = deepcopy(mappings[0]); swapped['quote'] = mappings[1]['quote']
        self.assertEqual(adapt(archive, [swapped])['adapter_rejections'][0]['reason'], 'EXACT_DECISION_JOIN_REQUIRED')
        docs, m = fixture(); docs['quote']['events'][1]['seq'] = 4
        archive = Archive(); m = add(archive, docs, m, 'gap')
        self.assertFalse(adapt(archive, [m])['converted_records'])

    def test_contract_rollover_target_and_early_origin_isolation(self):
        archive, mappings = self.base()
        docs, m = fixture(kind='FINAL_EVIDENCE', opened=OPEN + 900000, ticker='KXBTC15M-SYNTHETIC-B')
        rollover = add(archive, docs, m, 'rollover')
        result = adapt(archive, mappings + [rollover])
        self.assertEqual(result['replay']['rejections'][0]['reason'], 'ORIGIN_CONTRACT_MISMATCH')
        self.assertEqual(len(result['replay']['lifecycles'][0]['final_evidence']), 1)
        for field, value in [('ticker','OTHER'), ('floor_strike',80001)]:
            docs, m = fixture(); docs['contract'][field] = value
            a = Archive(); m = add(a, docs, m, field)
            self.assertFalse(adapt(a, [m])['converted_records'])

    def test_source_receipt_future_stale_submillisecond_and_publication_checks(self):
        mutations = [
            lambda d: d['fair'].update(btc_observed_utc=iso(OPEN + 120001)),
            lambda d: d['brti_delivery']['delivery'].update(observed_ts=(OPEN + 120001) / 1000),
            lambda d: d['context'].update(quote_received_utc=iso(OPEN + 120001)),
            lambda d: d['observation'].update(observed_utc=iso(OPEN + 125001)),
            lambda d: d['context'].update(published_utc=iso(OPEN + 120101)),
            lambda d: d['fair'].update(decision_utc='2020-01-01T00:02:00.000001+00:00'),
            lambda d: d['brti_source'].update(owner_epoch='different-owner'),
            lambda d: d['fair'].update(weights_sha256='0' * 64),
        ]
        for index, mutate in enumerate(mutations):
            with self.subTest(index=index):
                docs, m = fixture(); mutate(docs)
                a = Archive(); m = add(a, docs, m, str(index))
                result = adapt(a, [m])
                self.assertFalse(result['converted_records']); self.assertEqual(len(result['adapter_rejections']), 1)

    def test_false_ready_or_rounded_timer_cannot_supply_an_origin_or_official_window(self):
        docs, m = fixture()
        docs['observation']['lanes']['early']['raw']['ready'] = False
        a = Archive(); m = add(a, docs, m, 'false')
        self.assertFalse(adapt(a, [m])['converted_records'])
        docs, m = fixture(); del docs['contract']['open_time']
        a = Archive(); m = add(a, docs, m, 'no-window')
        self.assertFalse(adapt(a, [m])['converted_records'])
        docs, m = fixture(); del docs['context']['native_owner_epoch']
        a = Archive(); m = add(a, docs, m, 'no-owner')
        self.assertFalse(adapt(a, [m])['converted_records'])

    def test_hash_verified_csv_envelope_jsonl_manifest_and_no_input_writes(self):
        docs, _ = fixture()
        row = docs['observation']; output = io.StringIO(newline='')
        fields = ['observed_utc','source_timestamp_utc','contract','record_type','payload']
        writer = csv.DictWriter(output, fieldnames=fields); writer.writeheader()
        wrapper = {k: row[k] for k in fields[:-1]}; wrapper['payload'] = canonical(row)
        writer.writerow(wrapper); raw = output.getvalue().encode()
        archive = Archive(); archive.add('csv', raw, sha(raw), 'qualified_csv', 'observations')
        self.assertEqual(archive.get({'artifact':'csv','row':0}), row)
        with self.assertRaisesRegex(ValueError, 'ARTIFACT_HASH_MISMATCH'):
            Archive().add('csv', raw, '0'*64, 'qualified_csv')
        with self.assertRaisesRegex(ValueError, 'AMBIGUOUS_ARTIFACT_ID'):
            archive.add('csv', raw, sha(raw), 'qualified_csv')
        bad = raw.replace(b'KXBTC15M-SYNTHETIC-A', b'OTHER', 1)
        with self.assertRaisesRegex(ValueError, 'CSV_PAYLOAD_IDENTITY_CONFLICT'):
            Archive().add('bad', bad, sha(bad), 'qualified_csv')
        duplicate_json = b'{"x":1,"x":2}'
        with self.assertRaisesRegex(ValueError, 'DUPLICATE_JSON_FIELD'):
            Archive().add('bad', duplicate_json, sha(duplicate_json))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = root/'observations.csv'; source.write_bytes(raw)
            manifest = root/'manifest.json'
            manifest.write_text(canonical(dict(artifacts=[dict(id='csv',path='observations.csv',
                sha256=sha(raw),format='qualified_csv',role='observations')],mappings=[])))
            a, mappings = load_manifest(manifest)
            self.assertEqual(len(adapt(a, mappings)['unmapped_observations']), 1)
            self.assertEqual(source.read_bytes(), raw)
        raw = (canonical(row)+'\n'+canonical(row)+'\n').encode()
        a = Archive(); a.add('jsonl', raw, sha(raw), 'jsonl', 'observations')
        self.assertEqual(len(a.observations), 2)


if __name__ == '__main__':
    unittest.main()
