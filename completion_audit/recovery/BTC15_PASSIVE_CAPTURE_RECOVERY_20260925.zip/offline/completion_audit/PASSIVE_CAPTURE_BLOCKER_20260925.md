# Passive capture qualification — STOP / BLOCKED

Parent checkpoint: `b6e750fd07728a24ba6c7e49b1dfbe7f1392a0b7`.
No native instrumentation was installed or deployed. No adapter, replay,
strategy, model, threshold, two-clock or infrastructure code was changed.
Only focused offline producer-counterexample tests and this evidence were added.
SIGNAL ONLY / NO ORDERS.

## Demonstrated format blocker

The earlier source-level concern is now a reproducible failure using the actual
frozen `Provider.consume` and `Delivery.select` implementations. Their constructor
network workers are not started. Inputs and clocks are explicitly synthetic
January 2020 fixtures; these are engineering counterexamples, not authentic live
EARLY→FINAL evidence or predictive results.

| Required binding | Actual producer observation | Unchanged adapter result |
|---|---|---|
| Quote validation at/before native cutoff | Cutoff `00:02:00.000191Z`; book already present before cutoff; actual `Provider.consume` called at `00:02:00.004001Z`, emits `consumed_ms=1577836920004` | `QUOTE_PROVENANCE_TIME` |
| No future quote/source admitted | Event source `00:02:00.001000Z`, receipt `00:02:00.001001Z`, consumption after the same `00:02:00.000191Z` cutoff | `SOURCE_NOT_CAUSALLY_AVAILABLE` |
| Exact native BRTI telemetry | Actual `Delivery.select` receives native float cutoff corresponding to `.000191Z`; raw age is `1.0001909732818604`, whereas exact ISO-clock subtraction is `1.000191` | `SUBMICROSECOND_CLOCK_NOT_REPRESENTABLE` |

The unchanged adapter assigns `sources.quote.validated_ts_ms` directly from
`q.consumed_ms`. It has no distinct binding for a new independently captured
pre-cutoff receipt/validation witness. Appending such a field does not make it
consume that field. To force the existing row through, an exporter would have to
replace the actual consumption clock, move the native cutoff, or weaken the
existing check. None is permitted. Likewise, replacing raw native float age with
an exact derived age would alter evidence, not merely record it.

This proves that an unchanged-format passive copier is not a general solution
for truthful native evidence, even for a quote value present before the cutoff.
It does not establish that every possible timestamp combination fails, that no
future contract could incidentally pass, or that the tested future quote occurred
in live production. Capturing only fortuitous clock encodings is not a substitute
for the requested general causal capture contract.

Following the user's explicit stop condition, runtime patch implementation stops
here. Do not install a partial logger or label it qualified. A separate exact
evidence representation is needed before a truthful complete capture patch can
be qualified without changing native timing or relabeling its fields.

## What the focused checks do and do not prove

- 3 new producer tests pass by preserving and correctly rejecting the unsupported
  records. They do not pass by manufacturing an admissible lifecycle.
- The frozen main file is checked against Git blob
  `f547ab4238592910ed76fee61870cd18714d09f0`; its actual call order is checked.
- Reading the proof bytes after actual native consumption leaves the quote
  outputs, serialized proof and all quote-owner data identical to not copying
  them. `Delivery.select` leaves its delivery state unchanged. These are local
  producer checks, **not** whole-loop enabled/disabled patch equivalence.
- The existing 29 tests are reused unchanged alongside the 3 new tests. The
  recovery source package is used to run the focused 32-test suite independently
  of the repository, without model files, network, credentials or private captures.
- No production capture exists to benchmark. Bounded writer/queue behavior,
  full-native equivalence, complete field capture and all ten requested deployment
  gates are **NOT QUALIFIED**, not assumed from fast component tests.
- No authentic pair is obtained. The new native-produced counterexamples are
  rejected by the unchanged adapter. Prior synthetic complete-format cases still
  pass the preserved suite; they do not establish native capture compatibility.

## Required capture points remain explicit

The prior capture-gate document remains the field inventory: official market
object and BTC provenance at `decision_time`; original feature frame at
`record_model_input`; actual consumed book plus separately witnessed receipt/
validation at the quote owner; exact selected shared BRTI response and native
delivery; actual completed-publication context; immutable observational EARLY ID,
time/ask and explicit later-FINAL pointer in the existing observer. None may be
filled using renderer time, latest source state, another collector's epoch, or
same-contract association alone. No signal/action origin is created by this work.

## One minimum next action

Authorize a narrow, versioned **offline capture-evidence contract extension** that
keeps actual native consumption and raw float telemetry intact while separately
binding genuine pre-cutoff availability/validation witnesses and exact clocks.
Then qualify it before implementing or deploying native hooks. Keep PR36 timing,
all source/provenance checks, and the current replay version frozen; no tolerance,
backdating, fabricated origin or strategy change is a permitted remedy.

This is an evidence-format decision, not approval for deployment, scoring or
predictive/lifecycle policy work. The separate two-clock live-acceptance gate is
unchanged. Production PR36 is still `3e552065e34a0a402bc3ca4598b57dff1f1c6e77`;
two-clock candidate `06261dbfbe6d8336a6886a4f2b349f33b06b6202` remains undeployed.

## Recovery

The separately preserved recovery ZIP contains every local ladder change since
`852e9a4638eb487ffe5a307b79d039d2a9b747c1`, the minimal frozen source dependencies,
all 32 focused tests, these counterexamples, manifest hashes, exact commit/tree
identities, and resume instructions. It runs the focused tests without a GitHub
connection or a Git repository. An incremental Git bundle also preserves exact
local commits; restoring those commits into the full project requires the stated
base commit. This is a self-contained offline-work recovery, not a full project
mirror. It excludes secrets, runtime data directories and private live snapshots.
