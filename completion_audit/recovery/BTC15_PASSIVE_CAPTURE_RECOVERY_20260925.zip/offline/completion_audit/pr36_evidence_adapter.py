"""Read-only exact-artifact adapter; no inferred origins, live reads or scoring."""
import csv
from datetime import datetime, timezone
from decimal import Decimal
from fractions import Fraction
import hashlib
import io
import json
import re
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from btc15_fair_input_export_v1 import validate_record as validate_fair
from btc15_kalshi_quote_provenance_v1 import replay as replay_quote
from early_origin_replay import PR36, SCHEMA, canonical, exact, replay, require, timestamp, unique_object, validate

ARTIFACT = '1bf10e755fc81584bab3c3682b16103353f84582c27bb003664de883e7e7c816'
WEIGHTS = '95fc4e893c9032f29b9732d03c4a2e0cd62755ba93b36106a1d0c8c094520ba6'
SECONDS_FIELDS = frozenset(('source_ts', 'decision_ts', 'observed_ts', 'checked_ts',
                            'age_at_decision', 'current_age', 'brti_age_seconds'))


def parse(raw):
    def reject(value):
        raise ValueError('NONFINITE_JSON')
    def object_hook(pairs):
        # Source clock tokens must never pass through binary float, including
        # when a submicrosecond difference would disappear at epoch scale.
        return unique_object((key, value if key in SECONDS_FIELDS or not isinstance(value, Decimal)
                              else float(value)) for key, value in pairs)
    def arrays(value):
        if isinstance(value, list):
            return [float(x) if isinstance(x, Decimal) else arrays(x) for x in value]
        if isinstance(value, dict):
            return {k: arrays(v) for k, v in value.items()}
        return value
    return arrays(json.loads(raw, object_pairs_hook=object_hook, parse_constant=reject,
                            parse_float=Decimal))


def evidence_json(value):
    """Canonical archive JSON retaining exact numeric source-clock tokens."""
    if isinstance(value, Decimal):
        require(value.is_finite(), 'NONFINITE_JSON')
        return str(value)
    if type(value) is dict:
        return '{' + ','.join(canonical(k) + ':' + evidence_json(v)
                              for k, v in sorted(value.items())) + '}'
    if type(value) is list:
        return '[' + ','.join(evidence_json(v) for v in value) + ']'
    return canonical(value)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ms(value):
    """Exact rational milliseconds; reject unsupported precision before parsing."""
    require(type(value) is str and re.fullmatch(
        r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})',
        value), 'EXACT_MICROSECOND_ISO_REQUIRED')
    d = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(d.tzinfo is not None, 'TIMEZONE_REQUIRED')
    delta = d.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return Fraction((delta.days * 86400 + delta.seconds) * 1000000 + delta.microseconds, 1000)


def seconds_ms(value):
    require(type(value) in (int, Decimal), 'EXACT_SOURCE_CLOCK_REQUIRED')
    require(not isinstance(value, Decimal) or value.is_finite(), 'NONFINITE_JSON')
    scaled = Fraction(value) * 1000
    require((scaled * 1000).denominator == 1, 'SUBMICROSECOND_CLOCK_NOT_REPRESENTABLE')
    return scaled


def wire_ms(value):
    """Lossless JSON clock: legacy int ms or exact three-place decimal ms string."""
    micros = Fraction(value) * 1000
    require(micros.denominator == 1 and micros >= 0, 'EXACT_MICROSECOND_CLOCK_REQUIRED')
    whole, fraction = divmod(micros.numerator, 1000)
    return whole if fraction == 0 else f'{whole}.{fraction:03d}'


def wire_clocks(value):
    if type(value) is dict:
        return {k: wire_ms(v) if k.endswith('_ts_ms') else wire_clocks(v)
                for k, v in value.items()}
    return value


class Archive:
    """Hash-verified immutable JSON/JSONL/qualified-forward CSV bytes."""
    def __init__(self):
        self._rows = {}
        self._artifacts = {}
        self.observations = []

    def add(self, artifact_id, raw, expected_sha256, format='json', role='evidence'):
        require(type(artifact_id) is str and artifact_id and artifact_id not in self._artifacts,
                'AMBIGUOUS_ARTIFACT_ID')
        require(type(raw) is bytes and sha(raw) == expected_sha256, 'ARTIFACT_HASH_MISMATCH')
        require(role in ('evidence', 'observations'), 'ARTIFACT_ROLE')
        if format == 'json':
            rows = [parse(raw)]
        elif format == 'jsonl':
            rows = [parse(line) for line in raw.splitlines() if line.strip()]
        elif format == 'qualified_csv':
            reader = csv.DictReader(io.StringIO(raw.decode('utf-8'), newline=''))
            require(reader.fieldnames == ['observed_utc', 'source_timestamp_utc', 'contract',
                                          'record_type', 'payload'], 'CSV_SCHEMA')
            rows = []
            for wrapper in reader:
                require(set(wrapper) == set(reader.fieldnames), 'CSV_SCHEMA')
                row = parse(wrapper['payload'])
                require(all(wrapper[k] == row.get(k, '') for k in reader.fieldnames[:-1]),
                        'CSV_PAYLOAD_IDENTITY_CONFLICT')
                rows.append(row)
        else:
            raise ValueError('UNSUPPORTED_ARTIFACT_FORMAT')
        require(all(type(row) is dict for row in rows), 'RECORD_OBJECT_REQUIRED')
        for index, row in enumerate(rows):
            self._rows[(artifact_id, index)] = evidence_json(row)
            if role == 'observations':
                self.observations.append(dict(artifact=artifact_id, row=index))
        self._artifacts[artifact_id] = dict(sha256=expected_sha256, format=format, role=role,
                                          bytes=len(raw), records=len(rows))

    def get(self, ref):
        exact(ref, 'artifact row')
        require(type(ref['artifact']) is str and type(ref['row']) is int and ref['row'] >= 0,
                'EXACT_RECORD_REFERENCE_REQUIRED')
        key = (ref['artifact'], ref['row'])
        require(key in self._rows, 'MISSING_REFERENCED_EVIDENCE')
        return parse(self._rows[key])

    def identity(self, ref):
        self.get(ref)
        return self._artifacts[ref['artifact']]['sha256'] + ':' + str(ref['row'])


REF_NAMES = ('observation', 'fair', 'quote', 'brti_delivery', 'brti_source', 'contract', 'context')


def convert_one(archive, mapping):
    exact(mapping, 'record_type entry_id evidence_id ' + ' '.join(REF_NAMES))
    kind = mapping['record_type']
    require(kind in ('EARLY_ORIGIN', 'FINAL_EVIDENCE'), 'MAPPING_KIND')
    require(mapping['observation'] in archive.observations, 'OBSERVATION_ROLE_REQUIRED')
    values = {name: archive.get(mapping[name]) for name in REF_NAMES}
    o, f, q, b, bs, c, context = (values[name] for name in REF_NAMES)
    require(o.get('version') == 1 and o.get('record_type') == 'OBSERVATION',
            'QUALIFIED_FORWARD_OBSERVATION_REQUIRED')
    require(o.get('signal_only') is True and o.get('orders') is False, 'SIGNAL_ONLY_REQUIRED')
    require(o.get('usable_frame') is True and o.get('brti_fresh') is True,
            'OBSERVATION_UNQUALIFIED')
    # This is preserved native metadata, NOT a place for guessed/default values.
    exact(context, 'runtime_commit run_id native_owner_epoch btc_owner_epoch decision_id '
          'decision_utc published_utc ticker early_policy_id final_policy_id '
          'quote_received_utc signal_only orders')
    require(context['runtime_commit'] == PR36 and context['signal_only'] is True
            and context['orders'] is False, 'PR36_CONTEXT_REQUIRED')
    validate_fair(canonical(f))
    require(f['artifact_sha256'] == ARTIFACT and f['weights_sha256'] == WEIGHTS,
            'FROZEN_MODEL_IDENTITY_REQUIRED')
    require(b.get('schema') == 'BTC15_BRTI_DELIVERY_V1' and b.get('ready') is True
            and b.get('signal_only') is True and b.get('orders') is False, 'BRTI_DELIVERY_UNQUALIFIED')
    decision = ms(f['decision_utc'])
    require(all(ms(value) == decision for value in (o['source_timestamp_utc'],
                context['decision_utc'], b['decision_utc'], q['source_time'])), 'EXACT_DECISION_JOIN_REQUIRED')
    ticker = o['contract']
    require(all(x == ticker for x in (f['ticker'], q['ticker'], b['ticker'],
                                      context['ticker'], c['ticker'])), 'CROSS_CONTRACT_JOIN')
    # Official metadata only: never use the dashboard's source+rounded-remaining timer.
    contract = dict(ticker=ticker, open_ts_ms=ms(c['open_time']), close_ts_ms=ms(c['close_time']),
                    target=c['floor_strike'])
    require(contract['target'] == f['target'] == o['market']['target'], 'TARGET_CONFLICT')
    observed = ms(o['observed_utc'])
    require(o['parity']['status'] == 'PASS' and o['parity']['contract'] == ticker
            and o['parity']['api_contract'] == ticker
            and 0 <= observed - ms(o['parity']['timestamp_utc']) <= 45000, 'PARITY_NOT_QUALIFIED')
    quotes, _ = replay_quote(q, q['source_time'], ticker, contract['close_ts_ms'], observed)
    market = o['market']
    require(tuple(market[k] for k in ('up_bid', 'up_ask', 'down_bid', 'down_ask')) == quotes,
            'EXACT_QUOTE_PROOF_MISMATCH')
    delivery = b['delivery']
    require(delivery['reason'] == 'QUALIFIED' and seconds_ms(delivery['decision_ts']) == decision,
            'BRTI_DELIVERY_CUTOFF')
    source = seconds_ms(b['source_ts'])
    require(bs.get('schema_version') == 2 and bs.get('index_id') == 'BRTI'
            and bs.get('status') == 'PRIMARY_OK' and bs.get('clean_for_qualification') is True
            and bs.get('signal_only') is True and bs.get('orders') is False,
            'BRTI_SOURCE_UNQUALIFIED')
    require(source == Fraction(timestamp(bs['source_ts_ms']), 1000)
            and delivery['owner_epoch'] == bs['owner_epoch']
            and bs['value'] == market['brti_value'], 'EXACT_BRTI_PUBLICATION_REQUIRED')
    require(market['brti_ready'] is True and f['btc_price'] == market['btc_price'], 'SOURCE_VALUE_CONFLICT')
    require(seconds_ms(b['age_at_decision']) == decision - source
            and seconds_ms(market['brti_age_seconds']) == decision - source,
            'BRTI_SOURCE_AGE_CONFLICT')
    checked = seconds_ms(delivery['checked_ts'])
    require(decision <= checked <= ms(context['published_utc']) <= observed
            and seconds_ms(delivery['current_age']) == checked - source, 'BRTI_DELIVERY_CLOCK_CONFLICT')
    lane = 'early' if kind == 'EARLY_ORIGIN' else 'final'
    item = o['lanes'][lane]
    raw = item['raw']
    require(type(raw['ready']) is bool and item['raw_ready'] is raw['ready'], 'LANE_GATE_CONFLICT')
    require(item['publication_eligible'] is raw['ready'] and item['source_qualified'] is raw['ready'],
            'LANE_QUALIFICATION_CONFLICT')
    require(raw['source'] == ('FROZEN_TIER1' if lane == 'early' else 'FROZEN_V4_6_FINAL'),
            'FROZEN_LANE_SOURCE_REQUIRED')
    row = dict(schema=SCHEMA, record_type=kind, entry_id=mapping['entry_id'],
               run_id=context['run_id'], side=raw['side'], model_id=f['artifact_sha256'],
               policy_id=context[lane + '_policy_id'], native_gate_passed=raw['ready'],
               observed_ts_ms=observed, contract=contract, signal_only=True, orders=False,
               native=dict(authority='AUTHORITATIVE_ACTION_STATE', runtime_commit=context['runtime_commit'],
                           owner_epoch=context['native_owner_epoch'], decision_id=context['decision_id'],
                           decision_ts_ms=decision, published_ts_ms=ms(context['published_utc'])),
               sources=dict(
                   quote=dict(proof_id=archive.identity(mapping['quote']), owner_epoch=q['epoch'],
                              source_ts_ms=q['identity'][3], receipt_ts_ms=ms(context['quote_received_utc']),
                              validated_ts_ms=q['consumed_ms'], ticker=ticker,
                              up_ask=quotes[1], down_ask=quotes[3], qualified=True),
                   brti=dict(proof_id=archive.identity(mapping['brti_source']), owner_epoch=bs['owner_epoch'],
                             source_ts_ms=source, receipt_ts_ms=seconds_ms(delivery['observed_ts']),
                             value=bs['value'], qualified=True),
                   btc=dict(proof_id=archive.identity(mapping['fair']), owner_epoch=context['btc_owner_epoch'],
                            source_ts_ms=ms(f['btc_source_utc']), receipt_ts_ms=ms(f['btc_observed_utc']),
                            value=f['btc_price'], qualified=True)))
    if kind == 'EARLY_ORIGIN':
        require(mapping['evidence_id'] is None, 'ORIGIN_MUST_NOT_NAME_FINAL_EVIDENCE')
        row.update(entry_ts_ms=decision, entry_price=raw['ask'])
    else:
        require(raw['side'] in ('UP', 'DOWN'), 'FINAL_SIDE_REQUIRED')
        confidence = raw['confidence']
        require(type(confidence) in (int, float) and 0 <= confidence <= 1, 'FINAL_CONFIDENCE_REQUIRED')
        row.update(evidence_id=mapping['evidence_id'],
                   probability_up=confidence if raw['side'] == 'UP' else 1 - confidence)
    row = wire_clocks(row)
    validate(row)  # Reuse all causal/immutable-origin requirements.
    return row


def adapt(archive, mappings):
    mappings = parse(canonical(list(mappings)))
    records, lineage, rejected, used = [], [], [], set()
    # Conflicting explicit mappings poison their identity; never first-wins.
    groups, origin_bindings = {}, {}
    def observation_key(m):
        try:
            return evidence_json(archive.get(m['observation']))
        except (KeyError, TypeError, ValueError):
            return canonical(m.get('observation'))

    def resolved_mapping(m):
        try:
            return evidence_json({**m, **{k: archive.get(m[k]) for k in REF_NAMES}})
        except (KeyError, TypeError, ValueError):
            return canonical(m)

    for m in mappings:
        if type(m) is dict and type(m.get('entry_id')) is str:
            key = (m.get('record_type'), m['entry_id'], m.get('evidence_id'))
            try:
                groups.setdefault(key, set()).add(resolved_mapping(m))
                if m.get('record_type') == 'EARLY_ORIGIN':
                    origin_bindings.setdefault(observation_key(m), set()).add(m['entry_id'])
            except TypeError:
                pass
    for index, m in enumerate(mappings):
        try:
            require(type(m) is dict, 'MAPPING_OBJECT_REQUIRED')
            key = (m.get('record_type'), m.get('entry_id'), m.get('evidence_id'))
            require(len(groups.get(key, ())) == 1, 'AMBIGUOUS_MAPPING')
            if m.get('record_type') == 'EARLY_ORIGIN':
                require(len(origin_bindings.get(observation_key(m), ())) == 1,
                        'AMBIGUOUS_ORIGIN_MAPPING')
            used.add(canonical(m['observation']))
            row = convert_one(archive, m)
            records.append(row)
            lineage.append(dict(mapping_index=index, references={k: m[k] for k in REF_NAMES},
                                artifact_records={k: archive.identity(m[k]) for k in REF_NAMES}))
        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            rejected.append(dict(mapping_index=index, mapping_sha256=sha(canonical(m).encode()),
                                 reason=str(exc) if isinstance(exc, ValueError) else 'MISSING_OR_INVALID_EVIDENCE_FIELD'))
    unmapped = [ref for ref in archive.observations if canonical(ref) not in used]
    result = replay(records).to_dict()
    return dict(schema='BTC15_PR36_ADAPTER_V1', converted_records=records, lineage=lineage,
                adapter_rejections=rejected, unmapped_observations=unmapped, replay=result,
                artifacts=dict(sorted(archive._artifacts.items())),
                production_connected=False, scoring_performed=False, signal_only=True, orders=False)


def load_manifest(path):
    path = Path(path)
    manifest = parse(path.read_bytes())
    exact(manifest, 'artifacts mappings')
    archive = Archive()
    for spec in manifest['artifacts']:
        exact(spec, 'id path sha256 format role')
        source = path.parent / spec['path']
        archive.add(spec['id'], source.read_bytes(), spec['sha256'], spec['format'], spec['role'])
    return archive, manifest['mappings']


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    archive, mappings = load_manifest(args.manifest)
    result = adapt(archive, mappings)
    with args.output.open('x') as stream:
        stream.write(canonical(result) + '\n')
