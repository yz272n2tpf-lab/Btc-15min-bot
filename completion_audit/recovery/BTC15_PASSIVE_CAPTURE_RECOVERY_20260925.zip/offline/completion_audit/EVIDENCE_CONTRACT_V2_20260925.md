# Evidence contract V2 — offline qualification PASS

Parent: `9ca8f33a14df3606556bdf027eaa4af6cfd2ebd5`, tree
`4273908a617aa1d900809adccee8edf1984cd8a3`. SIGNAL ONLY / NO ORDERS.

This qualifies an offline evidence representation, not a runtime capture patch,
a deployed logger, authentic live evidence, strategy performance or lifecycle
policy. No existing file, producer, V1 schema or historical evidence is rewritten.

## Version boundary and interfaces

- Historical `early_origin_replay.py` and `pr36_evidence_adapter.py` stay V1.
  Their six existing implementation/test files have pinned SHA256 identities in
  the companion JSON; all 32 existing tests, including producer counterexamples,
  remain unchanged and pass.
- New `pr36_evidence_adapter_v2.py` consumes the same hash-verified local manifest
  structure (`artifacts`, `mappings`) through its V2 Archive. All original seven
  explicit references remain mandatory; a new explicit `witnesses` reference is
  mandatory. `context` must now be `BTC15_NATIVE_CONTEXT_V2`. No implicit upgrade,
  default source proof, origin discovery, or V1-to-V2 migration is provided.
- Output uses `BTC15_PR36_ADAPTER_V2` and `BTC15_EARLY_ORIGIN_REPLAY_V2`.
  `early_origin_replay_v2.py` accepts only V2 normalized records. Historical V1
  records must continue through V1; a V2 label alone cannot grant eligibility.
- The common invariant validator is reused internally on a structural view of
  V2 fields. That view is never an emitted V1 artifact or modified producer
  proof. Quote validation in this view is explicitly the independent owner
  validation witness, never `consumed_ms`. V2 additionally re-verifies the full
  evidence envelope on direct replay.

Offline commands (outputs must not already exist):

```sh
PYTHONPATH=completion_audit:. python3 completion_audit/pr36_evidence_adapter_v2.py manifest.json --output report-v2.json
PYTHONPATH=completion_audit:. python3 completion_audit/early_origin_replay_v2.py rows-v2.jsonl --output replay-v2.json
```

## Closed V2 clock contract

| Field / location | Meaning and authority | Causal use |
|---|---|---|
| Witness `source_utc` | Independently preserved exact source timestamp; must equal the corresponding exact shared BRTI publication, quote exchange timestamp or fair-input BTC timestamp | Exact source age, never raw native float subtraction |
| Witness `received_utc` | Exact timestamp witnessed by the appropriate owner when receipt is established; may follow the native raw receipt clock | Availability must already be established by cutoff |
| Witness `validated_utc` | Owner validation of the exact bound source/book | Must be between receipt and witness recording, at/before cutoff |
| Witness `witnessed_utc` | When the owner actually recorded this independently timestamped witness | Must exist at/before cutoff; retrospective assertion is insufficient |
| Context `decision_utc` | Original native cutoff; exact join with observation, fair input, delivery and quote proof | Unchanged decision / EARLY origin timestamp |
| Original quote `consumed_ms` | Actual native producer's integer-ms consumption telemetry | Preserved as integer-ms telemetry; never presented as exact microseconds or validation time |
| Original BRTI delivery clocks and ages | Actual binary64/native numeric tokens, including receipt, selection/check, cutoff and age | Preserved byte-for-byte in original record text; internal float consistency only |
| Context `consumption_completed_utc.{quote,brti,btc}` | Independent exact witness that native consumption has completed, **not** an exact reconstruction of the producer's internal raw timestamp | Witness must follow owner availability and precede publication; quote/BRTI completion cannot precede cutoff |
| Context `published_utc` / `completed_publication_utc` | Separately witnessed native publication start / completion | Cutoff ≤ start ≤ completion ≤ observer receipt < official close |
| Observation `observed_utc` | Existing observer receipt timestamp | All sources still fresh at observation; no publication-based refresh |

Witness schema: `BTC15_SOURCE_WITNESSES_V2`, exactly `schema`, `quote`, `brti`,
`btc`. Each source has exactly `authority`, `clock_basis`, `owner_epoch`,
`source_utc`, `received_utc`, `validated_utc`, `witnessed_utc`, `payload_sha256`.

Authorities are `QUOTE_BOOK_OWNER`, `BRTI_DELIVERY_OWNER`, `BTC_SOURCE_OWNER`;
clock basis must be `OWNER_UTC_MICROSECOND_WITNESS`. BRTI means the local receipt
owner for the selected shared BRTI publication; its generation must match that
publication and native delivery. It does not equate a remote publication to a
local receipt. The quote hash binds ticker, epoch, exact book identity and the
complete event tape, excluding future native decision/consumption metadata. BRTI
binds the full selected shared-source record. BTC binds source epoch, value and
exact source/receipt timestamps. Nothing is populated from a later latest frame.
`bound_payloads` only computes these explicit joins; it creates no witness.

V2 native context retains every V1 identity/policy/safety field except the old
ambiguous `quote_received_utc`, now exclusively an owner-witness field. It adds
`schema`, `clock_basis=NATIVE_UTC_MICROSECOND_WITNESS`,
`completed_publication_utc` and closed `consumption_completed_utc`. PR36 runtime
identity stays required. A later instrumented build needs separate exact build
identity/equivalence qualification before its capture is trusted; V2 does not
whitelist a new runtime or authorize deployment.

The V2 normalized row retains the unchanged immutable entry and native/context
fields and adds closed `evidence={mapping,identities,documents}`. `mapping`
contains only explicitly supplied kind/origin/evidence identities. `identities`
retains each original artifact hash and row index; `documents` preserves the
original JSON record text (or exact JSONL line / CSV payload) including numeric
lexemes. Original artifact bytes and wrapper hashes must remain in the archive;
normalized records are not a substitute for those originals. They are checked
at archive ingress, and source/frame bindings are rechecked at replay. Hashes
provide integrity and joins, not authentication of the witness producer. Authentic
witness acquisition is still a separate uncompleted task.

ISO clocks retain original strings and allow at most six fractional digits;
comparison uses integer microseconds / exact fractions. Normalized clocks retain
integer milliseconds or exact three-decimal-place millisecond strings. No float
is converted into an exact provenance clock. Epoch conversions to binary64 occur
only in the explicitly separate telemetry-consistency checks, never eligibility.
Raw receipt/check floats can contain submicrosecond fractions; completion
witnesses can truthfully follow those operations without pretending equality.

## Proven counterexamples represented truthfully

The actual frozen quote producer on the preserved synthetic input emits
`consumed_ms=1577836920004`, after cutoff `00:02:00.000191Z`. V1 still rejects it
with `QUOTE_PROVENANCE_TIME`. V2 retains that field and can accept the fixture only
when a separately supplied pre-cutoff witness binds **that exact complete book**.
Replay verifies the original native proof at consumption/observation and the
same event tape at the independent owner validation time. Consumption cannot be
substituted for receipt/validation; a post-cutoff witness fails, as does the
preserved future-source counterexample. There is no backdating or refreshed age.

The actual frozen BRTI producer's raw age `1.0001909732818604` remains in the
original delivery/observation texts. V1 still rejects its unsupported exact-clock
interpretation. V2 verifies its internal binary64 consistency while deriving
causal eligibility exclusively from independent exact owner clocks and the
original exact native cutoff. It does **not** replace that age with `1.000191`.
An actual-format checked float with submicrosecond precision is likewise retained,
with a separate later completion witness. Raw floats without witnesses fail.

The existing 5.0s BRTI, 6.0s quote and 10.0s BTC ceilings stay unchanged and apply
through observer receipt. One microsecond beyond a cutoff or expiry still fails.

## Qualification and remaining limits

40/40 focused tests pass: the unchanged 32 plus 8 V2 tests with adversarial
subcases. Coverage includes raw text/JSON/CLI round trips, deterministic sub-ms
ordering, exact cutoff/expiry and contract-close boundaries, complete context,
wrong/missing epochs/hashes, post-cutoff sources and witnesses, mixed schema,
explicit/missing/ambiguous origins, repeats/conflicts, owner restart, rollover,
and explicit attribution of one FINAL observation to independent explicit origins.
No sorting, duplicate sampling or extra lifecycle event is introduced. Advice,
exit/re-entry policy and execution/fill remain undefined/unproven exactly as V1.

All new complete V2 witnesses are **synthetic January 2020 fixtures**. The actual
frozen producer methods are exercised only with those synthetic inputs and no
network worker. No authentic live pair was acquired or admitted. Existing
incomplete historical observations remain unusable; V2 cannot manufacture their
missing origin, native context, witnesses or explicit linkage.

There are no runtime capture hooks, queues, polling, storage workers, model
calls or deployment changes. Consequently no native enabled/disabled capture
performance or whole-loop runtime qualification is claimed. The offline adapter
has archive-sized memory use and is not installed in the native path. The
separate two-clock live-acceptance requirement is unchanged.

## One minimum next action

Prepare and qualify the **minimal passive V2 owner/native/observer capture patch
offline**, including true independent witness acquisition, exact producer-build
identity and enabled/disabled native output/state equivalence, without deployment.
If a witness cannot actually exist by cutoff, the capture must preserve rejection,
not revise PR36 timing. Future production deployment/restart still requires
separate explicit authorization. No tuning, scoring, lifecycle policy or orders.

Recovery ZIP is updated under its existing identity with this checkpoint, all
40 tests, V1 history, hashes and resume instructions. It remains a self-contained
offline source/test package plus incremental local Git history; restoring full
Git history requires base `852e9a4638eb487ffe5a307b79d039d2a9b747c1`.
