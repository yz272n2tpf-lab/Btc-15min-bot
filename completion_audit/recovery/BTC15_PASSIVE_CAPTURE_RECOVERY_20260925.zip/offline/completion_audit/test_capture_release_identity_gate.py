"""Synthetic contract counterexamples only; no runtime capture or deployment."""
from copy import deepcopy
import unittest

from early_origin_replay import PR36
from pr36_evidence_adapter_v2 import Archive, adapt
from test_evidence_contract_v2 import fixture_v2
from test_microsecond_origin_replay import add_micro

# The actual local V2 checkpoint is distinct from PR36. It is used only as an
# example truthful non-PR36 build identity, NOT a deployed capture release.
OTHER_BUILD = '9b5b02744d8e31307516efb5a33c5190d8c74e90'


def result(docs, mapping):
    archive = Archive()
    explicit = add_micro(archive, docs, mapping, 'synthetic-build-identity')
    return adapt(archive, [explicit])


class CaptureReleaseIdentityGate(unittest.TestCase):
    def test_truthful_non_pr36_runtime_identity_is_rejected(self):
        docs, mapping = fixture_v2()
        docs['context']['runtime_commit'] = OTHER_BUILD
        outcome = result(docs, mapping)
        self.assertEqual(outcome['converted_records'], [])
        self.assertEqual(outcome['adapter_rejections'][0]['reason'], 'PR36_CONTEXT_REQUIRED')

    def test_separate_strategy_and_capture_identity_fields_are_not_in_v2(self):
        for metadata in ({'strategy_commit': PR36, 'runtime_commit': OTHER_BUILD},
                         {'runtime_commit': PR36, 'capture_build_commit': OTHER_BUILD}):
            docs, mapping = fixture_v2()
            docs['context'].update(metadata)
            outcome = result(docs, mapping)
            self.assertEqual(outcome['converted_records'], [])
            self.assertEqual(outcome['adapter_rejections'][0]['reason'], 'SCHEMA_FIELDS')

    def test_normalized_replay_cannot_silently_relabel_build_identity(self):
        from early_origin_replay_v2 import replay
        docs, mapping = fixture_v2()
        accepted = result(docs, mapping)
        self.assertFalse(accepted['adapter_rejections'])
        row = deepcopy(accepted['converted_records'][0])
        row['native']['runtime_commit'] = OTHER_BUILD
        rejected = replay([row])
        self.assertEqual(len(rejected.lifecycles), 0)
        self.assertEqual(rejected.rejections[0].reason, 'NORMALIZED_EVIDENCE_MISMATCH')


if __name__ == '__main__':
    unittest.main()
