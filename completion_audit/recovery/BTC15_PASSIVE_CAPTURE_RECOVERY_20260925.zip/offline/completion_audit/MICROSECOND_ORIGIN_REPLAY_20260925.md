# Lossless offline clocks — 2026-09-25

Parent: `e2693b86e6469d92eb003f7cda8c3b0716fd5e78`.
Scope: offline timestamp compatibility only. SIGNAL ONLY / NO ORDERS.

## Representation and checks

The existing replay `_ts_ms` fields retain their units and names. They accept
either the existing nonnegative integer milliseconds or an exact decimal string
with three fractional digits, e.g. `"1790309361246.191"`. The latter represents
`1790309361246191` integer microseconds. JSON epoch floats are rejected.
Integer-millisecond inputs/outputs remain unchanged. Older readers that only
accept integers cannot consume the new fractional representation.

Replay compares integer microseconds, but stores each input record's original
clock representation in immutable canonical JSON. It never sorts records or
rewrites an EARLY timestamp, ID or price. Contract windows, freshness ceilings,
strict later-FINAL checks and receipt/publication causality use exact arithmetic.
No tolerance, rounding or boundary extension is introduced. Representation
differences are not silently merged into duplicate identity matches.

The adapter parses ISO timestamps with at most six fractional second digits and
minute-resolution timezone offsets. Unsupported precision is rejected before
`datetime` can truncate it. Epoch conversion uses integer datetime deltas and
exact rational milliseconds; it never uses floating POSIX timestamps.
Numeric source-second and age fields are parsed directly from JSON tokens as
Decimal, preserved in archive serialization and compared as exact fractions.
Values that cannot be represented as whole microseconds are rejected, including
submicrosecond discrepancies that a binary epoch float would hide. Existing
float subtraction artifacts in recorded durations are not rounded or repaired.
Other numeric model/quote fields retain their existing handling.

Original ISO strings and exact numeric clock values remain in detached archived
records; original artifact SHA-256 and row references remain in adapter lineage.
Hashes attest byte identity, not external authenticity. No source proof is added.
The frozen quote and fair-input validators remain unchanged. All explicit origin,
native-context, model, quote/BRTI, owner, contract, duplicate and conflict checks
remain required. Undefined advice/exit/re-entry policy remains undefined.

## Focused verification

29/29 tests pass: the unchanged 14 origin tests and nine adapter tests, plus six
new microsecond tests. New cases cover all normalized clock fields and CLI JSON
round-trips, one-microsecond event ordering, duplicate/conflict retention, immutable
origins, exact 5-second freshness and one-microsecond expiry, future receipts,
decision mismatches, last-microsecond contract validity and rollover isolation,
missing/ambiguous mappings/context/proofs, and unsupported precision rejection.
Fixtures are synthetic January 2020 data. No unrelated suites or scoring ran.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=completion_audit:. python3 -m unittest \
  completion_audit.test_early_origin_replay \
  completion_audit.test_pr36_evidence_adapter \
  completion_audit.test_microsecond_origin_replay -v
```

## Previously inspected real evidence only

The same `cost-cleanup/main_state.json` was read locally and checked against its
previous SHA-256, `8bef078381c72fab7ffbf53fa9d7dc1dd91ef8efbedef4db5b9e2a18d540618f`.
No other cohort, remote data, repository search or infrastructure was inspected.

Its source time `2026-09-25T04:09:21.246191+00:00` now round-trips exactly through
`"1790309361246.191"` and integer microseconds `1790309361246191`, back to the
original UTC string. Timestamp precision is no longer this snapshot's blocker.

**Real EARLY→FINAL pairs admitted: 0.** The adapter received this unchanged raw
snapshot and the actually preserved mapping list (empty): one unmapped observation,
zero converted records, zero lifecycles. No mapping or observer envelope was
manufactured to make the artifact reach a later gate. The remaining gaps are:

- No explicit EARLY origin or FINAL-to-origin mapping and no complete preserved
  native owner/decision/publication context.
- A dashboard snapshot is not a qualified-forward OBSERVATION; EARLY and FINAL
  readiness are both false and cannot establish an origin.
- No complete matching fair-input/quote event tape/BRTI delivery and publication
  bundle. Parity prose does not supply replayable source proof.
- Its timer uses source timestamp plus logged remaining time, not preserved
  official contract open/close evidence.

These gaps were already identified at the parent checkpoint. This pass does not
claim that matching archives exist elsewhere, recover absent data or certify
submicrosecond duration artifacts. It only resolves timestamp representation.

**Single minimum next ladder action:** supply one authentic, explicitly mapped
EARLY-origin→FINAL evidence bundle containing all seven required record types,
including complete native context and source proofs. Missing history cannot be
repaired by inference; without that bundle, real connected-lifecycle replay stays
blocked. This offline evidence step does not depend on two-clock live acceptance.

Production PR36 `3e552065e34a0a402bc3ca4598b57dff1f1c6e77` is untouched. The
qualified two-clock candidate `06261dbfbe6d8336a6886a4f2b349f33b06b6202` remains
undeployed; its separate live-acceptance requirement is unchanged. No deployment,
push/authentication, infrastructure access, model/threshold changes, policy
selection or orders occurred. This checkpoint is local only.
