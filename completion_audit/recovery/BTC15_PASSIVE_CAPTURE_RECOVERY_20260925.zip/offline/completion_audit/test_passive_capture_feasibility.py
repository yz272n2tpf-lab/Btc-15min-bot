"""Offline stop gate using actual frozen producers, not invented live evidence.

Synthetic January 2020 book/clock inputs exercise PR36 Provider.consume and
Delivery.select without starting workers, polling, model evaluation or orders.
No production patch is installed by this module.
"""
import ast
from copy import deepcopy
from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from btc15_brti_delivery_v1 import Delivery
from btc15_kalshi_quote_provenance_v1 import Book, Provider
from pr36_evidence_adapter import Archive, adapt, evidence_json
from test_pr36_evidence_adapter import OPEN
from test_microsecond_origin_replay import add_micro, micro_fixture

ROOT = Path(__file__).resolve().parents[1]
FROZEN_MAIN_BLOB = 'f547ab4238592910ed76fee61870cd18714d09f0'


def provider_output(docs, consumed_at, capture):
    """A passive byte copy after the real method returns cannot change its clock."""
    q = docs['quote']
    # Avoid __init__: it starts the real network worker. Execute consume intact.
    owner = object.__new__(Provider)
    owner.lock = threading.Lock()
    owner.ticker, owner.epoch = q['ticker'], q['epoch']
    owner.events, owner.close_ms = deepcopy(q['events']), OPEN + 900000
    owner.book = Book(owner.ticker)
    for event in owner.events:
        owner.book.apply(event)
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp)/'proof.json'
        with patch('btc15_kalshi_quote_provenance_v1.proof_path', return_value=path), \
                patch('btc15_kalshi_quote_provenance_v1.time.time', return_value=consumed_at), \
                patch('socket.socket', side_effect=AssertionError('NO NETWORK')):
            quotes = owner.consume(owner.ticker, q['source_time'], owner.close_ms)
            copied = path.read_bytes() if capture else None
            raw = path.read_bytes()
        state = deepcopy(dict(ticker=owner.ticker, epoch=owner.epoch,
                              events=owner.events, close_ms=owner.close_ms,
                              book=vars(owner.book)))
    return quotes, raw, state, copied


def converted(docs, mapping):
    archive = Archive()
    explicit = add_micro(archive, docs, mapping, 'synthetic-producer-counterexample')
    return adapt(archive, [explicit])


def quote_counterexample(late_source=False):
    docs, mapping = micro_fixture(191)
    if late_source:
        # The exchange event and actual receipt both follow the fixed cutoff.
        docs['quote']['events'][1]['msg']['ts_ms'] = OPEN + 120001
        docs['context']['quote_received_utc'] = '2020-01-01T00:02:00.001001+00:00'
    at = float(Decimal('1577836920.004001'))
    disabled = provider_output(docs, at, False)
    enabled = provider_output(docs, at, True)
    docs['quote'] = json.loads(enabled[1])
    result = converted(docs, mapping)
    return dict(docs=docs, result=result, disabled=disabled, enabled=enabled,
                actual_consumption_clock_seconds_repr=repr(at))


def delivery_counterexample():
    docs, mapping = micro_fixture(191)
    decision = datetime.fromisoformat(docs['context']['decision_utc']).timestamp()
    owner = Delivery()
    source = (OPEN + 119000)/1000
    owner.accept(80020, source, (OPEN + 119500)/1000, 'brti-owner')
    before = deepcopy((owner.states, owner.statuses, owner.seen, owner.epoch))
    native = owner.select(decision, decision)
    after = deepcopy((owner.states, owner.statuses, owner.seen, owner.epoch))
    # Mirror the existing native delivery log's fields exactly; do not repair age.
    docs['brti_delivery'].update(source_ts=native['cf_ts'], age_at_decision=native['age'],
                                  ready=native['ready'], delivery=deepcopy(native))
    docs['observation']['market']['brti_age_seconds'] = native['age']
    return dict(docs=docs, result=converted(docs, mapping), before=before, after=after,
                native=native, exact_iso_decision_age_seconds='1.000191')


class PassiveCaptureFeasibilityTests(unittest.TestCase):
    def test_actual_quote_producer_rejects_even_with_source_present_before_cutoff(self):
        raw = (ROOT/'bot_two_output_build_v4_13_profit_protection_shadow.py').read_bytes()
        self.assertEqual(hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest(), FROZEN_MAIN_BLOB)
        tree = ast.parse(raw)
        calls = {name: [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Call)
                       and isinstance(n.func, ast.Name) and n.func.id == name]
                 for name in ('decision_time', 'consume_ws_quotes')}
        self.assertLess(calls['decision_time'][0], calls['consume_ws_quotes'][0])
        case = quote_counterexample()
        self.assertEqual(case['disabled'][:3], case['enabled'][:3])
        self.assertEqual(case['enabled'][1], case['enabled'][3])
        self.assertEqual(case['enabled'][0], (.34, .35, .65, .66))
        self.assertEqual(case['docs']['quote']['consumed_ms'], OPEN + 120004)
        self.assertEqual(case['docs']['context']['decision_utc'], '2020-01-01T00:02:00.000191+00:00')
        self.assertEqual(case['result']['converted_records'], [])
        self.assertEqual(case['result']['adapter_rejections'][0]['reason'], 'QUOTE_PROVENANCE_TIME')
        # Even newly captured independent receipt/validation fields cannot fix
        # this binding: the unchanged adapter uses consumed_ms as validated time.
        docs = deepcopy(case['docs'])
        docs['quote']['passive_validated_utc'] = '2020-01-01T00:01:59.900000+00:00'
        self.assertEqual(converted(docs, micro_fixture()[1])['adapter_rejections'][0]['reason'],
                         'QUOTE_PROVENANCE_TIME')

    def test_future_exchange_event_is_captured_truthfully_and_never_backdated(self):
        case = quote_counterexample(late_source=True)
        self.assertEqual(case['disabled'][:3], case['enabled'][:3])
        self.assertEqual(case['docs']['quote']['identity'][3], OPEN + 120001)
        self.assertEqual(case['result']['converted_records'], [])
        self.assertEqual(case['result']['adapter_rejections'][0]['reason'], 'SOURCE_NOT_CAUSALLY_AVAILABLE')

    def test_native_float_age_cannot_be_replaced_by_exact_iso_age(self):
        case = delivery_counterexample()
        self.assertEqual(case['before'], case['after'])
        self.assertTrue(case['native']['ready'])
        raw_age = Decimal(str(case['native']['age']))
        self.assertNotEqual(raw_age, Decimal(case['exact_iso_decision_age_seconds']))
        self.assertNotEqual(raw_age*1000000, (raw_age*1000000).to_integral_value())
        self.assertEqual(case['result']['converted_records'], [])
        self.assertEqual(case['result']['adapter_rejections'][0]['reason'],
                         'SUBMICROSECOND_CLOCK_NOT_REPRESENTABLE')
        self.assertIn(str(case['native']['age']), evidence_json(case['docs']['brti_delivery']))


if __name__ == '__main__':
    unittest.main()
