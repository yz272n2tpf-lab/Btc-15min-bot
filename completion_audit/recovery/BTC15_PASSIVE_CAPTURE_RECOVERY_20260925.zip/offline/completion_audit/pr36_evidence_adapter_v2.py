"""V2 offline adapter: independent owner clocks; untouched raw PR36 telemetry.

No runtime hooks, inferred origins, float-to-exact-clock conversion, or live I/O.
V1 modules and historical records retain their original meaning.
"""
from decimal import Decimal
from fractions import Fraction
import math
import csv
import io
from pathlib import Path
import re

from early_origin_replay import (PR36, SCHEMA as V1_SCHEMA, canonical, exact,
                                 require, timestamp, validate as validate_v1)
from pr36_evidence_adapter import (ARTIFACT, WEIGHTS, REF_NAMES as V1_REFS, Archive as ArchiveV1,
    evidence_json, ms, parse, replay_quote, sha, validate_fair, wire_clocks)
from early_origin_replay_v2 import SCHEMA, replay

REF_NAMES = V1_REFS + ('witnesses',)
OWNER_ROLES = {'quote': 'QUOTE_BOOK_OWNER', 'brti': 'BRTI_DELIVERY_OWNER', 'btc': 'BTC_SOURCE_OWNER'}


class Archive(ArchiveV1):
    """V1 hash/schema verification plus lossless original record text for V2."""
    def __init__(self):
        super().__init__()
        self._raw_records = {}

    def add(self, artifact_id, raw, expected_sha256, format='json', role='evidence'):
        super().add(artifact_id, raw, expected_sha256, format, role)
        text = raw.decode('utf-8')
        if format == 'json':
            rows = [text]
        elif format == 'jsonl':
            rows = [line for line in text.splitlines() if line.strip()]
        else:
            rows = [row['payload'] for row in csv.DictReader(io.StringIO(text, newline=''))]
        for index, row in enumerate(rows):
            self._raw_records[(artifact_id, index)] = row

    def raw_record(self, ref):
        self.get(ref)
        return self._raw_records[(ref['artifact'], ref['row'])]


def load_manifest(path):
    path = Path(path)
    manifest = parse(path.read_bytes())
    exact(manifest, 'artifacts mappings')
    archive = Archive()
    for spec in manifest['artifacts']:
        exact(spec, 'id path sha256 format role')
        archive.add(spec['id'], (path.parent / spec['path']).read_bytes(), spec['sha256'],
                    spec['format'], spec['role'])
    return archive, manifest['mappings']


def bound_payloads(values):
    """Only data actually available to each owner; no future decision identifiers."""
    q, f, c = (values[k] for k in ('quote', 'fair', 'context'))
    return dict(quote={k: q[k] for k in ('ticker', 'epoch', 'identity', 'events')},
                brti=values['brti_source'],
                btc=dict(owner_epoch=c['btc_owner_epoch'], value=f['btc_price'],
                         source_utc=f['btc_source_utc'], received_utc=f['btc_observed_utc']))


def native_float(value):
    """Check telemetry only. This must never return an exact clock."""
    require(type(value) in (int, float, Decimal), 'RAW_NATIVE_NUMBER_REQUIRED')
    result = float(value)
    require(math.isfinite(result), 'RAW_NATIVE_NUMBER_REQUIRED')
    return result


def validate_witnesses(values, decision, observed, contract, quotes):
    w, c, q, b, bs, f = (values[k] for k in
                         ('witnesses', 'context', 'quote', 'brti_delivery', 'brti_source', 'fair'))
    exact(w, 'schema quote brti btc')
    require(w['schema'] == 'BTC15_SOURCE_WITNESSES_V2', 'SOURCE_WITNESS_VERSION')
    exact(c['consumption_completed_utc'], 'quote brti btc')
    published, completed = ms(c['published_utc']), ms(c['completed_publication_utc'])
    require(decision <= published <= completed <= observed, 'PUBLICATION_CLOCK_ORDER')
    payloads = bound_payloads(values)
    epochs = dict(quote=q['epoch'], brti=bs['owner_epoch'], btc=c['btc_owner_epoch'])
    sources = dict(quote=Fraction(timestamp(q['identity'][3]), 1000),
                   brti=Fraction(timestamp(bs['source_ts_ms']), 1000), btc=ms(f['btc_source_utc']))
    clocks = {}
    for name in ('quote', 'brti', 'btc'):
        witness = w[name]
        exact(witness, 'authority clock_basis owner_epoch source_utc received_utc '
              'validated_utc witnessed_utc payload_sha256')
        require(witness['authority'] == OWNER_ROLES[name] and
                witness['clock_basis'] == 'OWNER_UTC_MICROSECOND_WITNESS', 'INDEPENDENT_OWNER_WITNESS_REQUIRED')
        require(witness['owner_epoch'] == epochs[name], 'WITNESS_OWNER_MISMATCH')
        require(witness['payload_sha256'] == sha(evidence_json(payloads[name]).encode()),
                'WITNESS_PAYLOAD_MISMATCH')
        clock = {key: ms(witness[key + '_utc']) for key in ('source', 'received', 'validated', 'witnessed')}
        consumed = ms(c['consumption_completed_utc'][name])
        require(clock['source'] == sources[name], 'WITNESSED_SOURCE_IDENTITY_MISMATCH')
        # Both the data and the independently recorded witness must exist by cutoff.
        require(clock['source'] <= clock['received'] <= clock['validated'] <= clock['witnessed'] <= decision,
                'SOURCE_NOT_INDEPENDENTLY_AVAILABLE_AT_CUTOFF')
        require(clock['witnessed'] <= consumed <= published, 'NATIVE_CONSUMPTION_CLOCK_ORDER')
        clocks[name] = {**clock, 'consumed': consumed}
    require(clocks['btc']['received'] == ms(f['btc_observed_utc']), 'BTC_RECEIPT_WITNESS_MISMATCH')
    # This is the independent completion witness, not a reconstruction of the
    # native rounded consumption clock. It may follow the actual operation.
    require(decision <= clocks['quote']['consumed'] and type(q['consumed_ms']) is int
            and q['consumed_ms'] <= clocks['quote']['consumed'],
            'RAW_QUOTE_CONSUMPTION_ORDER')
    # Replay the SAME book at the independently witnessed validation clock.
    # Do not rewrite consumed_ms/source_time to pass the frozen proof replayer.
    from btc15_kalshi_quote_provenance_v1 import Book
    book = Book(q['ticker'])
    for event in q['events']:
        book.apply(event)
    require(book.quotes(clocks['quote']['validated'], contract['close_ts_ms']) == quotes,
            'PRE_CUTOFF_BOOK_NOT_VALID')
    d = b['delivery']
    # Binary64 consistency is diagnostic only: exact causal comparisons above
    # never use these values. Preserve original JSON tokens in row.evidence.
    # Only these two native fields have independently known exact input clocks:
    # the shared publication timestamp and the original decision datetime.
    for raw, exact_clock in ((b['source_ts'], clocks['brti']['source']),
                             (d['decision_ts'], decision)):
        require(native_float(raw) == float(exact_clock / 1000), 'RAW_NATIVE_CLOCK_WITNESS_MISMATCH')
    require(decision <= clocks['brti']['consumed'], 'BRTI_CHECK_BEFORE_CUTOFF')
    # Raw receipt/check clocks remain binary64 telemetry. Exact owner receipt and
    # native consumption COMPLETION witnesses may follow those operations; they
    # need not (and often cannot) equal the raw submicrosecond numeric tokens.
    require(native_float(b['source_ts']) <= native_float(d['observed_ts']) <=
            native_float(d['decision_ts']) <= native_float(d['checked_ts']), 'RAW_DELIVERY_CLOCK_ORDER')
    require(native_float(d['observed_ts']) <= float(clocks['brti']['received'] / 1000)
            and native_float(d['checked_ts']) <= float(clocks['brti']['consumed'] / 1000),
            'RAW_DELIVERY_AFTER_COMPLETION_WITNESS')
    age = native_float(d['decision_ts']) - native_float(b['source_ts'])
    current_age = native_float(d['checked_ts']) - native_float(b['source_ts'])
    require(native_float(b['age_at_decision']) == age and
            native_float(values['observation']['market']['brti_age_seconds']) == age and
            native_float(d['current_age']) == current_age, 'RAW_NATIVE_AGE_CONFLICT')
    # Actual Delivery.select records have these fields; older wrapper-only
    # records may omit them. If present they must agree, never fill defaults.
    for key, expected in (('cf_ts', native_float(b['source_ts'])), ('age', age),
                          ('value', bs['value'])):
        if key in d:
            require(native_float(d[key]) == expected, 'RAW_DELIVERY_CONFLICT')
    if 'ready' in d:
        require(d['ready'] is True, 'RAW_DELIVERY_CONFLICT')
    return clocks


def convert_values(values, mapping, identities):
    exact(mapping, 'record_type entry_id evidence_id')
    kind = mapping['record_type']
    require(kind in ('EARLY_ORIGIN', 'FINAL_EVIDENCE'), 'MAPPING_KIND')
    o, f, q, b, bs, c, context = (values[name] for name in V1_REFS)
    require(o.get('version') == 1 and o.get('record_type') == 'OBSERVATION',
            'QUALIFIED_FORWARD_OBSERVATION_REQUIRED')
    require(o.get('signal_only') is True and o.get('orders') is False, 'SIGNAL_ONLY_REQUIRED')
    require(o.get('usable_frame') is True and o.get('brti_fresh') is True,
            'OBSERVATION_UNQUALIFIED')
    # This is preserved native metadata, NOT a place for guessed/default values.
    exact(context, 'schema clock_basis runtime_commit run_id native_owner_epoch btc_owner_epoch decision_id '
          'decision_utc published_utc completed_publication_utc ticker early_policy_id final_policy_id '
          'consumption_completed_utc signal_only orders')
    require(context['schema'] == 'BTC15_NATIVE_CONTEXT_V2' and
            context['clock_basis'] == 'NATIVE_UTC_MICROSECOND_WITNESS', 'NATIVE_CLOCK_WITNESS_REQUIRED')
    require(context['runtime_commit'] == PR36 and context['signal_only'] is True
            and context['orders'] is False, 'PR36_CONTEXT_REQUIRED')
    validate_fair(canonical(f))
    require(f['artifact_sha256'] == ARTIFACT and f['weights_sha256'] == WEIGHTS,
            'FROZEN_MODEL_IDENTITY_REQUIRED')
    require(b.get('schema') == 'BTC15_BRTI_DELIVERY_V1' and b.get('ready') is True
            and b.get('signal_only') is True and b.get('orders') is False, 'BRTI_DELIVERY_UNQUALIFIED')
    decision = ms(f['decision_utc'])
    require(all(ms(value) == decision for value in (o['source_timestamp_utc'],
                context['decision_utc'], b['decision_utc'], q['source_time'])), 'EXACT_DECISION_JOIN_REQUIRED')
    ticker = o['contract']
    require(all(x == ticker for x in (f['ticker'], q['ticker'], b['ticker'],
                                      context['ticker'], c['ticker'])), 'CROSS_CONTRACT_JOIN')
    # Official metadata only: never use the dashboard's source+rounded-remaining timer.
    contract = dict(ticker=ticker, open_ts_ms=ms(c['open_time']), close_ts_ms=ms(c['close_time']),
                    target=c['floor_strike'])
    require(contract['target'] == f['target'] == o['market']['target'], 'TARGET_CONFLICT')
    observed = ms(o['observed_utc'])
    require(o['parity']['status'] == 'PASS' and o['parity']['contract'] == ticker
            and o['parity']['api_contract'] == ticker
            and 0 <= observed - ms(o['parity']['timestamp_utc']) <= 45000, 'PARITY_NOT_QUALIFIED')
    quotes, _ = replay_quote(q, q['source_time'], ticker, contract['close_ts_ms'], observed)
    market = o['market']
    require(tuple(market[k] for k in ('up_bid', 'up_ask', 'down_bid', 'down_ask')) == quotes,
            'EXACT_QUOTE_PROOF_MISMATCH')
    delivery = b['delivery']
    require(delivery['reason'] == 'QUALIFIED', 'BRTI_DELIVERY_UNQUALIFIED')
    require(bs.get('schema_version') == 2 and bs.get('index_id') == 'BRTI'
            and bs.get('status') == 'PRIMARY_OK' and bs.get('clean_for_qualification') is True
            and bs.get('signal_only') is True and bs.get('orders') is False,
            'BRTI_SOURCE_UNQUALIFIED')
    require(delivery['owner_epoch'] == bs['owner_epoch']
            and bs['value'] == market['brti_value'], 'EXACT_BRTI_PUBLICATION_REQUIRED')
    require(market['brti_ready'] is True and f['btc_price'] == market['btc_price'], 'SOURCE_VALUE_CONFLICT')
    clocks = validate_witnesses(values, decision, observed, contract, quotes)
    source = clocks['brti']['source']
    lane = 'early' if kind == 'EARLY_ORIGIN' else 'final'
    item = o['lanes'][lane]
    raw = item['raw']
    require(type(raw['ready']) is bool and item['raw_ready'] is raw['ready'], 'LANE_GATE_CONFLICT')
    require(item['publication_eligible'] is raw['ready'] and item['source_qualified'] is raw['ready'],
            'LANE_QUALIFICATION_CONFLICT')
    require(raw['source'] == ('FROZEN_TIER1' if lane == 'early' else 'FROZEN_V4_6_FINAL'),
            'FROZEN_LANE_SOURCE_REQUIRED')
    row = dict(schema=SCHEMA, record_type=kind, entry_id=mapping['entry_id'],
               run_id=context['run_id'], side=raw['side'], model_id=f['artifact_sha256'],
               policy_id=context[lane + '_policy_id'], native_gate_passed=raw['ready'],
               observed_ts_ms=observed, contract=contract, signal_only=True, orders=False,
               native=dict(authority='AUTHORITATIVE_ACTION_STATE', runtime_commit=context['runtime_commit'],
                           owner_epoch=context['native_owner_epoch'], decision_id=context['decision_id'],
                           decision_ts_ms=decision, published_ts_ms=ms(context['published_utc'])),
               sources=dict(
                   quote=dict(proof_id=identities['quote'], owner_epoch=q['epoch'],
                              source_ts_ms=q['identity'][3], receipt_ts_ms=clocks['quote']['received'],
                              validated_ts_ms=clocks['quote']['validated'], ticker=ticker,
                              up_ask=quotes[1], down_ask=quotes[3], qualified=True),
                   brti=dict(proof_id=identities['brti_source'], owner_epoch=bs['owner_epoch'],
                             source_ts_ms=source, receipt_ts_ms=clocks['brti']['received'],
                             value=bs['value'], qualified=True),
                   btc=dict(proof_id=identities['fair'], owner_epoch=context['btc_owner_epoch'],
                            source_ts_ms=ms(f['btc_source_utc']), receipt_ts_ms=ms(f['btc_observed_utc']),
                            value=f['btc_price'], qualified=True)))
    if kind == 'EARLY_ORIGIN':
        require(mapping['evidence_id'] is None, 'ORIGIN_MUST_NOT_NAME_FINAL_EVIDENCE')
        row.update(entry_ts_ms=decision, entry_price=raw['ask'])
    else:
        require(raw['side'] in ('UP', 'DOWN'), 'FINAL_SIDE_REQUIRED')
        confidence = raw['confidence']
        require(type(confidence) in (int, float) and 0 <= confidence <= 1, 'FINAL_CONFIDENCE_REQUIRED')
        row.update(evidence_id=mapping['evidence_id'],
                   probability_up=confidence if raw['side'] == 'UP' else 1 - confidence)
    row = wire_clocks(row)
    # Reuse only the unchanged common invariant validator, never the V1 converter.
    # This private structural view is not a V1 artifact or rewritten producer proof.
    validate_v1({**row, 'schema': V1_SCHEMA})
    return row


def convert_one(archive, mapping):
    exact(mapping, 'record_type entry_id evidence_id ' + ' '.join(REF_NAMES))
    require(mapping['observation'] in archive.observations, 'OBSERVATION_ROLE_REQUIRED')
    values = {name: archive.get(mapping[name]) for name in REF_NAMES}
    identities = {name: archive.identity(mapping[name]) for name in REF_NAMES}
    explicit = {k: mapping[k] for k in ('record_type', 'entry_id', 'evidence_id')}
    row = convert_values(values, explicit, identities)
    # Decimal clock/age tokens stay text inside JSON, so Record.to_dict cannot
    # inadvertently coerce them to binary float. Original artifact hashes remain.
    row['evidence'] = dict(mapping=explicit, identities=identities,
                          documents={k: archive.raw_record(mapping[k]) for k in REF_NAMES})
    return row


def validate(row):
    """Re-verify all V2 provenance when a normalized row is replayed directly."""
    require(type(row) is dict and row.get('schema') == SCHEMA, 'SCHEMA_VERSION')
    e = row.get('evidence')
    exact(e, 'mapping identities documents')
    exact(e['documents'], ' '.join(REF_NAMES)); exact(e['identities'], ' '.join(REF_NAMES))
    for identity in e['identities'].values():
        require(type(identity) is str and re.fullmatch(r'[0-9a-f]{64}:[0-9]+', identity),
                'ARTIFACT_RECORD_IDENTITY_REQUIRED')
    values = {}
    for name, document in e['documents'].items():
        require(type(document) is str, 'RAW_EVIDENCE_JSON_REQUIRED')
        values[name] = parse(document)
    expected = convert_values(values, e['mapping'], e['identities'])
    require(canonical({k: v for k, v in row.items() if k != 'evidence'}) == canonical(expected),
            'NORMALIZED_EVIDENCE_MISMATCH')

def adapt(archive, mappings):
    mappings = parse(canonical(list(mappings)))
    records, lineage, rejected, used = [], [], [], set()
    # Conflicting explicit mappings poison their identity; never first-wins.
    groups, origin_bindings = {}, {}
    def observation_key(m):
        try:
            return evidence_json(archive.get(m['observation']))
        except (KeyError, TypeError, ValueError):
            return canonical(m.get('observation'))

    def resolved_mapping(m):
        try:
            return evidence_json({**m, **{k: archive.raw_record(m[k]) for k in REF_NAMES}})
        except (KeyError, TypeError, ValueError):
            return canonical(m)

    for m in mappings:
        if type(m) is dict and type(m.get('entry_id')) is str:
            key = (m.get('record_type'), m['entry_id'], m.get('evidence_id'))
            try:
                groups.setdefault(key, set()).add(resolved_mapping(m))
                if m.get('record_type') == 'EARLY_ORIGIN':
                    origin_bindings.setdefault(observation_key(m), set()).add(m['entry_id'])
            except TypeError:
                pass
    for index, m in enumerate(mappings):
        try:
            require(type(m) is dict, 'MAPPING_OBJECT_REQUIRED')
            key = (m.get('record_type'), m.get('entry_id'), m.get('evidence_id'))
            require(len(groups.get(key, ())) == 1, 'AMBIGUOUS_MAPPING')
            if m.get('record_type') == 'EARLY_ORIGIN':
                require(len(origin_bindings.get(observation_key(m), ())) == 1,
                        'AMBIGUOUS_ORIGIN_MAPPING')
            used.add(canonical(m['observation']))
            row = convert_one(archive, m)
            records.append(row)
            lineage.append(dict(mapping_index=index, references={k: m[k] for k in REF_NAMES},
                                artifact_records={k: archive.identity(m[k]) for k in REF_NAMES}))
        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            rejected.append(dict(mapping_index=index, mapping_sha256=sha(canonical(m).encode()),
                                 reason=str(exc) if isinstance(exc, ValueError) else 'MISSING_OR_INVALID_EVIDENCE_FIELD'))
    unmapped = [ref for ref in archive.observations if canonical(ref) not in used]
    result = replay(records).to_dict()
    return dict(schema='BTC15_PR36_ADAPTER_V2', converted_records=records, lineage=lineage,
                adapter_rejections=rejected, unmapped_observations=unmapped, replay=result,
                artifacts=dict(sorted(archive._artifacts.items())),
                production_connected=False, scoring_performed=False, signal_only=True, orders=False)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    archive, mappings = load_manifest(args.manifest)
    with args.output.open('x') as stream:
        stream.write(canonical(adapt(archive, mappings)) + '\n')
