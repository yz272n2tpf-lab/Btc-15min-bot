"""V2 offline linkage with unchanged origin/advice semantics; never accepts V1 rows.

The linkage algorithm is preserved from V1. V2 additionally verifies its full
provenance envelope, and includes it in frame/source conflict detection.
"""
import json
from early_origin_replay import (Lifecycle, Record, Rejection, Replay as ReplayV1,
    canonical, digest, require, timestamp, unique_object)

SCHEMA = 'BTC15_EARLY_ORIGIN_REPLAY_V2'


class Replay(ReplayV1):
    def to_dict(self):
        return {**super().to_dict(), 'schema': SCHEMA}


def validate(row):
    from pr36_evidence_adapter_v2 import validate as validate_v2
    validate_v2(row)


def proof_value(row, name):
    from pr36_evidence_adapter import parse
    witness = parse(row['evidence']['documents']['witnesses'])[name]
    return canonical(dict(source=row['sources'][name], witness=witness))


def replay(records):
    """Consume recorded observation order. Never sort away future/late evidence.

    Explicit multiple origins are retained as independent replay cases, not
    approved re-entries. A FINAL record must name its exact EARLY entry_id.
    Unqualified/rejected evidence stays in the rejection ledger; it cannot
    provide HOLD or carry any previous assessment forward as current advice.
    """
    rows = json.loads(canonical(list(records)))  # detach caller-owned dictionaries
    lives, seen, native_seen, contracts, proof_seen = {}, {}, {}, {}, {}
    evidence_seen, policies, native_frames = {}, {}, {}
    rejected, duplicate_count, last_observed, last_decision = [], 0, -1, -1
    run_id = model_id = None
    for index, row in enumerate(rows):
        encoded = canonical(row)
        try:
            validate(row)
            kind, n, c = row['record_type'], row['native'], row['contract']
            key = (kind, row['entry_id'], row.get('evidence_id'))
            require(run_id is None or row['run_id'] == run_id, 'MIXED_RUN_IDENTITIES')
            require(model_id is None or row['model_id'] == model_id, 'MODEL_IDENTITY_CHANGED')
            require(kind not in policies or policies[kind] == row['policy_id'],
                    'FROZEN_POLICY_IDENTITY_CHANGED')
            if key in seen:
                require(seen[key] == encoded, 'CONFLICTING_RECORD_IDENTITY')
                duplicate_count += 1
                continue
            observed, decision = timestamp(row['observed_ts_ms']), timestamp(n['decision_ts_ms'])
            require(observed >= last_observed and decision >= last_decision,
                    'OUT_OF_ORDER_RECORD')
            contract_id = c['ticker']
            require(contract_id not in contracts or contracts[contract_id] == c,
                    'CONTRACT_IDENTITY_CONFLICT')
            frame_key = (n['owner_epoch'], n['decision_id'])
            frame_value = canonical(dict(native=n, contract=c, model_id=row['model_id'],
                                         sources=row['sources'], evidence={k: row['evidence'][k] for k in ('documents', 'identities')}))
            require(frame_key not in native_frames or native_frames[frame_key] == frame_value,
                    'NATIVE_FRAME_IDENTITY_CONFLICT')
            # Same decision cannot acquire a new origin ID or changed evidence
            # through repeated sampling. One FINAL observation may explicitly
            # reference several independent origins, retaining the same payload.
            native_key = (kind, n['owner_epoch'], n['decision_id'])
            payload = {k: v for k, v in row.items() if k not in ('entry_id', 'evidence_id')}
            payload['evidence'] = {**row['evidence'], 'mapping': {k: v for k, v in
                row['evidence']['mapping'].items() if k not in ('entry_id', 'evidence_id')}}
            native_value = (row['entry_id'] if kind == 'EARLY_ORIGIN' else row['evidence_id'],
                            canonical(payload))
            require(native_key not in native_seen or native_seen[native_key] == native_value,
                    'NATIVE_DECISION_IDENTITY_CONFLICT')
            for name, source in row['sources'].items():
                proof_key = (name, source['owner_epoch'], source['proof_id'])
                require(proof_key not in proof_seen or proof_seen[proof_key] == proof_value(row, name),
                        'SOURCE_PROOF_IDENTITY_CONFLICT')
            if kind == 'EARLY_ORIGIN':
                life = Lifecycle(Record(encoded))
            else:
                require(row['evidence_id'] not in evidence_seen
                        or evidence_seen[row['evidence_id']] == canonical(payload),
                        'FINAL_EVIDENCE_IDENTITY_CONFLICT')
                require(row['entry_id'] in lives, 'UNKNOWN_EARLY_ORIGIN')
                prior = lives[row['entry_id']]
                origin = prior.origin.to_dict()
                require(c == origin['contract'], 'ORIGIN_CONTRACT_MISMATCH')
                require(n['owner_epoch'] == origin['native']['owner_epoch'],
                        'OWNER_RESTART_LINK_UNDEFINED')
                require(row['model_id'] == origin['model_id'], 'MODEL_IDENTITY_CHANGED')
                require(decision > timestamp(origin['entry_ts_ms'])
                        and n['decision_id'] != origin['native']['decision_id'],
                        'FINAL_NOT_SUBSEQUENT_TO_ORIGIN')
                life = Lifecycle(prior.origin, prior.final_evidence + (Record(encoded),))
            # Only fully accepted records commit replay bookkeeping.
            lives[row['entry_id']] = life
            seen[key] = encoded
            native_seen[native_key] = native_value
            native_frames[frame_key] = frame_value
            if kind == 'FINAL_EVIDENCE':
                evidence_seen[row['evidence_id']] = canonical(payload)
            policies[kind] = row['policy_id']
            contracts[contract_id] = c
            for name, source in row['sources'].items():
                proof_seen[(name, source['owner_epoch'], source['proof_id'])] = proof_value(row, name)
            run_id = row['run_id']
            model_id = row['model_id']
            last_observed, last_decision = observed, decision
        except (ValueError, KeyError, TypeError, OverflowError) as exc:
            rejected.append(Rejection(index, digest(encoded), str(exc) if isinstance(exc, ValueError)
                                      else 'MISSING_OR_INVALID_EVIDENCE_FIELD'))
    return Replay(tuple(lives.values()), tuple(rejected), duplicate_count, digest(canonical(rows)))



if __name__ == '__main__':
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path, help='Explicit normalized JSONL records; no live fetch')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    with args.input.open() as stream:
        records = [json.loads(line, object_pairs_hook=unique_object) for line in stream if line.strip()]
    result = replay(records).to_dict()
    with args.output.open('x') as stream:
        stream.write(canonical(result) + '\n')
