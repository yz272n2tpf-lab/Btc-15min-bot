BTC15 existing repair, SAFE STAGING ONLY

Upload this ZIP into the root of the existing GitHub Codespaces BTC15 repository and run:

unzip BTC15_STAGE_EXISTING_REPAIR_20261008.zip && python3 stage_btc15_repair.py --run-tests

This creates a DETACHED ISOLATED LOCAL Git worktree from protected MAIN 1bd5b44, installs the existing repair files there and checks safety/dependency/manifest gates. It NEVER deploys, pushes, modifies the live branch, or places orders. If the exact pinned Python dependencies are absent, it stops without claiming tests pass. The preserved repair checkpoint 533a722b requires SCALP base 2e1edac; applying its changed-file snapshot onto production MAIN is a candidate assembly requiring manifest validation, not a claim of exact commit reproduction.
