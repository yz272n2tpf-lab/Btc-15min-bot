#!/usr/bin/env python3
"""Stage BTC15 continuity repair into a DETACHED LOCAL worktree, never production.

This tool is intentionally offline and never starts a bot or runs network calls.
It refuses to modify the current checkout or push/deploy anything.
"""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZipFile

BASE = '1bd5b44d9e11a4f0dc572cd74b7ba513e61f9844'
REPAIR = '533a722b4e81b391d04204d35d7bb8b96888c174'
SHA = '7467a39f8b8fb05f3b669b22067331e77fd379d87e7b42058fd968a9d050166e'
EXPECTED = {
    'cryptography': '50.0.0', 'numpy': '2.5.2', 'pandas': '3.0.5',
    'requests': '2.32.5', 'scikit-learn': '1.9.0', 'scipy': '1.18.1',
    'joblib': '1.5.3', 'websockets': '15.0.1',
}
EXECUTABLE = [
    'btc15_v2_product/main_timing.py',
    'btc15_v2_product/runtime.py',
    'BTC15_V2_PRODUCT_RELEASE_R1.json',
    'cockpit_candidate/cockpit.js',
    'cockpit_candidate/index.html',
    'cockpit_candidate/styles.css',
    'cockpit_candidate/hosting/runtime.sha256',
]

def git(repo, *args):
    return subprocess.run(['git','-C',str(repo),*args],check=True,text=True,capture_output=True).stdout.strip()

def stage(repo, package, run_tests=False):
    if not (repo/'.git').exists():
        # Handles a normal .git dir and worktree .git file.
        raise SystemExit('STOP: open your existing local GitHub Codespaces repo, then run this script there.')
    if git(repo,'rev-parse','--is-inside-work-tree')!='true':
        raise SystemExit('STOP: this is not a Git worktree.')
    try:
        git(repo,'cat-file','-e',BASE+'^{commit}')
    except subprocess.CalledProcessError:
        raise SystemExit('STOP: protected MAIN commit is absent locally. No files changed.')
    raw=package.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SHA:
        raise SystemExit('STOP: repair package hash mismatch. No files changed.')
    target=Path(tempfile.mkdtemp(prefix='btc15-continuity-test-'))
    try:
        git(repo,'worktree','add','--detach',str(target),BASE)
    except Exception:
        target.rmdir(); raise
    try:
        with ZipFile(package) as z:
            names=set(z.namelist())
            if len(names)!=len(z.namelist()) or not set(EXECUTABLE).issubset(names):
                raise ValueError('Incomplete or duplicate candidate files')
            for entry in z.infolist():
                path=Path(entry.filename)
                if path.is_absolute() or '..' in path.parts or entry.is_dir():
                    raise ValueError('Unexpected entry in repair ZIP')
                destination=target/path
                destination.parent.mkdir(parents=True,exist_ok=True)
                destination.write_bytes(z.read(entry.filename))
        for name in EXECUTABLE:
            if not (target/name).exists(): raise ValueError('Missing repair file '+name)
        for name in ('btc15_v2_product/main_timing.py','btc15_v2_product/runtime.py','ops/main_live_repair_20261008/test_producer.py'):
            compile((target/name).read_bytes(),str(target/name),'exec')
        json.loads((target/'BTC15_V2_PRODUCT_RELEASE_R1.json').read_text())
        print('STAGED: exact archived repair files applied to isolated detached checkout')
        print('CANDIDATE_CHECKPOINT:',REPAIR)
        print('CHECKOUT:',target)
        print('CURRENT_REPO_UNTOUCHED:',repo)
        print('NO_PUSH_NO_DEPLOY_NO_ORDERS: YES')
        print('PYTHON:',sys.version.split()[0])
        if sys.version_info[:2] != (3,12):
            print('RUNTIME_PIN_BLOCKER: Python 3.12 required for full acceptance tests')
        mismatches=[]
        for package_name,expected in EXPECTED.items():
            try:current=importlib.metadata.version(package_name)
            except importlib.metadata.PackageNotFoundError:current='MISSING'
            if current!=expected:mismatches.append(f'{package_name}: expected {expected}, got {current}')
        if mismatches:
            print('RUNTIME_PIN_BLOCKERS:',*mismatches,sep='\n - ')
        else:
            print('RUNTIME_DEPENDENCIES: all 8 pins MATCH')
        import hashlib as h
        # This is a source-code consistency check, not a replacement for tests.
        manifest=json.loads((target/'BTC15_V2_PRODUCT_RELEASE_R1.json').read_text())
        changed=[]
        for name,expected in manifest.get('files_sha256',{}).items():
            path=target/name
            if not path.is_file() or h.sha256(path.read_bytes()).hexdigest()!=expected:
                changed.append(name)
        if changed:
            print('MANIFEST_CHECK: MISMATCH',','.join(changed))
            print('STOP: do not deploy this assembly; original SCALP-base differences may require additional exact files.')
            return 2
        print('MANIFEST_CHECK: PASS')
        if run_tests:
            if mismatches or sys.version_info[:2]!=(3,12):
                print('TESTS_SKIPPED: exact pinned environment required')
                return 3
            tests=[
                [sys.executable,'ops/main_live_repair_20261008/test_producer.py'],
                [sys.executable,'-m','unittest','test_btc15_integrated_finish.ProtectedBaselines','test_btc15_integrated_finish.DirectionalLifecycle','test_btc15_integrated_finish.GeneralizedScalp'],
                ['node','ops/main_live_repair_20261008/test_display.cjs'],
            ]
            for cmd in tests:
                print('RUNNING:', ' '.join(cmd),flush=True)
                result=subprocess.run(cmd,cwd=target,timeout=240)
                if result.returncode:
                    print('NO-GO: test failed with code',result.returncode)
                    return result.returncode
            print('OFFLINE_TESTS: PASS (not live-source validation)')
        return 0
    finally:
        print('Staged worktree remains isolated for inspection. No changes to live systems.')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,default=Path.cwd())
    ap.add_argument('--run-tests',action='store_true')
    args=ap.parse_args()
    raise SystemExit(stage(args.repo.resolve(),Path(__file__).with_name('repair_payload.zip'),args.run_tests))
